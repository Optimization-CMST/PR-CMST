package Common;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;

public class Data {
	public String name;
	public int p; //the number of rows
	public int m; //the number of columns
	public boolean[][] panel; //true if a panel exists
	public int tot; //the number of panels
	public double[][] x; //the x-coordinates of vertices
	public double[][] y; //the y-coordinates of vertices
	public double[][] f; //the distances from vertices to the root
	public int[] size = {10,14}; //the sizes of subtrees
	public int[] num = {1,7}; //the numbers of subtrees with different sizes
	public int max_size = 14; //maximum size of subtrees
	//id map
	public int[] y_map; //map from panel to row
	public int[] x_map; //map from panel to column
	public ArrayList[] adj_map; //map from panel to adjacent panels
	public int[] size_map; //map from size to position
	public int[][] index_map; //map from [row, column] to panel
	public double[][] d; //the distances between different panels
	
	//DP2 init masks
	public int init_limit = 50;
	public long[] intDC = {0x00, 0x00, 0x00, 0x00};
	//algorithm parameter
	public double time_limit = 48 * 60 * 60;
	public double start_time  = System.nanoTime();
	//output information - root node
	public boolean is_root = true;
	public double lp_cost;
	public double lpc_cost;
	public double root_lp_time  = 0;
	public double root_lpc_time = 0;
	public double root_tabu_time;
	public double root_bd1_time = 0;
	public double root_bd2_time = 0;
	public double root_bd3_time = 0;
	public double root_join_time;
	public double total_join_time;
	public int root_flabels = 0;
	public int root_plabels = 0;
	public int root_blabels = 0;
	public int root_cap_num = 0;
	public int root_sr_num = 0;
	public double lpc = 0;
	
	public double ip_cost;
	public double ip_time = 0;
	public int node_num = 0;
	public int total_cap_num = 0;
	public int total_sr_num = 0;
	public double total_tabu_time;
	public long[] mask;
	public long all_mask;

	public double DP_1_time = 0;
	public double DP_2_time = 0;
	public double DP_NG_time = 0;

	public Data() {
	}


	public void build_info(){
		y_map = new int[tot + 1];
		x_map = new int[tot + 1];
		index_map = new int [p][m];
		int iter = 1;
		for(int i = 0; i < p; i++){
			for(int j = 0; j < m; j++){
				if(panel[i][j] == true){
					index_map[i][j] = iter;
					y_map[iter] = i;
					x_map[iter] = j;
					iter++;
				}
			}
		}
		size_map = new int[max_size + 1];
		for(int i = 0; i < max_size + 1; i++)
			size_map[i] = -1;
		for(int i = 0; i < size.length; i++){
			size_map[size[i]] = i;
		}
		d = new double[tot + 1][tot + 1];
		for(int i = 0; i < tot + 1; i++){
			for(int j = 0; j < tot + 1; j++){
				d[i][j] = 1e10;
			}
		}
		//only adjacent two vertices have a certain distance
		adj_map = new ArrayList[tot + 1];
		for(int i = 0; i < p; i++){
			for(int j = 0; j < m; j++){
				if(panel[i][j] == false)
					continue;
				int index1 = index_map[i][j];
				adj_map[index1] = new ArrayList<Integer>();
				if(i - 1 >= 0 && panel[i - 1][j]){
					int index2 = index_map[i - 1][j];
					d[index1][index2] = y[i][j] - y[i - 1][j];
					adj_map[index1].add(index2);
				}
				if(j - 1 >= 0 && panel[i][j - 1]){
					int index2 = index_map[i][j - 1];
					d[index1][index2] = x[i][j] - x[i][j - 1];
					adj_map[index1].add(index2);
				}
				if(i + 1 <= p - 1 && panel[i + 1][j]){
					int index2 = index_map[i + 1][j];
					d[index1][index2] = y[i + 1][j] - y[i][j];
					adj_map[index1].add(index2);
				}
				if(j + 1 <= m -  1 && panel[i][j + 1]){
					int index2 = index_map[i][j + 1];
					d[index1][index2] = x[i][j + 1] - x[i][j];
					adj_map[index1].add(index2);
				}
			}
		}
		//build mask
		mask = new long[tot + 1];
		long mx = 0x01;
		for(int i = 0; i < tot + 1; i++){
			mask[i] = mx;
			if(i == 63)
				mx = 0x01;
			else
				mx *= 2;
		}

		long mk = 0x01;
		for(int i = 0; i < 64; i++){
			all_mask = all_mask | mk;
			mk *= 2;
		}

	}
	public boolean time_out(){
		if((System.nanoTime() - start_time) / 1e9 > time_limit)
			return true;
		else
			return false;
	}

	public boolean turn_out(){
		if((System.nanoTime() - start_time) / 1e9 > 7200)
			return true;
		else
			return false;
	}
}
