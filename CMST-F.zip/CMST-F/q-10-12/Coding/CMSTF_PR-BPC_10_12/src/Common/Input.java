package Common;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;

public class Input {
	public static Data read_instance(String inst_path) throws Exception{
		Data data = new Data();
		Scanner cin = new Scanner(new BufferedReader(new FileReader(inst_path)));
		ArrayList<Double> px = new ArrayList<Double>();
		ArrayList<Double> py = new ArrayList<Double>();
		ArrayList<Integer> number = new ArrayList<Integer>();
		double depot_x1 = -1;
		double depot_x2 = -1;
		int depot_id1 = -1;
		int depot_id2 = -1;
		double depot_y1 = -1;
		double depot_y2 = -1;
		cin.nextLine();
		while(cin.hasNextLine()){
			String line = cin.nextLine();
			String[] subs = line.split(",");
			int type = Integer.parseInt(subs[2].trim());
			if(type == -3)
				continue;
			double x = Double.parseDouble(subs[0].trim());
			double y = Double.parseDouble(subs[1].trim());
			px.add(x);
			py.add(y);
			number.add(type);
			if(type == -1){
				if(depot_x1 == -1 || depot_y1 == -1){
					depot_x1 = x;
					depot_y1 = y;
					depot_id1 = px.size() - 1;
				}
				else{
					depot_x2 = x;
					depot_y2 = y;
					depot_id2 = px.size() - 1;
				}
			}
		}
		double depot_x = -1;
		double depot_y = -1;
		if(depot_id2 == -1){
			depot_x = depot_x1;
			depot_y = depot_y1;
		}
		else{
			depot_x = (depot_x1 + depot_x2)/2.0;
			depot_y = (depot_y1 + depot_y2)/2.0;
		}
		cin.close();
		//get the x ray
		ArrayList<Double> x_ray = new ArrayList<Double>();
		ArrayList<Double> y_ray = new ArrayList<Double>();
		for(int i = 0; i < px.size(); i++){
			double x = px.get(i);
			boolean is_exist = false;
			for(int j = 0; j < x_ray.size(); j++){
				if(Math.abs(x_ray.get(j) - x) < 1e-1){
					is_exist = true;
					break;
				}
			}
			if(is_exist)
				continue;
			int iter = 0;
			while(iter < x_ray.size() && x > x_ray.get(iter))
				iter++;
			x_ray.add(iter, x);
		}
		for(int i = 0; i < py.size(); i++){
			double y = py.get(i);
			boolean is_exist = false;
			for(int j = 0; j < y_ray.size(); j++){
				if(Math.abs(y_ray.get(j) - y) < 1e-1){
					is_exist = true;
					break;
				}
			}
			if(is_exist)
				continue;
			int iter = 0;
			while(iter < y_ray.size() && y > y_ray.get(iter))
				iter++;
			y_ray.add(iter, y);
		}
		System.out.println(x_ray);
		System.out.println(y_ray);
		for(int i = 0; i < x_ray.size() - 1; i++){
			System.out.print(x_ray.get(i + 1) - x_ray.get(i));
			System.out.print(" ");
		}
		System.out.println();
		for(int i = 0; i < y_ray.size() - 1; i++){
			System.out.print(y_ray.get(i + 1) - y_ray.get(i));
			System.out.print(" ");
		}
		System.out.println();
		double min_x = 1e10;
		double max_x = -1e10;
		double min_y = 1e10;
		double max_y = -1e10;
		for(int i = 0; i < x_ray.size() - 1; i++){
			double x_delta = x_ray.get(i + 1) - x_ray.get(i);
			if(x_delta < min_x)
				min_x = x_delta;
			if(x_delta > max_x)
				max_x = x_delta;
		}
		for(int i = 0; i < y_ray.size() - 1; i++){
			double y_delta = y_ray.get(i + 1) - y_ray.get(i);
			if(y_delta < min_y)
				min_y = y_delta;
			if(y_delta > max_y)
				max_y = y_delta;
		}
		System.out.println("x delta: " + min_x + " " + max_x);
		System.out.println("y delta: " + min_y + " " + max_y);
		data.p = y_ray.size();
		data.m = x_ray.size();
		data.panel = new boolean[data.p][data.m];
		data.x = new double[data.p][data.m];
		data.y = new double[data.p][data.m];
		int[][] num = new int[data.p][data.m];
		for(int i = 0; i < px.size(); i++){
			if(i == depot_id1 || i == depot_id2)
				continue;
			int x_iter = 0;
			while(x_iter < x_ray.size() && Math.abs(x_ray.get(x_iter) - px.get(i)) > 1e-1)
				x_iter++;
			if(x_iter >= x_ray.size()){
				System.out.println("cannot find x position!");
				System.exit(0);
			}
			int y_iter = 0;
			while(y_iter < y_ray.size() && Math.abs(y_ray.get(y_iter) - py.get(i)) > 1e-1)
				y_iter++;
			if(y_iter >= y_ray.size()){
				System.out.println("cannot find y position!");
				System.exit(0);
			}
			data.panel[y_iter][x_iter] = true;
			data.x[y_iter][x_iter] = px.get(i);
			data.y[y_iter][x_iter] = py.get(i);
			num[y_iter][x_iter] = number.get(i);
		}
		data.f = new double[data.p][data.m];
		data.tot = 0;
		for(int i = 0; i < data.p; i++){
			for(int j = 0; j < data.m; j++){
				if(data.panel[i][j]){
					data.f[i][j] = (int)(2.77 * (Math.abs(data.x[i][j] - depot_x) + Math.abs(data.y[i][j] - depot_y)));
					data.tot++;
				}
			}
		}
		data.build_info();

		System.out.println("demension: " + data.p + " " + data.m);
		System.out.println("count: " + data.tot);
		DecimalFormat df  = new DecimalFormat("000");
		//for(int i = 0; i < data.p; i++){
		for(int i = data.p - 1; i >= 0; i--){ //row
			for(int j = 0; j < data.m; j++){ //column
				if(data.panel[i][j]){
					System.out.print("[" + df.format(data.index_map[i][j]) + "]");
				}
				else{
					System.out.print("[   ]");
				}
			}
			System.out.println();
		}
		return data;
	}
}
