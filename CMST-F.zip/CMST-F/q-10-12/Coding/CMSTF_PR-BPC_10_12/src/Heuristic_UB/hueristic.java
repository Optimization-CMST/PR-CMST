package Heuristic_UB;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Random;
import java.util.Scanner;

public class hueristic {
	
	String File_Name;
	int tcl = 0;
	int SN_b = 300;
	int Slen = 0;
	int Stm1;
	int fd = 0;
	int tabu_len = 10;
	int N1, M1, N_vtx, BLK;
	int ff_best;
	int Psize = 10;

	double [][]XP;   // adjacent matrix
	double [][]YP;
	int [][]OEdge;

	double [][]XP1;   // adjacent matrix
	double [][]YP1;
	int [][]OEdge1;

	int [][]C_OEdge;
	int [][]CX;
	
	int []Snode_block;
	int []Snblock;
	int []Snode;
	int []color1;
	int []color2;
	int [][]tabu_list;
	int [][]SEdge;
	int []Scolor_temp;
	int [][]S_nd;
	int [][]C_nd1;
	int [][]C_nd2;
	int []Saddress;
	int []STcn;
	int []Scrinode;
	int []Srab_node;
	int []Sfdisg;
	int []Sdisg;
	int []Sfsolution;
	int []aa;
	int []kset;
	int [][]ad;
	int []clen;
	int []alen;
	int []bestsolution;
	int [][]bb;
	int [][]dd;
	
	int [][]Srblnt;

	int []Sadjaclen;
	int [][]SadjacMatrix;

	int [][]Sdis_two;
	int [][]distwo;
	int [][]Srp_dis_two;
	int []Sdis_o;
	int []Scp_D;
	int []crd;
	int []Gedge;
	int []is_set;
	int []is_flag;

	double Sxt = 2.77;
	int f = 0;

	int CN;
	int search_depth;
	
	int []fpop;
	int [][]Pop;
	int []Rbest;
	int []offspring;
	int p1, p2;
	
	public Random r3;
	
	public int randomInt( int n )
	{
		 //Random r3 = new Random();
	     return r3.nextInt(n);
	}
	
	public void Initializing() throws FileNotFoundException{
	    
		 r3 = new Random(1);
		 
	     Scanner cin = new Scanner(new BufferedReader(new FileReader(File_Name)));
	     String StrReading = "";
	     
	     
	     StrReading = cin.next();
	     N1 = Integer.parseInt(StrReading.trim());
	     
	     StrReading = cin.next();
	     M1 = Integer.parseInt(StrReading.trim());
	     
	     Snode_block = new int[ SN_b ];
	     Snblock = new int[ SN_b ];
	     Snode = new int[ SN_b ];
	     Saddress = new int[ SN_b ];
	     Scolor_temp = new int[ SN_b ];
	     STcn = new int[ SN_b ];
	     Scrinode = new int[ SN_b ];
	     Srab_node = new int[ SN_b ];
	     Sfdisg = new int[ SN_b ];
	     Sdisg = new int[ SN_b ];
	     color1 = new int[ SN_b ]; 
	     color2 = new int[ SN_b ];
	     Rbest = new int[ SN_b ];
	     fpop = new int[ SN_b ]; 
	     offspring = new int[ SN_b ];
	     Sfsolution = new int[ SN_b ];
	     Gedge = new int[ SN_b ];
	     is_set = new int[ SN_b ]; 
	     is_flag = new int[ SN_b ];
	     crd = new int[ 300 ];
	     bestsolution = new int[ 300 ];
	     alen = new int[ 40 ];
	     bb = new int[ 40 ][ 10 ];
	     dd = new int[ 100 ][ 100 ];
	     
	     SEdge = new int[ SN_b ][ SN_b ];
	     tabu_list = new int[ SN_b ][ SN_b ];
	     S_nd = new int[ SN_b ][ SN_b ];
	     C_nd1 = new int[ SN_b ][ SN_b ];
	     C_nd2 = new int[ SN_b ][ SN_b ];
	     Pop = new int[ SN_b ][ SN_b ];
	     
	     aa = new int[8];
	     kset = new int[10];
	     ad = new int[8][8];
	     clen = new int[10];
	     
	     XP = new double[ 122 ][ 75 ];   // adjacent matrix
	     YP = new double[ 122 ][ 75 ];
	     OEdge = new int[ 122 ][ 75 ];

	     XP1 = new double[ 122 ][ 75 ];   // adjacent matrix
	     YP1 = new double[ 122 ][ 75 ];
	     OEdge1 = new int[ 122 ][ 75 ];

	     C_OEdge = new int[ 122 ][ 75 ];
	     CX = new int[ 3500 ][ 2 ];
	     
	     
	     Srblnt = new int[ 10 ][ 10 ];

	     Sadjaclen = new int[ 300 ];
	     SadjacMatrix = new int[ 300 ][ 8 ];

	     Sdis_two = new int [ 300 ][ 300 ];
	     distwo = new int [ 300 ][ 300 ];
	     Srp_dis_two = new int [ 300 ][ 300 ];
	     Sdis_o = new int [ 300 ];
	     Scp_D = new int [ 8 ];
	     
	     int x1, x2;
	     double d1, d2, d3;
	     int x4;
	     int lll = 0;
	     
	     //FIC >> N1 >> M1;
	     System.out.println("N1 = " + N1 + " M1 = " + M1);
	     
	     /*for( int i = 0; i < N1; i++ )
	     for( int j = 0; j < M1; j++ )
	     {
	    	 StrReading = cin.next();
	    	 //System.out.println(StrReading);
	    	 d1 = Double.parseDouble(StrReading.trim());
	    	 StrReading = cin.next();
	    	 StrReading = cin.next();
	    	 d2 = Double.parseDouble(StrReading.trim());
	    	 StrReading = cin.next();
	    	 StrReading = cin.next();
	    	 x1 = Integer.parseInt(StrReading.trim());
	    	 //System.out.println( "d1 = " + d1 + " d2 = " + d2 + " x1 = " + x1 );
	         XP1[ i ][ j ] = d1;
	         YP1[ i ][ j ] = d2;
	         OEdge1[ i ][ j ] = x1; 
	     }*/
	     String line = cin.nextLine();
	     for( int i = 0; i < N1; i++ )
		 for( int j = 0; j < M1; j++ )
		 {
				line = cin.nextLine();
				String[] subs = line.split(",");
				//System.out.println(subs[0] + " " + subs[1] + " " + subs[2] );
				d1 = Double.parseDouble(subs[0].trim());
				d2 = Double.parseDouble(subs[1].trim());
				x1 = Integer.parseInt(subs[2].trim());
				//System.out.println( "d1 = " + d1 + " d2 = " + d2 + " x1 = " + x1 );
				
				XP1[ i ][ j ] = d1;
		        YP1[ i ][ j ] = d2;
		        OEdge1[ i ][ j ] = x1;		
		 }
	     
	     
	     for( int i = 0; i < N1; i++ )
	     for( int j = 0; j < M1; j++ )
	     {
	          XP[ i ][ j ] = XP1[ i ][ j ];
	          YP[ i ][ j ] = YP1[ i ][ j ];
	          OEdge[ i ][ j ] = OEdge1[ i ][ j ];
	          x1 = OEdge[ i ][ j ];
	          if(x1 == -3)
	             OEdge[ i ][ j ] = -1;
	          else
	          {
	             OEdge[ i ][ j ] = 0;  
	             CX[ lll ][ 0 ] = i;
	             CX[ lll ][ 1 ] = j; 
	             
	             if( x1 == -1 )
	                CN = lll;
	             lll++;
	          }
	          //FIC >> StrReading;
	          //cout << d1 << " " << d2 << " " << x1 << " " << endl;
	     }
	     
	     SN_b = lll;
	     BLK = (int)(lll/8) + 1;
	     System.out.println("lll = " + lll + " BLK = " + BLK );
	}
	
	int Srp_com_distwo(int knd1, int knd2)
	{
	     int x1, y1, x2, y2;
	     int node1 = knd1 ;
	     int node2 = knd2 ;
	     x1 = CX[ node1 ][ 0 ];
	     y1 = CX[ node1 ][ 1 ];
	     
	     x2 = CX[ node2 ][ 0 ];
	     y2 = CX[ node2 ][ 1 ];
	     
	     int d = Math.abs(x1 - x2) + Math.abs(y1 - y2);
	     return d;
	}


	int Scom_distwo(int knd1, int knd2)
	{
	     int x1, y1, x2, y2;
	     int node1 = knd1 ;
	     int node2 = knd2 ;
	     x1 = CX[ node1 ][ 0 ];
	     y1 = CX[ node1 ][ 1 ];
	     
	     x2 = CX[ node2 ][ 0 ];
	     y2 = CX[ node2 ][ 1 ];
	     
	     //int d = fabs(XP[ x1 ][ y1 ] - XP[ x2 ][ y2 ] ) + fabs(YP[ x1 ][ y1 ] - YP[ x2 ][ y2 ] );
	     int d = (int) ( Math.abs(XP[ x1 ][ y1 ] - XP[ x2 ][ y2 ]) + Math.abs(YP[ x1 ][ y1 ] - YP[ x2 ][ y2 ]) );
	     return (d);
	}

	int is_neighbor(int node1, int node2)
	{
	     int x1, y1, x2, y2;
	     x1 = CX[ node1 ][ 0 ];
	     y1 = CX[ node1 ][ 1 ];
	     
	     x2 = CX[ node2 ][ 0 ];
	     y2 = CX[ node2 ][ 1 ];
	     
	     if( (x1 == x2) && ( y1 == (y2+1) ) )
	        return 1;
	        
	     if( (x1 == x2) && ( y1 == (y2-1) ) )
	        return 1; 
	        
	     if( (y1 == y2) && ( x1 == (x2+1) ) )
	        return 1; 
	        
	     if( (y1 == y2) && ( x1 == (x2-1) ) )
	        return 1;   
	        
	     return 0;        
	}
	
	void construct_sub_graph()
	{
	    int i, j, k, l, m;
	    
	    for( i = 0; i < SN_b; i++ )
	    for( j = 0; j < SN_b; j++ )
	    {
	        SEdge[ i ][ j ] = 0;
	        Sdis_two[ i ][ j ] = Scom_distwo(i,j);
	        Srp_dis_two[ i ][ j ] = Srp_com_distwo(i,j);
	    }
	    
	    for( i = 0; i < SN_b; i++ )
	    for( j = i + 1; j < SN_b; j++ )  
	    if( is_neighbor(i,j) == 1)  
	        SEdge[ i ][ j ] = SEdge[ j ][ i ] = 1;
	        
	    for( int x = 0 ; x < SN_b; x++ )
	    {
	        Sadjaclen[ x ] = 0;
	        for( int y = 0; y < SN_b; y++ )
	        {
	             if( SEdge[ x ][ y ] != 0 )
	             {
	                 SadjacMatrix[ x ][ Sadjaclen[ x ] ] = y;
	                 Sadjaclen[ x ]++;
	             }
	         }
	    }
	    
	    Stm1 = 4*SN_b;
	}

	void Set_original()
	{
	     int i, j, k, l, m;
	     int dmin = 99999999;
	     int d;
	     int kmin = -1;
	     for( i = 0; i < SN_b; i++ )
	     {
	         Snode_block[ i ] = 0;
	     }
	     
	     k = CN;
	     //cout << "k = " << k << " CN = " << CN << endl;
	     Snode_block[ k ] = -1;
	     
	     int tl = 0;
	     int xo, yo;
	     int x1, x2, y1, y2;
	     x1 = CX[ k ][ 0 ];
	     y1 = CX[ k ][ 1 ];
	     xo = (int)( XP[ x1 ][ y1 ] );
	     yo = (int)( YP[ x1 ][ y1 ] ); 
	     for( i = 0; i < SN_b; i++ )
	     {
	         x1 = CX[ i ][ 0 ];
	         y1 = CX[ i ][ 1 ]; 
	         d = (int)( Math.abs(XP[ x1 ][ y1 ] - xo ) + Math.abs(YP[ x1 ][ y1 ] - yo ));
	         Sdis_o[ i ] = (int)(d*Sxt);
	     }
	}

	void Sselect_all()
	{
	    int i, j, k, l;
	    Slen = 0;
	    for( i = 0; i < SN_b; i++ )
	    {
	        if(Snode_block[ i ] == 0)
	           Snode[ Slen++ ] = i; 
	    }
	}
	
	void Sini_solution1()
	{
	     int i, j, k, l, m;
	     tcl = 0;
	     
	     for( i = 0; i < SN_b; i++ )
	     {
	         Snode_block[ i ] = 0;   
	     } 
	     
	     for( i = 1; i <= BLK; i++ )
	         Snblock[ i ] = 0;
	    
	     for( i = 0; i < SN_b; i++ )
	     for( j = 0; j < SN_b; j++ )
	         tabu_list[ i ][ j ] = 0; 
	    
	     for( i = 1; i <= BLK; i++ )
	         Scolor_temp[ i ] = 8;       
	    
	     for( i = 0; i < 2; i++ )
	     {
	         while(true)
	         {
	             k = 1 + randomInt(BLK);
	             if( Scolor_temp[ k ] == 8 )
	             {
	                 Scolor_temp[ k ] = 6;
	                 break;
	             }    
	         } 
	     }    
	      
	     Set_original();
	     
	     for( i = 0; i < SN_b - 1; i++ )
	     {     
	         Sselect_all();
	         k = randomInt(Slen);
	         k = Snode[ k ];
	         while(true)
	         {
	             tcl = 1 + randomInt(BLK);
	             if( Snblock[ tcl ] < Scolor_temp[ tcl ])
	             {
	                 break;
	             }    
	         }
	         Snode_block[ k ] = tcl;
	         Snblock[ tcl ]++;
	     }
	      
	     for( i = 1; i <= BLK; i++ )
	        Snblock[ i ] = 0;
	     for( i = 0; i < SN_b; i++ )
	     if(Snode_block[ i ] > 0)
	     {
	        k = Snode_block[ i ];  
	        S_nd[ k ][ Snblock[ k ] ] = i;
	        Saddress[ i ] = Snblock[ k ];
	        Snblock[ k ]++;
	        //cout << "i = " << i << "k = " << k << " address = " << Snblock[ k ] << endl;
	     }
	     
	     /*for( i = 0; i < SN_b; i++ )
	        cout << Saddress[ i ] << " ";
	     cout << endl;   
	     
	     for( i = 1; i < 15; i++ )
	     {
	        for( j = 0; j < Snblock[ i ]; j++ )  
	           cout << S_nd[ i ][ j ] << " ";
	        cout << endl;    
	     }   
	     cout << endl; 
	     for( i = 1; i < 15; i++ )
	        cout << "i = " << i << " len = " << Snblock[ i ] << " limit = " << Scolor_temp[ i ] << endl;  */
	     //getchar(); 
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	//////////*repair tabu search*////////////////////////////////////////////////////////////////////////////////////////////////
	int Set_reachable(int xlen)
	{
	    int i, j, k, l, m, xnd1;
	    
	    int klen = 0;
	    
	    for( i = 0; i < 10; i++ )
	    for( j = 0; j < 10; j++ )
	       Srblnt[ i ][ j ] = 0;
	  
	    //memset(STcn, 0, Stm1);//please check here 
	    for( i = 0; i < SN_b; i++ )
	        STcn[ i ] = 0;
	    
	    for( i = 0; i < xlen; i++ )
	    {
	       aa[ i ] = Srab_node[ i ];   
	    }
	    
	    for( i = 0; i < xlen; i++ )
	       STcn[ aa[ i ] ] = 1;
	    
	    while(true)
	    {
	       klen = 0;
	       for( i = 0; i < 10; i++ )
	          clen[ i ] = 0;
	    
	       xnd1 = -1;
	       for( i = 0; i < xlen; i++ )
	       if(STcn[ aa[ i ] ] == 1)
	       {
	           kset[ klen++ ] = i; 
	           xnd1 = aa[ i ];  
	           break;    
	       }
	       
	       if(xnd1 == -1)
	         break;
	     
	       ad[ 0 ][ 0 ] = xnd1;
	       STcn[ xnd1 ] = 0;
	       clen[ 0 ] = 1;
	       l = 1; 
	       int dpt = 0;  
	       while( true )
	       {
	           for( i = 0; i < clen[ dpt ]; i++ )  
	           {
	               k = ad[ dpt ][ i ];
	               for( j = 0; j < xlen; j++ )
	               {
	                   m =  aa[ j ]; 
	                   if( (m != k) && (STcn[ m ] == 1) && (SEdge[ m ][ k ] == 1) )
	                   {
	                        ad[ dpt + 1  ][ clen[ dpt + 1 ] ] = m;
	                        STcn[ m ] = 0;
	                        clen[ dpt + 1 ]++;
	                        kset[ klen++ ] = j;
	                   }
	               }  
	           }
	            
	           if(clen[ dpt + 1 ] == 0) 
	                break; 
	           dpt++;    
	       }
	       
	       for( i = 0; i < klen; i++ )
	       for( j = i+1; j < klen; j++ )
	           Srblnt[ kset[i] ][ kset[j] ] = Srblnt[ kset[j] ][ kset[i] ] = 1;
	     }
	    
	     return 0;
	}

	int Srp_com_group_distance(int ki)
	{
	    int d, dmin;
	    int i, j, k, l, m, xx;
	    int kmin = 0;
	    int imin = 0;
	    dmin = 9999999;
	    
	    for( xx = 0; xx < Snblock[ ki ]; xx++ )
	        Srab_node[  xx ] = S_nd[ ki ][ xx ]; 
	    //cout << "hello1" << endl;
	    Set_reachable( Snblock[ ki ] );
	    
	    //cout << "hello2" << endl;
	    for( i = 0; i < Snblock[ ki ]; i++ )
	    {
	         k = S_nd[ ki ][ i ];
	         d = 0;
	          
	         for( j = 0; j < Snblock[ ki ]; j++ )
	         if( i != j )
	         { 
	             m = S_nd[ ki ][ j ];
	             if( Srblnt[ i ][ j ] == 1)  
	                d += 0;
	             else
	             {
	                 d += 100*Srp_dis_two[ k ][ m ];
	             }    
	         }
	         if( d < dmin )
	         {
	             dmin = d;
	             kmin = k;
	             imin = i;
	         }
	    } 
	    
	    Scrinode[ kmin ] = 0;
	    for( j = 0; j < Snblock[ ki ]; j++ )
	    if( S_nd[ ki ][ j ] != kmin )
	    { 
	        m = S_nd[ ki ][ j ];
	        if( Srblnt[ imin ][ j ] == 1)  
	          Scrinode[ m ] = 0;
	        else
	          Scrinode[ m ] = 1;      
	    }  
	   
	    return dmin;
	}

	void Srp_comp_distance()
	{
	    int i, j, k, l, m, x1, x2;
	    fd = 0;
	    //cout << "in Srp_comp_distance()" << endl;
	    for( i = 0; i < SN_b; i++ )
	         Scrinode[ i ] = 0;
	    
	    for( i = 1; i <= BLK; i++ )
	    {
	         Sfdisg[ i ] = Srp_com_group_distance(i);
	         fd += Sfdisg[ i ];
	         //cout << "i = " << i << " dis = " << Sfdisg[ i ] << " fd = " << fd << endl; 
	    } 
	    //getchar();
	} 

	int Srp_comp_cp_D(int len)
	{
	    int d, dmin;
	    int i, j, k, l, m, xx;
	    int kmin;
	    
	    for( xx = 0; xx < len; xx++ )
	        Srab_node[  xx ] = Scp_D[ xx ]; 
	        
	    Set_reachable( len );    
	    
	    dmin = 9999999;
	    for( i = 0; i < len; i++ )
	    {
	         k = Scp_D[ i ];
	         d = 0;
	         
	         for( j = 0; j < len; j++ )
	         {
	              if( Scp_D[ j ] != k )
	              {
	                  m = Scp_D[ j ];
	                  if( Srblnt[ i ][ j ] == 1)   
	                     d += 0;
	                  else
	                  {
	                     d += 100*Srp_dis_two[ k ][ m ];
	                  }   
	              } 
	         }
	         if( d < dmin )
	         {
	             dmin = d;
	             kmin = k;
	         }
	    }
	    return dmin;  
	} 

	int Srp_delta_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    
	    for( i = 0; i < Snblock[ Snode_block[ xnd1 ] ]; i++ )
	        Scp_D[ i ] = S_nd[ Snode_block[ xnd1 ] ][ i ];
	    
	    m = Saddress[ xnd1 ];
	    Scp_D[ m ] = xnd2;
	    
	    int d1 = Srp_comp_cp_D( Snblock[ Snode_block[ xnd1 ] ] );   
	    
	    for( i = 0; i < Snblock[ Snode_block[ xnd2 ] ]; i++ )
	        Scp_D[ i ] = S_nd[ Snode_block[ xnd2 ] ][ i ];
	    
	    m = Saddress[ xnd2 ];
	    Scp_D[ m ] = xnd1;
	    
	    int d2 = Srp_comp_cp_D( Snblock[ Snode_block[ xnd1 ] ] ); 
	    
	    int d = d1 + d2 - Sfdisg[ Snode_block[ xnd1 ] ] - Sfdisg[ Snode_block[ xnd2 ] ];
	   
	    return d;
	}

	void Srp_perform_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    int k1 = Snode_block[ xnd1 ];
	    int k2 = Snode_block[ xnd2 ];
	    int m1 = Saddress[ xnd1 ];
	    int m2 = Saddress[ xnd2 ];
	    
	    Snode_block[ xnd1 ] = k2;
	    Snode_block[ xnd2 ] = k1;
	    
	    S_nd[ k1 ][ m1 ] = xnd2;
	    S_nd[ k2 ][ m2 ] = xnd1;
	    Saddress[ xnd1 ] = m2;
	    Saddress[ xnd2 ] = m1;
	    
	    Sfdisg[ k1 ] = Srp_com_group_distance(k1);
	    Sfdisg[ k2 ] = Srp_com_group_distance(k2);
	}

	int Stabu_repair( int depth )
	{
	     int iter, i, j, k, l, m;
	     int d, fmin, ftabu;
	     int kmin1, kmin2, ktabu1, ktabu2;
	     int fbest = fd;
	     
	     int clen;
	     for( i = 0; i < SN_b; i++ )
	     for( j = 0; j < SN_b; j++ )
	         tabu_list[ i ][ j ] = 0;
	         
	     for( iter = 1; iter <= depth; iter++ )
	     {
	          fmin = 9999999;
	          kmin1 = -1;
	          kmin2 = -1;
	          
	          ftabu = 9999999;
	          ktabu1 = -1;
	          ktabu2 = -1;
	          clen = 0;
	          for( i = 0; i < SN_b; i++ )
	          if( Scrinode[ i ] == 1 )
	            crd[ clen++ ] = i;
	            
	          clen = randomInt(clen);
	          i = crd[ clen ];  
	          l = 0;
	            
	          for( j = 0; j < SN_b; j++ )
	          if( (Snode_block[ i ] != Snode_block[ j ]) && (Snode_block[ i ] > 0) && (Snode_block[ j ] > 0) )
	          {
	               d = Srp_delta_exchange_two(i,j);
	               if( (tabu_list[ i ][ j ] < iter) )
	               {
	                  if(d < fmin)
	                  {
	                      fmin = d;
	                      kmin1 = i;
	                      kmin2 = j;
	                      l = 1;
	                  }
	                  else if( d == fmin )
	                  {
	                      l++;
	                      if( randomInt(l) == 0 )
	                      {
	                         kmin1 = i;
	                         kmin2 = j;
	                      } 
	                  } 
	               }
	               else
	               {
	                   if( d < ftabu )
	                   {
	                       ftabu = d;
	                       ktabu1 = i;
	                       ktabu2 = j;
	                   }
	               }
	          }
	          
	          fd = 0; 
	          tabu_list[ kmin1 ][ kmin2 ] = iter + tabu_len;
	          tabu_list[ kmin2 ][ kmin1 ] = iter + tabu_len; 
	          Srp_perform_exchange_two(kmin1,kmin2);
	          for( i = 1; i <= BLK; i++ )
	            fd += Sfdisg[ i ];
	          //Srp_check_solution1();
	          if(fd == 0)
	            return 1;  
	     } 
	     return 0;
	}

	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////*tabu search procedure*/////////////////////////////////////////////////////////////////////////////////////
	int Sin_connected(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	 
	    for( i = 0; i < SN_b; i++ )
	        STcn[ i ] = 0;
	    
	    for( i = 0; i < 10; i++ )
	       clen[ i ] = 0;
	    
	    k = Snode_block[ xnd1 ];
	    int len = 0;
	    for( i = 0; i < Snblock[ k ]; i++ )
	    {
	       if(S_nd[ k ][ i ] != xnd1)
	          aa[ len++ ] = S_nd[ k ][ i ];
	       clen[ i ] = 0;   
	    }
	    aa[ len++ ] = xnd2;
	    
	    //for( i = 0; i < len; i++ )
	    //   cout << aa[ i ] << " ";
	    //cout << endl;   
	    
	    for( i = 0; i < len; i++ )
	       STcn[ aa[ i ] ] = 1;
	       
	    ad[ 0 ][ 0 ] = aa[ 0 ];
	    STcn[ aa[ 0 ] ] = 0;
	    clen[ 0 ] = 1;
	    l = 1; 
	    int dpt = 0;  
	    while( true )
	    {
	        for( i = 0; i < clen[ dpt ]; i++ )  
	        {
	            k = ad[ dpt ][ i ];
	            for( j = 0; j < Sadjaclen[ k ]; j++ )
	            {
	                m =  SadjacMatrix[ k ][ j ]; 
	                if( STcn[ m ] == 1 )
	                {
	                     ad[ dpt + 1  ][ clen[ dpt + 1 ] ] = m;
	                     STcn[ m ] = 0;
	                     clen[ dpt + 1 ]++;
	                     l++;
	                }
	            }  
	        } 
	        if(clen[ dpt + 1 ] == 0) 
	            break; 
	        dpt++;    
	    }
	    
	    if( l < len )
	       return 0;
	    else
	       return 1;       
	}

	int Sis_exchangeable(int xnd1, int xnd2) 
	{
	    int i, j, k, l, m;
	    int knd1 = Snode_block[ xnd1 ];
	    int knd2 = Snode_block[ xnd2 ];
	    l = 0;
	    for( j = 0; j < Sadjaclen[ xnd1 ]; j++ )
	    {
	        m = SadjacMatrix[ xnd1 ][ j ]; 
	        if( Snode_block[ m ] == knd2 )
	           l++;
	    }
	    if(l == 0)
	       return 0;
	       
	    l = 0;
	    for( j = 0; j < Sadjaclen[ xnd2 ]; j++ )
	    {
	        m = SadjacMatrix[ xnd2 ][ j ]; 
	        if( Snode_block[ m ] == knd1 )
	           l++;
	    }
	    if(l == 0)
	       return 0;
	          
	    l = Sin_connected(xnd1,xnd2);
	    if(l == 0)
	       return 0;   
	    
	    l = Sin_connected(xnd2,xnd1);
	    if(l == 0)
	       return 0;   
	    
	    return 1;      
	}

	int Scom_group_distance(int ki)
	{
	    int d, dmin;
	    int i, j, k, l, m;
	    int kmin;
	    dmin = 9999999;
	    for( i = 0; i < Snblock[ ki ]; i++ )
	    {
	         k = S_nd[ ki ][ i ];
	         d = Sdis_o[ k ];
	         
	         for( j = 0; j < Snblock[ ki ]; j++ )
	         {
	              if( S_nd[ ki ][ j ] != k )
	              {
	                  m = S_nd[ ki ][ j ];
	                  d += Sdis_two[ m ][ k ];
	              } 
	         }
	         if( d < dmin )
	         {
	             dmin = d;
	             kmin = k;
	         }
	         
	    }   
	    
	    return dmin;
	}

	void Scomp_distance()
	{
	    int i, j, k, l, m;
	    f = 0;
	    for( i = 1; i <= BLK; i++ )
	    {
	         Sdisg[ i ] = Scom_group_distance(i);
	         f += Sdisg[ i ];
	         //cout << "i = " << i << " dis = " << Sdisg[ i ] << " f = " << f << endl;
	    } 
	} 

	int Scomp_cp_D(int len)
	{
	    int d, dmin;
	    int i, j, k, l, m;
	    int kmin;
	    dmin = 9999999;
	    for( i = 0; i < len; i++ )
	    {
	         k = Scp_D[ i ];
	         d = Sdis_o[ k ];
	         //cout << k << " ";
	         //d = 0;
	         //cout << "d = " << d << " dis_o = "<< dis_o[ k ] << endl; 
	         for( j = 0; j < len; j++ )
	         {
	              if( Scp_D[ j ] != k )
	              {
	                  m = Scp_D[ j ];
	                  d += Sdis_two[ m ][ k ];
	              } 
	         }
	         if( d < dmin )
	         {
	             dmin = d;
	             kmin = k;
	         }
	         //cout << "d = " << d << " k = " << k << endl;
	    }
	    //cout << endl;   
	    //cout << "dmin = " << dmin << " kmin = " << kmin << endl; 
	    //getchar();
	    return dmin;  
	} 

	int Sdelta_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    //cout << "xnd1 = " << xnd1 << " xnd2 = " << xnd2 << " color1 = " << color[ xnd1 ] << " color2 = " << color[ xnd2 ] << endl;
	    for( i = 0; i < Snblock[ Snode_block[ xnd1 ] ]; i++ )
	        Scp_D[ i ] = S_nd[ Snode_block[ xnd1 ] ][ i ];
	    
	    m = Saddress[ xnd1 ];
	    Scp_D[ m ] = xnd2;
	    
	    int d1 = Scomp_cp_D( Snblock[ Snode_block[ xnd1 ] ] );   
	    
	    for( i = 0; i < Snblock[ Snode_block[ xnd2 ] ]; i++ )
	        Scp_D[ i ] = S_nd[ Snode_block[ xnd2 ] ][ i ];
	    
	    m = Saddress[ xnd2 ];
	    Scp_D[ m ] = xnd1;
	    
	    int d2 = Scomp_cp_D( Snblock[ Snode_block[ xnd2 ] ] );  
	    
	    int d = d1 + d2 - Sdisg[ Snode_block[ xnd1 ] ] - Sdisg[ Snode_block[ xnd2 ] ];
	    //cout << "d1 = " << d1 << " d2 = " << d2 << " disg1 = " << disg[ node_color[ xnd1 ] ] << " disg2 = " << disg[ node_color[ xnd2 ] ] << endl;
	    return d;
	}

	void Sperform_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    int k1 = Snode_block[ xnd1 ];
	    int k2 = Snode_block[ xnd2 ];
	    int m1 = Saddress[ xnd1 ];
	    int m2 = Saddress[ xnd2 ];
	    
	    Snode_block[ xnd1 ] = k2;
	    Snode_block[ xnd2 ] = k1;
	    
	    S_nd[ k1 ][ m1 ] = xnd2;
	    S_nd[ k2 ][ m2 ] = xnd1;
	    Saddress[ xnd1 ] = m2;
	    Saddress[ xnd2 ] = m1;
	    
	    Sdisg[ k1 ] = Scom_group_distance(k1);
	    Sdisg[ k2 ] = Scom_group_distance(k2);
	}

	int Scheck_solution()
	{
	    int i, j, k, l, m;
	    //cout << "hello " << endl; 
	    
	    for( i = 0; i < 40; i++ )
	       alen[ i ] = 0;
	    for( i = 0; i < SN_b; i++ )
	    if(Snode_block[ i ] >= 0)
	    {
	       bb[ Snode_block[ i ] ][ alen[ Snode_block[ i ] ]++ ] = i;
	    }
	       
	    for( i = 1; i <= BLK; i++ )
	    	System.out.print(alen[ i ] + " ");	
	     
	    System.out.println(" ");	     
	       
	    int ff = 0;  
	    int d;  
	    for( i = 1; i <= BLK; i++ )
	    {
	       for( j = 0; j < alen[ i ]; j++ )
	         Scp_D[ j ] = bb[ i ][ j ];
	       d = Scomp_cp_D( alen[ i ] );
	       ff += d;
	       //cout << "d = " << d << " dreal = " << Sdisg[ i ] << endl;    
	    } 
	    System.out.println("f = " + ff + " freal = " + f);	
	     
	    return ff;
	}

	int Stabu_search( int depth )
	{
	     int iter, i, j, k, l, m;
	     int d, fmin, ftabu;
	     int kmin1, kmin2, ktabu1, ktabu2;
	     int fbest = f;
	     
	     for( i = 0; i < SN_b; i++ )
	     for( j = 0; j < SN_b; j++ )
	         tabu_list[ i ][ j ] = 0; 
	     
	     for( iter = 1; iter <= depth; iter++ )
	     {
	          fmin = 9999999;
	          kmin1 = -1;
	          kmin2 = -1;
	          
	          ftabu = 9999999;
	          ktabu1 = -1;
	          ktabu2 = -1;
	          l = -1;
	         
	          for( i = 0; i < SN_b; i++ )
	          for( j = i + 1; j < SN_b; j++ )
	          if( (Snode_block[ i ] != Snode_block[ j ]) && (Snode_block[ i ] > 0) && (Snode_block[ j ] > 0) )
	          {
	              if( (Sis_exchangeable(i,j) == 1) )
	              {
	                   d = Sdelta_exchange_two(i,j);
	                   if( (tabu_list[ i ][ Snode_block[ j ] ] < iter) && (tabu_list[ j ][ Snode_block[ i ] ] < iter) )
	                   {
	                       if(d < fmin)
	                       {
	                          fmin = d;
	                          kmin1 = i;
	                          kmin2 = j;
	                          l = 1;
	                       }
	                       else if( d == fmin )
	                       {
	                          l++;
	                          if( randomInt(l) == 0 )
	                          {
	                              kmin1 = i;
	                              kmin2 = j;
	                          } 
	                       } 
	                   }
	                   else
	                   {
	                       if( d < ftabu )
	                       {
	                           ftabu = d;
	                           ktabu1 = i;
	                           ktabu2 = j;
	                       }
	                   }
	              }
	          }  
	          
	          if( ( (ftabu < fmin) && (f + ftabu < fbest) ) || (l <= 0) )
	          {
	              //cout << "ktabu1 = " << ktabu1 << " ktabu2 = " << ktabu2 << endl;
	              f += ftabu; 
	              tabu_list[ ktabu1 ][ Snode_block[ ktabu1 ] ] = iter + tabu_len;
	              tabu_list[ ktabu2 ][ Snode_block[ ktabu2 ] ] = iter + tabu_len; 
	              Sperform_exchange_two(ktabu1,ktabu2);
	              //cout << "in aspiration f = " << f << endl;
	          }
	          else
	          {
	              //cout << "kmin1 = " << kmin1 << " kmin2 = " << kmin2 << endl;
	              f += fmin; 
	              tabu_list[ kmin1 ][ Snode_block[ kmin1 ] ] = iter + tabu_len;
	              tabu_list[ kmin2 ][ Snode_block[ kmin2 ] ] = iter + tabu_len; 
	              Sperform_exchange_two(kmin1,kmin2);
	          }   
	          
	          if( fbest  > f )
	          {
	              fbest = f;
	              //Soutput();
	              //Scheck_solution(); 
	              //cout << "fbest = " << fbest << endl; 
	              for( i = 0; i < SN_b; i++ )
	                 Sfsolution[ i ] = Snode_block[ i ];
	          } 
	          //getchar(); 
	     }
	     return fbest;  
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	
	void rough_optimize()
	{
	    int mm, i, j, d; 
	    Scomp_distance();
	    
	    for( mm = 0; mm < 80; mm++ )
	    {
	        for( i = 0; i < SN_b; i++ )
	        for( j = i + 1; j < SN_b; j++ )
	        if( (Snode_block[ i ] != Snode_block[ j ]) && (Snode_block[ i ] > 0) && (Snode_block[ j ] > 0) )
	        {
	             d = Sdelta_exchange_two(i,j);
	             if(d <= 0)
	             {
	                 f += d;  
	                 Sperform_exchange_two(i,j);                   
	                 //cout << "i = " << i << " j = " << j <<  " d = " << d << " f = " << f << endl;                    
	             }
	        }         
	    } 
	}
	
	void dispatchnode1(int []p)
	{
	     int i, j, k, l, m;
	     for( i = 1; i <= BLK; i++ )
	        color1[ i ] = 0;
	        
	     for( i = 0; i < N_vtx; i++ )
	     if( p[ i ] > 0 )
	     {
	          C_nd1[ p[ i ] ][ color1[ p[ i ] ] ] = i;
	          color1[ p[ i ] ]++;      
	     }             
	}
	 
	void dispatchnode2(int []p)
	{
	     int i, j, k, l, m;
	     for( i = 1; i <= BLK; i++ )
	        color2[ i ] = 0;
	        
	     for( i = 0; i < N_vtx; i++ )
	     if( p[ i ] > 0 )
	     {
	          C_nd2[ p[ i ] ][ color2[ p[ i ] ] ] = i;
	          color2[ p[ i ] ]++;      
	     }             
	}
	
	int dis_two_component(int x1, int x2)
	{
	    int i, j, k, m;
	    int l1 = 0;
	    int l2 = 0;
	    int l = 0;
	    int k1 = color1[ x1 ];
	    int k2 = color2[ x2 ];
	    while( (l1 < k1) && (l2 < k2) )
	    {
	        if(C_nd1[ x1 ][ l1 ] < C_nd2[ x2 ][ l2 ])  
	        {
	            l1++;           
	        } 
	        else if(C_nd1[ x1 ][ l1 ] > C_nd2[ x2 ][ l2 ])
	        {
	            l2++; 
	        }
	        else if(C_nd1[ x1 ][ l1 ] == C_nd2[ x2 ][ l2 ])
	        {
	            l1++;
	            l2++;
	            l++;
	        }
	    }
	    
	    return l;
	}
	
	int com_distance(int []p1, int []p2)
	{
	    int i, j, k, l, m, n, num;
	    int i1, i2, i3;
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = 0;
	    }
	    
	    dispatchnode1(p1);
	    dispatchnode2(p2);
	    
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = dis_two_component(i,j);
	    }
	    
	    int cmin = -1;
	    int hmin = -1;
	    num = 0;
	    
	    int fm = -1;
	    for( i1 = 1; i1 <= BLK; i1++ )
	    {
	         cmin = -1;
	         hmin = -1;
	         fm = -1;
	         for( i2 = 1; i2 <= BLK; i2++ )
	         for( i3 = 1; i3 <= BLK; i3++ )
	         if( distwo[ i2 ][ i3 ] > fm )
	         {
	             fm = distwo[ i2 ][ i3 ];
	             cmin = i2;
	             hmin = i3;
	         }
	         
	         num = num + fm;
	         
	         for( i = 1; i <= BLK; i++ )
	         {
	              distwo[ cmin ][ i ] = 0; 
	              distwo[ i ][ hmin ] = 0;
	         }
	    } 
	    
	    int pros = (100*num)/(N_vtx - 1); 
	    return pros;
	}
	
	int com_pop_dis(int ki_len)
	{
	    int i, j, k, l, m;
	    l = 0;
	    for( i = 0; i < ki_len; i++ )
	    {
	        m = com_distance(Pop[i],Sfsolution); 
	        if( m > l )
	           l = m;
	    }
	    
	    return l;
	}
	
	int Ini_Pop()
	{
	    int i, j, k, l, l1, l2, m;
	    int f1;
	    i = 0;
	    ff_best = 900000000;
	    while( i < Psize )
	    {
	          while(true)
              { 
                 Sini_solution1();
                 rough_optimize();
                 Srp_comp_distance();
         
                 if(fd > 0)
                 {
                    Stabu_repair(1000);
                 }
                 if(fd == 0)
                    break;
              }
              
              Scomp_distance();
              
	          f1 = Stabu_search( search_depth );
	          //cout << "one run of search is finished f1 = " << f1 << endl;
	          //System.out.println( "one run of search is finished f1 = " + f1 );
	         
	          l = com_pop_dis(i); 
	          
	          //if( (l < 95 ) || (f1 < ff_best) )
	          {
	            if(f1 < ff_best)
	            {	
	                ff_best = f1;
	                for( j = 0; j < N_vtx; j++ )
		            {
		               Rbest[ j ] = Sfsolution[ j ]; 
		            }
	            }
	         
	            fpop[ i ] = f1;
	            for( j = 0; j < N_vtx; j++ )
	            {
	               Pop[ i ][ j ] = Sfsolution[ j ]; 
	            }
	            i++;
	          }
	         //cout << "hello" << endl;
	    }
	    System.out.println( "finish population ini f = " + ff_best );
	    
	    return ff_best; 
	}
	
	void assign_value(int x1, int x2, int xkl)
	{
	    int k;
	    int l1 = 0;
	    int l2 = 0;
	    int k1 = color1[ x1 ];
	    int k2 = color2[ x2 ];
	    while( (l1 < k1) && (l2 < k2) )
	    {
	        if(C_nd1[ x1 ][ l1 ] < C_nd2[ x2 ][ l2 ])  
	        {
	            l1++;           
	        } 
	        else if(C_nd1[ x1 ][ l1 ] > C_nd2[ x2 ][ l2 ])
	        {
	            l2++; 
	        }
	        else if(C_nd1[ x1 ][ l1 ] == C_nd2[ x2 ][ l2 ])
	        {
	            k = C_nd1[ x1 ][ l1 ];
	            offspring[ k ] = xkl; 
	            l1++;
	            l2++;
	        }
	    }
	}
	
	void cross_over(int []pp1, int []pp2)
	{
	    int i, j, k, l, m, n, num;
	    int i1, i2, i3;
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = 0;
	    }
	    
	    dispatchnode1(pp1);
	    dispatchnode2(pp2);
	    
	    for( i = 0; i < N_vtx; i++ )
	       offspring[ i ] = 0;
	    
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = dis_two_component(i,j);
	    }
	    
	    int cmin = -1;
	    int hmin = -1;
	    num = 0;
	    int fm = -1;
	    for( i1 = 1; i1 <= BLK; i1++ )
	    {
	         cmin = -1;
	         hmin = -1;
	         fm = -1;
	         for( i2 = 1; i2 <= BLK; i2++ )
	         for( i3 = 1; i3 <= BLK; i3++ )
	         if( distwo[ i2 ][ i3 ] > fm )
	         {
	             fm = distwo[ i2 ][ i3 ];
	             cmin = i2;
	             hmin = i3;
	         }
	         
	         num = num + fm;
	         
	         for( i = 0; i <= BLK; i++ )
	         {
	              distwo[ cmin ][ i ] = 0; 
	              distwo[ i ][ hmin ] = 0;
	         }
	         
	         assign_value(cmin, hmin, i1);
	    }
	}
	
	void Select_P()
	{
	    p1 = randomInt( Psize );
	    p2 = randomInt( Psize );
	    while(p1 == p2)
	    {
	       p2 = randomInt( Psize );
	    }
	}
	
	int Max_f( )
	{
	    int i, j, k, l, m;
	    int kp = 0;
	    int fmax = 0;
	    for( i = 0; i < Psize; i++ )
	    {
	       if( fpop[ i ] > fmax )
	       {
	           fmax = fpop[ i ];
	           kp = i;
	       }
	    }
	     
	    return kp;
	}

	int com_pop_dis_off()
	{
	    int i, j, k, l, m;
	    l = -100;
	    for( i = 0; i < Psize; i++ )
	    {
	        m = com_distance(Pop[ i ],Sfsolution); 
	        if( m > l )
	           l = m;
	    }
	    
	    return l;
	}
	
	void up_date(int fm)
	{
	     int j;
	     int dl = Max_f( );
	     int dmin = com_pop_dis_off();
	     if( (fm < ff_best) || (dmin < 95) )
	     {
	         if( fm < fpop[ dl ] )
	         {            
	            fpop[ dl ] = fm;
	            for( j = 0; j < N_vtx; j++ )
	            {
	               Pop[ dl ][ j ] = Sfsolution[ j ]; 
	            }
	         }
	     }
	} 
	
	int check_bestsolution(int []cp, int ki)
	{
	     int  fft, i, k, l, m;
	     int num = 0;
	     
	     fft = 0;
	     for( i = 0; i < SN_b; i++ )
	         Snode_block[ i ] = cp[ i ];
         fft = Scheck_solution();       
           
         //System.out.println("");
         System.out.println( "fft = " + fft + " fpop = " + fpop[ ki ] );  
         //cout << "fft = " << fft << " fpop = " << fpop[ ki ] << endl;
	     
	     return fft;
	}
	
	void check_pop()
	{
	     int i, j;
	     for( i = 0; i < Psize; i++ )
	     {
	        check_bestsolution(Pop[ i ], i);  
	     }
	     for( i = 0; i < Psize; i++ )
	     {
	        for( j = 0; j < Psize; j++ )
	        	System.out.print( com_distance(Pop[ i ], Pop[ j ]) + " ");
	        System.out.println("");   
	        //	System.out.print( com_distance(Pop[ i ], Pop[ j ]) + " ");
	        //System.out.println("");
	     }   
	}
	
void initilize_offspring()
{
     int i, j, k, l, m;
     tcl = 0;
     
     for( i = 0; i < SN_b; i++ )
     {
         Snode_block[ i ] = 0;
         Snblock[ i ] = 0;  
     } 
         
     for( i = 0; i < SN_b; i++ )
     for( j = 0; j < SN_b; j++ )
         tabu_list[ i ][ j ] = 0; 
      
     Set_original();
     
     l = 0;    
     for( i = 0; i < N_vtx; i++ )
     if( (offspring[ i ] > 0) && (i != CN) )
     {
	      k = i;
	      tcl = offspring[ i ];  
          Snode_block[ k ] = tcl;
          Snblock[ tcl ]++;  
          l++;      
	 } 
	 
     //System.out.println("the common node l = " + l);
	 //cout << "the common node l = " << l << endl;
	 
	 for( i = 1; i <= BLK; i++ )
         Scolor_temp[ i ] = 8;       
         
     for( i = 0; i < 2; i++ )
     {
         while(true)
         {
             k = 1 + randomInt(BLK);
             if( (Scolor_temp[ k ] == 8) && (Snblock[ k ] <= 6) )
             {
                 Scolor_temp[ k ] = 6;
                 break;
             }    
         } 
     }    
     
     while(true)
     {     
         Sselect_all();
         if(Slen == 0)
            break;
         k = randomInt(Slen);
         k = Snode[ k ];
         while(true)
         {
             tcl = 1 + randomInt(BLK);
             if( Snblock[ tcl ] < Scolor_temp[ tcl ])
             {
                 break;
             }    
         }
         Snode_block[ k ] = tcl;
         Snblock[ tcl ]++;
         //cout << "i = " << i << " k = " << k << " color = " << node_color[ k ] << " tcl = " << tcl << " len = " << color[ tcl ] << endl;
     }
     
     //output();
     //getchar();
     //Soutput();
     
     /*for( i = 0; i < SN_b; i++ )
        cout << Snode_block[ i ] << " ";
     getchar(); */  
     
     for( i = 1; i <= BLK; i++ )
        Snblock[ i ] = 0;
     for( i = 0; i < SN_b; i++ )
     if(Snode_block[ i ] > 0)
     {
        k = Snode_block[ i ];  
        S_nd[ k ][ Snblock[ k ] ] = i;
        Saddress[ i ] = Snblock[ k ];
        Snblock[ k ]++;
        //cout << "i = " << i << "k = " << k << " address = " << Snblock[ k ] << endl;
     }
     
     /*for( i = 0; i < SN_b; i++ )
        cout << Saddress[ i ] << " ";
     cout << endl;   
     
     for( i = 1; i < 15; i++ )
     {
        for( j = 0; j < Snblock[ i ]; j++ )  
           cout << S_nd[ i ][ j ] << " ";
        cout << endl;    
     }   
     cout << endl; 
     for( i = 1; i < 15; i++ )
        cout << "i = " << i << " len = " << Snblock[ i ] << " limit = " << Scolor_temp[ i ] << endl;  */
     //getchar(); 
     
     //for( i = 1; i <= BLK; i++ )
     //	 System.out.print( Snblock[ i ] + " "); 
     //System.out.println(" "); 
     //   cout << Snblock[ i ] << " ";
     //cout << endl;    
}

void srepair()
{
     while(true)
     { 
        initilize_offspring();
        rough_optimize();
        Srp_comp_distance();
         
        if(fd > 0)
        {
           Stabu_repair(1000);
        }
        if(fd == 0)
           break;
     }
}

    int Scomp_cp_D1(int len)
    {
        int d, dmin;
        int i, j, k, l, m;
        int kmin = 0;
        dmin = 9999999;
        for( i = 0; i < len; i++ )
        {
             k = Scp_D[ i ];
             d = Sdis_o[ k ];
          
             for( j = 0; j < len; j++ )
             {
                 if( Scp_D[ j ] != k )
                 {
                      m = Scp_D[ j ];
                      d += Sdis_two[ m ][ k ];
                 } 
             }
             if( d < dmin )
             {
                 dmin = d;
                 kmin = k;
             }
          
        }
    
        return kmin;
    } 
    
    void Soutput()
    {
    	 int i, j, k, l, x1, y1;
    	 
    	 for( i = 0; i < N1; i++ )
    	 {	 
    	     for( j = 0; j < M1; j++ )
    	     {
    	    	 dd[ i ][ j ] = -3; 
    	     }
    	 }
    	 
    	 for( i = 0; i < SN_b; i++ )
    	 {
    		 x1 = CX[ i ][ 0 ];
    	     y1 = CX[ i ][ 1 ];
    	     if(i < CN)
    	       dd[ x1 ][ y1 ] = i;
    	     if(i > CN)
      	       dd[ x1 ][ y1 ] = i - 1;
    	 }
    	 for( i = 0; i < N1; i++ )
    	 {	 
    	     for( j = 0; j < M1; j++ )
    	     {
    	    	 if(dd[ i ][ j ] == -3)
    	    	    System.out.print("[   " + " ]"); 
    	    	 else if(dd[ i ][ j ] < 10)
    	    		System.out.print("[  " + dd[ i ][ j ] + " ]");
    	    	 else if(dd[ i ][ j ] < 100)
    	    		 System.out.print("[ " + dd[ i ][ j ] + " ]");
    	    	 else if(dd[ i ][ j ] < 110)
    	    		 System.out.print("[" + dd[ i ][ j ] + " ]");
    	     }
    	     System.out.println(" "); 
    	 }
    }
    
    void Soutput1()
    {
    	 int i, j, k, l, x1, y1;
    	 
    	 for( i = 0; i < N1; i++ )
    	 {	 
    	     for( j = 0; j < M1; j++ )
    	     {
    	    	 dd[ i ][ j ] = -3; 
    	     }
    	 }
    	 
    	 for( i = 0; i < SN_b; i++ )
    	 {
    		 x1 = CX[ i ][ 0 ];
    	     y1 = CX[ i ][ 1 ];
    	     dd[ x1 ][ y1 ] = Snode_block[ i ];
    	 }
    	 for( i = 0; i < N1; i++ )
    	 {	 
    	     for( j = 0; j < M1; j++ )
    	     {
    	    	 if(dd[ i ][ j ] == -3)
    	    		 System.out.print("[   " + " ]"); 
    	    	 else if(dd[ i ][ j ] == -1)
    	    		 System.out.print("[  *" + " ]"); 
    	         else if(dd[ i ][ j ] < 10)
     	    		System.out.print("[  " + dd[ i ][ j ] + " ]");
    	    	 else if(dd[ i ][ j ] == 10)
     	    	    System.out.print("[  a" + " ]"); 
    	    	 else if(dd[ i ][ j ] == 11)
    	    		 System.out.print("[  b" + " ]");
    	    	 else if(dd[ i ][ j ] == 12)
    	    		 System.out.print("[  c" + " ]");
    	    	 else if(dd[ i ][ j ] == 13)
    	    		 System.out.print("[  d" + " ]");
    	    	 else if(dd[ i ][ j ] == 14)
    	    		 System.out.print("[  e" + " ]");
    	     }
    	     System.out.println(" "); 
    	 }
    }
    
    void set_edge(int len)
    {
    	int i, j, k, l, m, t;
    	for( i = 0; i < SN_b; i++ )
    	{	
    		is_set[ i ] = 0;
    		is_flag[ i ] = 0;
    	}
    	for( j = 0; j < len; j++ )
    	{	
            k = Scp_D[ j ] ;
            is_flag[ k ] = 1;
            if(Gedge[ k ] == CN)
            	is_set[ k ] = 1;
    	}
    	
    	while(true)
    	{
    		l = 0;
    		for( j = 0; j < len; j++ )
        	{	
                k = Scp_D[ j ] ;
                if(Gedge[ k ] == -6)
                	l++;
        	}
    		if(l == 0)
    			return;
    		for( j = 0; j < len; j++ )
        	{	
                k = Scp_D[ j ] ;
                if(is_set[ k ] == 1)
                {
                	for( t = 0; t < Sadjaclen[ k ]; t++ )
    	            {
    	                m =  SadjacMatrix[ k ][ t ]; 
    	                if( (is_set[ m ] == 0) && (is_flag[ m ] == 1) )
    	                {
    	                	Gedge[ m ] = k;
    	                	is_set[ m ] = 1;
    	                }
    	            }  
                }
        	}
    	}
    }

    int check_final_solution()
    {
    	 int  fft, i, j, k, l, m;
	     int num = 0;
	     
	     Soutput();
	     
	     fft = 0;
	     for( i = 0; i < SN_b; i++ )
	         Snode_block[ i ] = Rbest[ i ];
	     Soutput1();
         fft = Scheck_solution();    
         ff_best =(int)(ff_best*0.0248);
         fft =(int)(fft*0.0248);
          
         //System.out.println("");
         System.out.println( "In check_final_solution fft = " + fft + " ff_best = " + ff_best );  
         //cout << "fft = " << fft << " fpop = " << fpop[ ki ] << endl;
         
         for( i = 0; i < SN_b; i++ )
        	 Gedge[ i ] = -1;
         
         for( i = 0; i < 40; i++ )
             alen[ i ] = 0;
          for( i = 0; i < SN_b; i++ )
          if(Snode_block[ i ] >= 0)
          {
             bb[ Snode_block[ i ] ][ alen[ Snode_block[ i ] ]++ ] = i;
          }
                 
            
          for( i = 1; i <= BLK; i++ )
          {
             for( j = 0; j < alen[ i ]; j++ )
               Scp_D[ j ] = bb[ i ][ j ];
             k = Scomp_cp_D1( alen[ i ] );
             
             Gedge[ k ] = CN;
             
             for( j = 0; j < alen[ i ]; j++ )
             if( bb[ i ][ j ] != k)
             {
            	 Gedge[ bb[ i ][ j ] ] = -6;
             }
             
             for( j = 0; j < alen[ i ]; j++ )
                 Scp_D[ j ] = bb[ i ][ j ];
             set_edge(alen[ i ]);
             //ff += d;
             //cout << "d = " << d << " dreal = " << Sdisg[ i ] << endl;    
          } 
		  
		  for( i = 0; i < SN_b; i++ )
		  if(Gedge[ i ] == CN)
		      Gedge[ i ] = -1;
			  
	      for( i = CN; i < SN_b - 1; i++ )	
              Gedge[ i ] = Gedge[ i + 1 ];	
 
          for( i = 0; i < SN_b; i++ )
		      if(Gedge[ i ] > CN) 
			  Gedge[ i ] = Gedge[ i ] - 1;
          
          for( i = 0; i < SN_b - 1; i++ )
        	  System.out.print(Gedge[ i ] + " ");
          System.out.println(" ");
	      return fft;
    }

    int hybrid_search(int generation)
	{
	     int i, j, f1;
	     
	     Ini_Pop();
	     check_pop();
	     //getchar(); 
	     for( i = 0; i < generation; i++ )
	     {
	        Select_P();
	        cross_over(Pop[ p1 ], Pop[ p2 ]);
	        //initilize_offspring();
	        srepair();
	        //inisolution();
	        //f1 = tabu_one_move(search_depth);  
	        Scomp_distance();
            f1 = Stabu_search( search_depth );
            System.out.println("In hybrid_search one run  of tabu is finished i = " + i + " f1 = " + f1 + " ff_best = " + ff_best); 
            //cout << "In hybrid_search one run  of tabu is finished f1 = " << f1 << " ff_best = " << ff_best << endl;
	        //f1 = tabu_search(search_depth);
	           
	        up_date(f1);
	        
	        if(f1 < ff_best)
	        {	
	          ff_best = f1;
	          for( j = 0; j < N_vtx; j++ )
	          {
	             Rbest[ j ] = Sfsolution[ j ]; 
	          }
	        }
	        
	        //check_pop();
	        //getchar();
	        /*System.out.println( "gen = " + i + " one run f1 = " + f1 + " ffbest = " + ff_best ); */ 
	        
	        /*if(i % 10 == 0)
	           check_pop();*/
	     }
	     return ff_best;
	}

///////////////////////////////////////////////////////////////////////////////////////////
    
    public static void  main(String args[]) throws FileNotFoundException{
    	 hueristic i = new hueristic();
    	 
    	 i.File_Name = "E:/study in hust/luo solar/code/109/r5.txt.out";
         int gbest = 999999999;
         int j, g; 
         
         i.Initializing();
         i.construct_sub_graph();
         i.N_vtx = i.SN_b;
         //BLK = 16;
         i.search_depth = 10000;
         //Set_original();
         
         i.tabu_len = 10;
         
         //Ini_Pop();
         //check_pop();
         i.hybrid_search(3);
         i.check_final_solution();
    }
}
