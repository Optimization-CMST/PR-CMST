package Heuristic_UB;

import Common.Data;
import Helper.Check;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Ub {
	
	public static void get_column(ArrayList<Integer> column, ArrayList<Integer> place, int father, int[] tree, int n){
		for(int i = 0; i < n; i++){
			if(tree[i] == column.get(father)){
				column.add(i);
				place.add(father);
				get_column(column, place, column.size() - 1, tree, n);
			}
		}
	}
	
	public static double get_ub(Data data, String path, ArrayList<ArrayList<Integer>> trees) throws FileNotFoundException{
   	 	hueristic2 i = new hueristic2();
	 
   	 	i.File_Name = path;
   	 	
        i.Initializing();
        i.construct_sub_graph();
        i.N_vtx = i.SN_b;
        //BLK = 16;
        i.search_depth = 10000;
        //Set_original();
        
        i.tabu_len = 10;
        
        //Ini_Pop();
        //check_pop();
        double lbest = i.hybrid_search(3);
        i.check_final_solution();
		System.out.println("Gedge.length: " + i.Gedge.length);
		for(int j = 0; j < data.tot; j++){
			System.out.print("(" + j + "," + i.Gedge[j] + ") ");
		}
		System.out.println();
		int[][] pseudo_index_map = new int[data.tot][data.tot];
		int iter = 0;
		for(int k = 0; k < data.p; k++){
			for(int j = 0; j < data.m; j++){
				if(data.panel[k][j]){
					pseudo_index_map[k][j] = iter;
					iter++;
				}
			}
		}
		int[] map = new int[data.tot];
		iter = 0;
		for(int j = data.p - 1; j >= 0; j--){
			for(int k = 0; k < data.m; k++){
				if(data.panel[j][k]){
					map[iter++] = pseudo_index_map[j][k];
				}
			}
		}
		for(int j = 0; j < data.tot; j++){
			System.out.print("(" + j + "," + map[j] + ")");
		}
		System.out.println();
		int[] edge = new int[data.tot];
		for(int j = 0; j < data.tot; j++){
			if(i.Gedge[j] >= 0)
				edge[map[j]] = map[i.Gedge[j]];
			else
				edge[map[j]] = -1;
		}
		for(int j = 0; j < data.tot; j++){
			System.out.print("(" + j + "," + edge[j] + ")");
		}
		System.out.println();
		for(int j = 0; j < data.tot; j++){
			if(edge[j] == -1){
				ArrayList<Integer> temp_column = new ArrayList<Integer>();
				ArrayList<Integer> temp_place = new ArrayList<Integer>();
				temp_column.add(j);
				temp_place.add(-1);
				get_column(temp_column, temp_place, 0, edge, data.tot);
				ArrayList<Integer> column = new ArrayList<Integer>();
				column.add(temp_column.size());
				for(int k = 0; k < temp_column.size(); k++)
					column.add(temp_column.get(k)+1);
				for(int k = 0; k < temp_place.size(); k++){
					if(k == 0)
						column.add(temp_place.get(k));
					else
						column.add(temp_place.get(k) + 1);
				}
				//System.out.println(column);
				Check.check_column(data, column);
				trees.add(column);
			}
		}
		//naive cost
		double cost = 0.0;
		for(int j = 0; j < data.tot; j++){
			if(i.Gedge[j] == -1){
				cost += i.Sdis_o[j];
			}
			else{
				int k  = j;
				while(i.Gedge[k] != -1){
					cost += i.Srp_com_distwo(k, i.Gedge[k]);
					k = i.Gedge[k];
				}
			}
		}
		System.out.println("niave cost: " + cost);
		return lbest;
	}
}
