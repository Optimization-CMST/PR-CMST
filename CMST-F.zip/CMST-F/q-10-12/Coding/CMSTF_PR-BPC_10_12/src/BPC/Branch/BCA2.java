package BPC.Branch;

import BPC.SearchTree.Node;
import Common.*;
import BPC.LP.*;
import Helper.*;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBVar;

import java.util.*;

//branch on whether a panel is a root
public class BCA2 {
    public Data data;
    public int id1;
    public int id2;
    public Node left_node;
    public Node right_node;
    public double av;
    public double left_obj;
    public double right_obj;
    public ArrayList<ArrayList<Integer>> left_set;
    public ArrayList<ArrayList<Integer>> right_set;
    public double thresh_hold;
    public double max_value;

    public BCA2(Data d){
        data = d;
    }
	/*
	public void fraction_root(LP lp, boolean[] forbid, boolean dual_test) throws IloException{
		id1 = id2 = -1;
		double min_cost = Double.MAX_VALUE;
		double max_dist = 0.0;
		double thresh_hold = 0.01;
		while(id1 == -1 && id2 == -1 && thresh_hold < 1.0){
			for(int i = 0; i < data.n + 1; i++){
				for(int j = 0; j < data.n + 1; j++){
					if(i == j || forbid[j])
						continue;
					if(Help.is_fractional(lp.arc_map[i][j]) == false)
						continue;
					double fra_cost = Help.frac_cost(lp.arc_map[i][j]);
					if(fra_cost > thresh_hold)
						continue;
					if(dual_test){
						left_modify_lp(lp, i, j);
						if(lp.cplex.solve() == false || lp.branch_dual() == false){
							left_restore_lp(lp, i, j);
							continue;
						}
						left_restore_lp(lp, i, j);
						right_modify_lp(lp, i, j);
						if(lp.cplex.solve() == false || lp.branch_dual() == false){
							right_restore_lp(lp, i, j);
							continue;
						}
						right_restore_lp(lp, i, j);
					}

					if(data.d[i][j] > max_dist){
						min_cost = fra_cost;
						max_dist = data.d[i][j];
						id1 = i;
						id2 = j;
						av = lp.arc_map[i][j];
					}
				}
			}
			thresh_hold += 0.01;
		}
	}
	*/

    public boolean select(RMP lp, double[][][][] map) throws GRBException {
        double ocost = lp.cost;
        //compute change cost
        double[][][] left_cost = new double[data.p][data.m][4];
        double[][][] right_cost = new double[data.p][data.m][4];
        ArrayList<ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>> left_matrix = new ArrayList<ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>>();
        ArrayList<ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>> right_matrix = new ArrayList<ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>>();
        for(int i = 0; i < data.p; i++){
            left_matrix.add(new ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>());
            right_matrix.add(new ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>());
            for(int j = 0; j < data.m; j++){
                left_matrix.get(i).add(new ArrayList<ArrayList<ArrayList<Integer>>>());
                right_matrix.get(i).add(new ArrayList<ArrayList<ArrayList<Integer>>>());
                for(int k = 0; k < 4; k++){
                    left_matrix.get(i).get(j).add(new ArrayList<ArrayList<Integer>>());
                    right_matrix.get(i).get(j).add(new ArrayList<ArrayList<Integer>>());
                }
            }
        }
        thresh_hold = 1000;
        for(int i = 0; i < data.p; i++){
            for(int j = 0; j < data.m; j++){
                if(data.panel[i][j] == false)
                    continue;
                int iid = data.index_map[i][j];
                for(int k = 0; k < 4; k++){
                    int y = -1;
                    int x = -1;
                    if(k == 0){
                        y = i - 1;
                        x = j;
                    }
                    else if(k == 1){
                        y = i;
                        x = j - 1;
                    }
                    else if(k == 2){
                        y = i;
                        x = j + 1;
                    }
                    else{
                        y = i + 1;
                        x = j;
                    }
                    if(y < 0 || y >= data.p || x < 0 || x >= data.m || data.panel[y][x] == false)
                        continue;
                    if(i == j || Help.frac_cost(map[i][j][y][x]) > 0.1)
                        continue;
                    int jid = data.index_map[y][x];
                    //modify the lp
                    double lobj = -1e10;
                    double robj = -1e10;
                    ArrayList<ArrayList<Integer>> lset = new ArrayList<ArrayList<Integer>>();
                    ArrayList<ArrayList<Integer>> rset = new ArrayList<ArrayList<Integer>>();
                    left_modify_lp(lp, iid, jid);
                    lp.model.update();
                    lp.model.optimize();
                    int status = lp.model.get(GRB.IntAttr.Status);
                    if(status == GRB.Status.OPTIMAL){
                        lp.set_value();
                        lobj = lp.model.get(GRB.DoubleAttr.ObjVal);
                        lp.get_columns(lset);
                    }
                    left_restore_lp(lp, iid, jid);
                    if(lobj - ocost < thresh_hold)
                        continue;
                    right_modify_lp(lp, iid, jid);
                    lp.model.update();
                    lp.model.optimize();
                    status = lp.model.get(GRB.IntAttr.Status);
                    if(status == GRB.Status.OPTIMAL){
                        lp.set_value();
                        robj = lp.model.get(GRB.DoubleAttr.ObjVal);
                        lp.get_columns(rset);
                    }
                    right_restore_lp(lp, iid, jid);
                    if(robj - ocost < thresh_hold)
                        continue;
                    left_cost[i][j][k] = lobj;
                    right_cost[i][j][k] = robj;
                    left_matrix.get(i).get(j).set(k, lset);
                    right_matrix.get(i).get(j).set(k, rset);
                }
            }
        }
        //select the arcs
        thresh_hold = 10000;
        max_value = 0.0;
        while(thresh_hold > 100){
            for(int i = 0; i < data.p; i++){
                for(int j = 0; j < data.m; j++){
                    if(data.panel[i][j] == false)
                        continue;
                    for(int k = 0; k < 4; k++){
                        int y = -1;
                        int x = -1;
                        if(k == 0){
                            y = i - 1;
                            x = j;
                        }
                        else if(k == 1){
                            y = i;
                            x = j - 1;
                        }
                        else if(k == 2){
                            y = i;
                            x = j + 1;
                        }
                        else{
                            y = i + 1;
                            x = j;
                        }
                        if(y < 0 || y >= data.p || x < 0 || x >= data.m || data.panel[y][x] == false)
                            continue;
                        if(Help.frac_cost(map[i][j][y][x]) > 0.1)
                            continue;
                        //modify the lp
                        double lobj = left_cost[i][j][k];
                        double robj = right_cost[i][j][k];
                        if(lobj - ocost < thresh_hold)
                            continue;
                        if(robj - ocost < thresh_hold)
                            continue;
                        ArrayList<ArrayList<Integer>> lset = left_matrix.get(i).get(j).get(k);
                        ArrayList<ArrayList<Integer>> rset = right_matrix.get(i).get(j).get(k);
                        System.out.println(i + "," + j + "," + lobj + "," + robj + "," + map[i][j][y][x]);
                        if(lobj + robj > max_value){
                            max_value = lobj + robj;
                            id1 = data.index_map[i][j];
                            id2 = data.index_map[y][x];
                            av = map[i][j][y][x];
                            left_obj = lobj;
                            right_obj = robj;
                            left_set = lset;
                            right_set = rset;
                        }
                    }
                }
            }
            thresh_hold -= 1000;
        }

        lp.cost = ocost;
        if(max_value < 1e-1)
            return false;
        else
            return true;
    }

    public void left_modify_lp(RMP lp, int id1, int id2) throws GRBException {
        ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
        for(int i = 0; i < zero_set.size(); i++){
            GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
            var.set(GRB.DoubleAttr.UB, 0);
        }
    }

    public void left_restore_lp(RMP lp, int id1, int id2) throws GRBException {
        ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
        for(int i = 0; i < zero_set.size(); i++){
            GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
            var.set(GRB.DoubleAttr.UB, 1);
        }
    }

    public void right_modify_lp(RMP lp, int id1, int id2) throws GRBException {
        for(int i = 0; i < data.tot + 1; i++){
            if(i != id2){
                ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
                for(int j = 0; j < zero_set.size(); j++){
                    GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
                    var.set(GRB.DoubleAttr.UB, 0);
                }
            }
        }
    }

    public void right_restore_lp(RMP lp, int id1, int id2) throws GRBException {
        for(int i = 0; i < data.tot + 1; i++){
            if(i != id2){
                ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
                for(int j = 0; j < zero_set.size(); j++){
                    GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
                    var.set(GRB.DoubleAttr.UB, 1);
                }
            }
        }
    }

    public void get_cuts(RMP lp, Node node){
        node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
        node.sr_cuts = new ArrayList<ArrayList<Integer>>();
        for(int i = 0; i < lp.useful_sr.size(); i++){
            ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
            node.sr_cuts.add((ArrayList<Integer>) cut.clone());
        }
    }

    public boolean branch(RMP lp) throws GRBException {
        double[][][][] map = new double[data.p][data.m][data.p][data.m];
        for(int i = 0; i < data.p; i++){
            for(int j = 0; j < data.m; j++){
                for(int k = 0; k < data.p; k++){
                    for(int h = 0; h < data.m; h++)
                        map[i][j][k][h] = lp.arc_map[i][j][k][h];
                }
            }
        }
        if(select(lp, map) == false){
            for(int i = 0; i < data.p; i++){
                for(int j = 0; j < data.m; j++){
                    for(int k = 0; k < data.p; k++){
                        for(int h = 0; h < data.m; h++)
                            lp.arc_map[i][j][k][h] = map[i][j][k][h];
                    }
                }
            }
            return false;
        }
        left_node = lp.node;
        right_node = lp.node.duplicate();
        left_node.sudo_cost = lp.cost;
        right_node.sudo_cost = lp.cost;
        left_node.depth ++;
        right_node.depth = left_node.depth;
        get_cuts(lp, left_node);
        get_cuts(lp, right_node);
        //--------branch on root------------------------
        //change the direction of the branching arc
        left_node.feasible_arc[id1][id2] = -1;
        for(int i = 0; i < data.tot + 1; i++){
            if(i != id2){
                right_node.feasible_arc[id1][i] = -1;
            }
        }
        right_node.feasible_arc[id1][id2] = 1;
        //--------get the left route set and the right route set-----------------
        left_node.column_set = left_set;
        right_node.column_set = right_set;
        return true;
    }
}
