package BPC.Branch;

import BPC.SearchTree.Node;
import Common.*;
import BPC.LP.*;
import Helper.*;
import com.gurobi.gurobi.GRBException;

import java.util.*;

//branch on whether a panel is a root
public class BCA {
    public Data data;
    public Node left_node;
    public Node right_node;
    public int id1;
    public int id2;
    public double av;
    public double left_obj;
    public double right_obj;
    public ArrayList<ArrayList<Integer>> left_set;
    public ArrayList<ArrayList<Integer>> right_set;
    public double thresh_hold = 0.5;
    public double max_value;

    public BCA(Data d){
        data = d;
    }
    public void fraction_root(RMP lp){
        id1 = id2 = -1;
        double min_cost = Double.MAX_VALUE;
        for(int i = 0; i < data.p; i++){
            for(int j = 0; j < data.m; j++){
                if(data.panel[i][j] == false)
                    continue;
                int iid = data.index_map[i][j];
                for(int k = 0; k < 4; k++){
                    int y = -1;
                    int x = -1;
                    if(k == 0){
                        y = i - 1;
                        x = j;
                    }
                    else if(k == 1){
                        y = i;
                        x = j - 1;
                    }
                    else if(k == 2){
                        y = i;
                        x = j + 1;
                    }
                    else{
                        y = i + 1;
                        x = j;
                    }
                    if(y < 0 || y >= data.p || x < 0 || x >= data.m || data.panel[y][x] == false)
                        continue;
                    if(Help.is_fractional(lp.arc_map[i][j][y][x]) == false)
                        continue;
                    int jid = data.index_map[y][x];
                    double fra_cost = Help.frac_cost(lp.arc_map[i][j][y][x]);
                    if(fra_cost < min_cost){
                        min_cost = fra_cost;
                        id1 = iid;
                        id2 = jid;
                        av = lp.arc_map[i][j][y][x];
                    }
                }
            }
        }
    }

    public void get_cuts(RMP lp, Node node){
        node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
        node.sr_cuts = new ArrayList<ArrayList<Integer>>();
        for(int i = 0; i < lp.useful_sr.size(); i++){
            ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
            node.sr_cuts.add((ArrayList<Integer>) cut.clone());
        }
    }

    public boolean branch(RMP lp) throws GRBException {
        fraction_root(lp);
        left_node = lp.node;
        right_node = lp.node.duplicate();
        left_node.sudo_cost = lp.cost;
        right_node.sudo_cost = lp.cost;
        left_node.depth++;
        right_node.depth = left_node.depth;
        get_cuts(lp, left_node);
        get_cuts(lp, right_node);
        //--------branch on root------------------------
        //change the direction of the branching arc
        left_node.feasible_arc[id1][id2] = -1;
        for(int i = 0; i < data.tot + 1; i++){
            if(i != id2)
                right_node.feasible_arc[id1][i] = -1;
        }
        right_node.feasible_arc[id1][id2] = 1;
        //--------get the left route set and the right route set-----------------
        BigMA bigm = new BigMA(data);
        left_node.column_set = bigm.get_left_routeset(lp, left_node, id1, id2);
        right_node.column_set = bigm.get_right_routeset(lp, right_node, id1, id2);
        if(left_node.column_set == null){
            left_node.clear();
            left_node = null;
        }
        if(right_node.column_set == null){
            right_node.clear();
            right_node = null;
        }
        return true;
    }
}
