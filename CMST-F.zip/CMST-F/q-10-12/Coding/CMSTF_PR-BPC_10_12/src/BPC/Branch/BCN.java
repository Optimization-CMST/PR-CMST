package BPC.Branch;

import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRBException;

import java.util.ArrayList;

//branch on whether a panel is a root
public class BCN {
	public Data data;
	public int id1;
	public int id2;
	public double nv;
	public Node left_node;
	public Node right_node;
	
	public BCN(Data d){
		data = d;
	}
	
	
	public void fraction_root(RMP lp){
		id1 = id2 = -1;
		double min_cost = 0.1;
		for(int i = 0; i < data.p; i++){
			for(int j = 0; j < data.m; j++){
				if(Help.is_fractional(lp.inverter_map[i][j]) == false)
					continue;
				double fra_cost = Help.frac_cost(lp.inverter_map[i][j]);
				if(fra_cost < min_cost){
					min_cost = fra_cost;
					id1 = i;
					id2 = j;
					nv = lp.inverter_map[i][j];
				}
			}
		}
	}
	
	public void get_cuts(RMP lp, Node node){
		node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
		node.sr_cuts = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < lp.useful_sr.size(); i++){
			ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
			node.sr_cuts.add((ArrayList<Integer>) cut.clone());
		}
	}
	
	
	public boolean branch(RMP lp) throws GRBException {
		fraction_root(lp);
		if(true)
			return false;
		if(id1 == -1 || id2 == -1)
			return false;
		left_node = lp.node;
		right_node = lp.node.duplicate();
		left_node.sudo_cost = lp.cost;
		right_node.sudo_cost = lp.cost;
		left_node.depth++;
		right_node.depth = left_node.depth;
		get_cuts(lp, left_node);
		get_cuts(lp, right_node);
		//--------branch on root------------------------
		int index = data.index_map[id1][id2];
		left_node.feasible_arc[index][0] = -1;
		for(int i = 1; i < data.tot + 1; i++){
			right_node.feasible_arc[index][i] = -1;
		}
		//--------get the left route set and the right route set-----------------
		BigMN bigm = new BigMN(data);
		left_node.column_set = bigm.get_left_routeset(lp, left_node, id1, id2);
		right_node.column_set = bigm.get_right_routeset(lp, right_node, id1, id2);
		if(left_node.column_set == null){
			System.out.println("bcn left node fail");
			//System.exit(0);
			left_node.clear();
			left_node = null;
		}		
		if(right_node.column_set == null){
			System.out.println("bcn right node fail");
			//System.exit(0);
			right_node.clear();
			right_node = null;
		}
		return true;
	}
}
