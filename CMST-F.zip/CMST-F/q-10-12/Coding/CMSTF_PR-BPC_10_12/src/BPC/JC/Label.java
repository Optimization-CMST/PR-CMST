package BPC.JC;
import BPC.LP.RMP;

import java.util.ArrayList;

public class Label {

	public int id;
	public int q;
	public double c;
	public int k;
	public double[] c_comp;
	public boolean[] dom;
	public int min_subQ;
	public long S1; //the set of vertics that is connected to the root node
	public long S2;
	public long S3;
	public long S4;
	public long T1;
	public long T2;
	public long T3;
	public long T4;
	public long V1; //the set of panels that has been covered
	public long V2;
	public long V3;
	public long V4;
	public long N1; //the set of panels that has been covered more than once
	public long N2;
	public long N3;
	public long N4;
	public Label child1;
	public Label child2;
	public Label last_layer;
	public int arc1; //0: no arc, 1: child->father 2: father->child
	public int arc2;
	public int root;
	//to handle the sr cuts
	public ArrayList<Integer> sr_set;      // 这里面应该存储的是访问过一次的负的SR 索引
	public double tsr;
	public double tolerance = 1e-6;
	
	public boolean dominate(RMP lp, long C1, long C2, long C3, long C4, Label label, boolean is_relax){
		if(greater_than(c, label.c))
			return false;
		if(q > label.q)
			return false;
		if (is_relax == false) {
			if((V1 & label.V1 & C1) != (V1 & C1))
				return false;
			if((V2 & label.V2 & C2) != (V2 & C2))
				return false;
			if((V3 & label.V3 & C3) != (V3 & C3))
				return false;
			if((V4 & label.V4 & C4) != (V4 & C4))
				return false;
		}
		if (!greater_than(c - tsr, label.c))               // c-tsr <= label.c
			return true;
		double sr_penalty = 0;
		double neg_sr_penalty = 0;
		if(lp.is_sr_add){
			for(int i = 0; i < sr_set.size(); i++){
				int s1 = sr_set.get(i);
				int s2 = label.sr_set.get(i);
				sr_penalty += lp.sr_comp[i][s1 & (~s2)];
				neg_sr_penalty += lp.sr_comp[i][s1 & s2];
				if(greater_than(c - sr_penalty, label.c))       // c - sr_penalty > label.c
					return false;
				else if(!greater_than(c - tsr + neg_sr_penalty, label.c))   //c - tsr + neg_sr_penalty <= label.c
					return true;
			}
		}
		if (greater_than(c - sr_penalty, label.c))
			return false;
		return true;
	}


	private boolean greater_than(double v1, double v2){
		if (v1 > v2 && Math.abs(v1 - v2) > tolerance)
			return true;
		else
			return false;
	}

	public int find_index (int capacity, int outflow) {
		if (capacity == 1)
			return outflow - 6;
		else if (capacity == 2)
			return outflow - 5;
		else if (capacity == 3)
			return outflow - 4;
		else if (capacity == 4)
			return outflow - 3;
		else if (capacity == 5){
			if (outflow < 4)
				return -1;
			else
				return capacity - 4;
		}
		return -1;
	}
	public boolean check_dominated() {
		for (int i = 0; i < dom.length; i++){
			if (dom[i] == false)
				return false;
		}
		return true;
	}
}
