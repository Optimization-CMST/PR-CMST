package BPC.GC;

import BPC.LP.RMP;
import Common.Data;

public class DP {

	public Data data;
	
	public DP(Data d){
		data = d;
	}

	public void run(RMP lp, int type, double[][][] FT, double[][][] BT){
		int cap = data.size[type];
		//initialize the states
		for(int i = 1; i < data.tot + 1; i++){
			int iy = data.y_map[i];
			int ix = data.x_map[i];
			for(int k = 0; k < 4; k++){
				//forward state
				FT[i][k][0] = 1e15;
				FT[i][k][1] = -lp.mu[iy][ix];
				//backward state
				BT[i][k][0] = 1e15;
				BT[i][k][1] = data.f[iy][ix] - lp.dual_arc[i][0] - lp.mu[iy][ix] - lp.nu[type];
			}
		}
		//dp
		for(int q = 2; q <= cap; q++){
			for(int i = 1; i < data.tot + 1; i++){
				for(int k = 0; k < 4; k++){
					FT[i][k][q] = 1e15;
					BT[i][k][q] = 1e15;
					//decision 1, from the k - 1 state
					if(k - 1 >= 0){
						if(FT[i][k - 1][q] < FT[i][k][q]){
							FT[i][k][q] = FT[i][k - 1][q];
						}
						if(BT[i][k - 1][q] < BT[i][k][q]){
							BT[i][k][q] = BT[i][k - 1][q];
						}
					}
					int iy = data.y_map[i];
					int ix = data.x_map[i];
					int jy = -1;
					int jx = -1;
					if(k == 0){
						jy = iy - 1;
						jx = ix;
					}
					else if(k == 1){
						jy = iy;
						jx = ix - 1;
					}
					else if(k == 2){
						jy = iy;
						jx = ix + 1;
					}
					else if(k == 3){
						jy = iy + 1;
						jx = ix;
					}
					if(jy >= 0 && jy < data.p && jx >= 0 && jx < data.m && data.panel[jy][jx]){
						int jid = data.index_map[jy][jx];
						//decision 2, all from the next customer
						if(lp.node.feasible_arc[jid][i] != -1){
							double cost2 = (q - 1) * data.d[jid][i] - lp.dual_arc[jid][i] - lp.mu[iy][ix] + FT[jid][3][q - 1];
							if(cost2 < FT[i][k][q]){
								FT[i][k][q] = cost2;
							}
						}

						if(lp.node.feasible_arc[i][jid] != -1){
							double cost2 = (cap - q + 1) * data.d[i][jid] - lp.dual_arc[i][jid]  - lp.mu[iy][ix] + BT[jid][3][q - 1];
							if(cost2 < BT[i][k][q]){
								BT[i][k][q] = cost2;
							}
						}
						if(k - 1 >= 0){
							//decision 3, from two labels
							if(lp.node.feasible_arc[jid][i] != -1){
								for(int q2 = 1; q2 <= q - 2; q2++){
									double cost3 = FT[i][k - 1][q - q2] + q2 * data.d[jid][i] - lp.dual_arc[jid][i] + FT[jid][3][q2];
									if(cost3 < FT[i][k][q]){
										FT[i][k][q] = cost3;
									}
								}
								for(int q2 = 1; q2 <= q - 2; q2++){
									double cost3 = BT[i][k - 1][q - q2] + q2 * data.d[jid][i] - lp.dual_arc[jid][i] + FT[jid][3][q2];
									if(cost3 < BT[i][k][q]){
										BT[i][k][q] = cost3;
									}
								}
							}

							if(lp.node.feasible_arc[i][jid] != -1){
								//double dist = data.d[data.index_map[i][j]][data.index_map[jy][jx]];
								for(int q2 = 1; q2 <= q - 2; q2++){
									double cost3 = FT[i][k - 1][q - q2] + (cap - q2) * data.d[i][jid] - lp.dual_arc[i][jid] + BT[jid][3][q2];
									if(cost3 < BT[i][k][q]){
										BT[i][k][q] = cost3;
									}
								}
							}
						}
					}
					if(k == 3 && lp.node.feasible_arc[i][0] != -1){
						//decision 4 for the backward extension
						double cost4 = FT[i][k][q] + data.f[iy][ix] - lp.dual_arc[i][0] - lp.nu[type];
						if(cost4 < BT[i][k][q]){
							BT[i][k][q] = cost4;
						}
					}
				}
			}
		}
	}
	
	public void get_inner_bound(RMP lp, int type, double[][] fb, double[][] bb){
		int cap = data.size[type];
		for(int i = 0; i < data.tot + 1; i++){
			for(int q = 0; q <= cap; q++){
				fb[i][q] = 1e10;
			}
		}
		for(int i = 0; i < data.tot + 1; i++){
			bb[i][0] = 0;
			for(int q = 0; q <= cap; q++){
				bb[i][q] = 1e10;
			}
		}
		double[][][] FT = new double[data.tot + 1][4][cap + 1];
		double[][][] BT = new double[data.tot + 1][4][cap + 1];
		run(lp, type, FT, BT);
		for(int i = 1; i < data.tot + 1; i++){
			for(int q = 1; q < cap; q++){
				double cost = BT[i][3][cap - q];
				if(cost < fb[i][q]){
					fb[i][q] = cost;
				}
			}
		}

		for(int i = 1; i < data.tot + 1; i++){
			int iy = data.y_map[i];
			int ix = data.x_map[i];
			for(int q = 1; q < cap; q++){
				double cost = FT[i][3][q + 1] + lp.mu[iy][ix];
				if(cost < bb[i][q]){
					bb[i][q] = cost;
				}
			}
		}
	}

	public void get_bound(RMP lp, double[][] fb, double[][] bb) {
		double[][] fb_1 = new double[data.tot + 1][data.size[0] + 1];
		double[][] bb_1 = new double[data.tot + 1][data.size[0] + 1];
		double[][] fb_2 = new double[data.tot + 1][data.size[1] + 1];
		double[][] bb_2 = new double[data.tot + 1][data.size[1] + 1];
		get_inner_bound(lp, 0, fb_1, bb_1);
		get_inner_bound(lp, 1, fb_2, bb_2);
		for (int i = 1; i < data.tot + 1; i++)
			for (int q = 1; q < data.size[1] + 1; q++){
				bb[i][q] = bb_2[i][q];
			}
		for (int i = 1; i < data.tot + 1; i++)
			for (int q = 1; q < data.size[0] + 1; q ++){
				if (fb_1[i][q] < fb_2[i][q]){
					fb_2[i][q] = fb_1[i][q];
				}
			}
		for (int i = 1; i < data.tot + 1; i++)
			for (int q = 1; q < data.size[1] + 1; q++){
				fb[i][q] = fb_2[i][q];
			}
	}
}
