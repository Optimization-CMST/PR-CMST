package BPC.Cut;

import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;

public class SRSep {
	public Data data;
	public ArrayList<ArrayList<Integer>> retS;
	
	public SRSep(Data d){
		data = d;
	}
	
	public void solve(RMP lp, int size){
		retS = new ArrayList<ArrayList<Integer>>();
		ArrayList<Double> values = new ArrayList<Double>();
		//-----------construct the map--------------------------------------------
		int[][] col_map = new int[lp.active_set.size()][data.tot+1];
		for(int i = 0; i < lp.active_set.size(); i++){
			ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
			for(int j = 1; j <= column.get(0); j++){
				col_map[i][column.get(j)]++;
			}
		}
		//----------enumerate all the three node set------------------------------
		for(int i = 1; i < data.tot + 1; i++){
			for(int j = i + 1; j < data.tot + 1; j++){
				for(int k = j + 1; k < data.tot + 1; k++){
					double left = 0.0;
					for(int h = 0; h < lp.active_value.size(); h++){
						int count = col_map[h][i] + col_map[h][j] + col_map[h][k];
						left += Math.floor(count / 2.0) * lp.active_value.get(h);
					}
					if(left > 1.1){
						ArrayList<Integer> cut = new ArrayList<Integer>();
						cut.add(i);
						cut.add(j);
						cut.add(k);
						retS.add(cut);
						values.add(left - 1.1);
						//System.out.print(left + " ");
						//printer.print_array(cut);
					}
				}
			}
		}
		if(retS.size() < 100){
			double[][] x_map = new double[data.tot + 1][data.tot + 1];
			for(int i = 0; i < lp.active_set.size(); i++){
				ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
				for(int j = 1; j < column.get(0); j++){
					for(int k = j + 1;  k < column.get(0); k ++){
						x_map[column.get(j)][column.get(k)] += lp.active_value.get(i);
					}
				}
			}
			int[][] dist = new int[data.tot + 1][data.tot + 1];
			for(int i = 1; i < data.tot + 1; i++){
				for(int j = i; j < data.tot + 1; j++){
					dist[i][j] = dist[j][i] = (int)(Math.abs(data.y_map[i] - data.y_map[j]) + Math.abs(data.x_map[i] - data.x_map[j]));
				}
			}
			for(int i = 1; i < data.tot + 1; i++){
				for(int j = i + 1; j < data.tot + 1; j++){
					if(dist[i][j] > data.max_size)
						continue;
					//if(x_map[i][j] + x_map[j][i] < 0.18)
					if(x_map[i][j] + x_map[j][i] < 0.15)
						continue;
					for(int k = j + 1; k < data.tot + 1; k++){
						if(dist[i][k] > data.max_size || dist[j][k] > data.max_size)
							continue;
						//if(x_map[i][j] + x_map[j][k] + x_map[k][i] + x_map[j][i] + x_map[i][k] + x_map[k][j] < 0.54)
						if(x_map[i][j] + x_map[j][k] + x_map[k][i] + x_map[j][i] + x_map[i][k] + x_map[k][j] < 0.45)
							continue;
						for(int h = k + 1; h < data.tot + 1; h++){
							if(dist[i][h] > data.max_size || dist[j][h] > data.max_size || dist[k][h] > data.max_size)
								continue;
							//if(x_map[i][j] + x_map[i][k] + x_map[i][h] + x_map[j][i] + x_map[j][k] + x_map[j][h]
									//+ x_map[k][i] + x_map[k][j] + x_map[k][h] + x_map[h][i] + x_map[h][j] + x_map[h][k] < 1.08)
							if(x_map[i][j] + x_map[i][k] + x_map[i][h] + x_map[j][i] + x_map[j][k] + x_map[j][h]
							   + x_map[k][i] + x_map[k][j] + x_map[k][h] + x_map[h][i] + x_map[h][j] + x_map[h][k] < 0.9)
								continue;
							for(int l = h + 1; l < data.tot + 1; l++){
								if(dist[i][l] > data.max_size || dist[j][l] > data.max_size || dist[k][l] > data.max_size || dist[h][l] > data.max_size)
									continue;
								double left = 0.0;
								for(int x = 0; x < lp.active_value.size(); x++){
									int count = col_map[x][i] + col_map[x][j] + col_map[x][k] + col_map[x][h] + col_map[x][l];
									left += Math.floor(count / 2.0) * lp.active_value.get(x);
								}
								if(left > 2.1){
									ArrayList<Integer> cut = new ArrayList<Integer>();
									cut.add(i);
									cut.add(j);
									cut.add(k);
									cut.add(h);
									cut.add(l);
									retS.add(cut);
									values.add(left - 2.1);
									//System.out.print(left + " ");
									//printer.print_array(cut);
								}
							}
						}
					}
				}
			}
		}
		System.out.println("raw sr cut size: " + retS.size());
		ArrayList<ArrayList<Integer>> ret_set = new ArrayList<ArrayList<Integer>>();
		while(ret_set.size() < size && retS.size() > 0){
			double max_value = -1e10;
			int place = -1;
			for(int i = 0; i < values.size(); i++){
				double v = values.get(i);
				if(v > max_value){
					max_value = v;
					place = i;
				}
			}
			System.out.println(retS.get(place) + " " + max_value);
			ArrayList<Integer> add_in = retS.get(place);
			ret_set.add(add_in);
			retS.remove(place);
			values.remove(place);
			boolean[] set = new boolean[data.tot + 1];
			for(int i = 0; i < add_in.size(); i++){
				set[add_in.get(i)] = true;
			}
			//remove the other cuts
			for(int i = 0; i < retS.size(); i++){
				ArrayList<Integer> cut = retS.get(i);
				int similar = 0;
				for(int j = 0; j < cut.size(); j++){
					if(set[cut.get(j)]){
						similar++;
					}
				}
				if(cut.size() == 3 && similar > 1 || cut.size() == 5 && similar > 2){
					retS.remove(i);
					values.remove(i);
					i--;
				}
			}
		}
		if(ret_set.size() < 5)
			ret_set.clear();
		retS = ret_set;
		
	}
}
