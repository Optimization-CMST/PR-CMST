package BPC.SearchTree;

import BPC.Cut.CutPool;
import BPC.LP.PC;
import BPC.LP.RMP;
import Common.Data;
import Common.Input;
import Helper.Check;
import Helper.Help;
import Heuristic_UB.Ub;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;


public class RootNode_Test {

	public Data data;
	public double best_value;
	public ArrayList<ArrayList<Integer>> best_columns;

	public RootNode_Test(Data d){
		data = d;
	};

	public void solve(ArrayList<ArrayList<Integer>> init_routes, ArrayList<ArrayList<Integer>> ubs) throws Exception {
		//ArrayList<ArrayList<Integer>> optimal = read_optimal_solution("optimal.txt");
		double optimal_cost = Help.get_solution_cost(data, ubs);
		DecimalFormat df = new DecimalFormat("0.00");
		best_value = 1e10;
		best_columns = new ArrayList<ArrayList<Integer>>();
		if (ubs != null) {
			best_value = Help.get_solution_cost(data, ubs);
			data.ip_cost = best_value;
			for (int i = 0; i < ubs.size(); i++) {
				best_columns.add(ubs.get(i));
			}
		}
		Node init_node = new Node(data, init_routes);
		init_node.potential_optimal = true;
		init_node.sudo_cost = 0.0;
		PriorityQueue<Node> queue = new PriorityQueue<Node>();
		queue.add(init_node);
		int node_size = 0;
		CutPool cut_pool = new CutPool();
		long[] C = new long[4];
		boolean a = data.time_out();
		boolean b = queue.isEmpty();
		while (data.time_out() == false && queue.isEmpty() == false) {
			double sudo_cost = -1;
			Node node = queue.poll();
			//debug node
			//node.export(node_size);
			//cut_pool.export();
			sudo_cost = node.sudo_cost;
			//------------solve the node-------------------------------
			if (node.sudo_cost > best_value - 0.01) {
				node.clear();
				continue;
			}
			node_size++;
			//copy the node C
			for (int i = 0; i < 4; i++)
				node.C[i] = C[i];
			//-------------new the structure---------------------------
			long t10 = System.nanoTime();
			RMP lp = new RMP(data);
//			BCV bcv = new BCV(data);
//			//BCN bcn = new BCN(data);
//			BCA2 bca2 = new BCA2(data);
//			BCA bca = new BCA(data);
			PC pc = new PC(data);
			//-------------end------------------------------------------
			lp.construct(node, cut_pool);
			long t5 = System.nanoTime();
			//data.first_time = 0;
			System.out.println(node.fid + "----" + node.count);
			pc.solve(lp, best_value);
		}
	}
}
