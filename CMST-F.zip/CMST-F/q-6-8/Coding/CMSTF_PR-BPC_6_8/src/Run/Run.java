package Run;

import BPC.SearchTree.RootNode_Test;
import BPC.SearchTree.Tree;
import Common.Data;
import Common.Input;
import Helper.Check;
import Helper.Help;
import Heuristic_UB.Ub;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Run {
    public static void main(String[] args) throws Exception {
        for (int inst = 2; inst <= 2; inst++) {
            Input input = new Input();
            String path = "instance/final benchmark/r" + inst + ".txt.out";
            System.out.println();
            Data data = input.read_instance(path);
            data.name = "r" + inst;
            System.out.println("read instance sucessful");
            System.out.println("size " + data.tot);
            for (int i = 0; i < data.size.length; i++) {
                System.out.println(i + " " + data.size[i] + " " + data.num[i]);
            }
            //get the ubs
            double t1 = System.nanoTime();
            ArrayList<ArrayList<Integer>> ub = new ArrayList<ArrayList<Integer>>();
            double ub_cost = Ub.get_ub(data, path, ub) * 0.0039365;
            double test = Help.get_solution_cost(data, ub) * 0.0039365;
            if (Math.abs(ub_cost - test) > 0.001){
                int a = 0;
            }
            double t2 = System.nanoTime();

            Tree tree = new Tree(data);
            tree.solve(ub, ub);
            double t3 = System.nanoTime();



            String output_Path = "result/" + data.name + "_" + "t6_8.txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_Path));
            writer.write("Heuristic value : " + String.format("%.2f", ub_cost * 0.0039365));
            writer.newLine();
            writer.write("Heuristic time : " + String.format("%.2f", (t2 - t1)/1e9));
            writer.newLine();
            writer.write("ip cost : " + String.format("%.2f", tree.best_value * 0.0039365));
            writer.newLine();
            writer.write("lp cost : " + String.format("%.2f", data.lp_cost * 0.0039365));
            writer.newLine();
            writer.write("lp time : " + String.format("%.2f", (data.root_lp_time) / 1e9));
            writer.newLine();
            writer.write("lpc cost : " + String.format("%.2f", data.lpc_cost * 0.0039365));
            writer.newLine();
            writer.write("lpc time :" + String.format("%.2f", (data.root_lpc_time) / 1e9));
            writer.newLine();
            writer.write("P1 Label : " + data.root_flabels);
            writer.newLine();
            writer.write("P2 Label : " + data.root_plabels);
            writer.newLine();
            writer.write("R Label : " + data.root_blabels);
            writer.newLine();
            writer.write("Root RCI Cuts : " + data.root_cap_num);
            writer.newLine();
            writer.write("Root SRI Cuts : " + data.root_sr_num);
            writer.newLine();
            writer.write("Total RCI Cuts : " + data.total_cap_num);
            writer.newLine();
            writer.write("Total SRI Cuts :" + data.total_sr_num);
            writer.newLine();
            writer.write("Nodes : " + data.node_num);
            writer.newLine();
            writer.write("Joining Time : " + String.format("%.2f", (data.total_join_time) / 1e9));
            writer.newLine();
            writer.write("Pruning Time : " + String.format("%.2f", (data.DP_1_time) / 1e9));
            writer.newLine();
            writer.write("Gap : " + 0);
            writer.newLine();
            double total_time =  (t3 - t1) / 1e9;
            writer.write("Running Time : " + String.format("%.2f", total_time));
            writer.close();




            System.out.println("LPC value " + data.lpc_cost);
            System.out.println("LPC time " + data.root_lpc_time / 1e9);
            System.out.println("Node Number " + data.node_num);
            System.out.println("upper bound time: " + (t2 - t1) / 1e9);
//            System.out.println("optimal cost: " + tree.best_value * 0.0039365);
//            System.out.println("total time: " + (t3 - t1) / 1e9);
//
//            System.out.println("bpc time: " + (t3 - t2) / 1e9);
//        System.out.println("Ub value " + ub);

            System.out.println("DP_1 time" + data.DP_1_time);
            System.out.println("DP_2 time" + data.DP_2_time);
            System.out.println("DP NG Time" + data.DP_NG_time);

//        Check.check_EuclideanDistance(data);


            // BPC Process
//        ArrayList<ArrayList<Integer>> init_columns = new ArrayList<ArrayList<Integer>>() ;
//        for(int i = 0; i < data.n; i++){
//            ArrayList<Integer> column = new ArrayList<Integer>();
//            column.add(1);    // size
//            column.add(i);    // id
//            column.add(-1);   // root
//            init_columns.add(column);
//        }
//        RootNode_Test test = new RootNode_Test(data);
//        test.solve(init_columns, null);
        }


    }
}