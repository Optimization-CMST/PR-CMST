package Run;

import BPC.SearchTree.RootNode_Test;
import BPC.SearchTree.Tree;
import Common.Data;
import Common.Input;
import Helper.Check;
import Heuristic_UB.Simple_UB;
import Heuristic_UB.Ub;
import com.gurobi.gurobi.GRBException;

import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Run {
    public static void main(String[] args) throws IOException, GRBException {
        // initialization
        String[] INSTANCES = {"tc40-1" , "tc80-1", "tc80-2", "tc80-3", "tc80-4", "tc80-5",
                "te80-1", "te80-2", "te80-3", "te80-4", "te80-5",
                "td80-1", "td80-2", "td80-3", "td80-4", "td80-5",
                "tc120-1", "tc120-2", "tc120-3", "tc120-4", "tc120-5",
                "te120-1", "te120-2", "te120-3", "te120-4", "te120-5",
                "tc160-1", "te160-1"};
        for (int inst = 1; inst <= 27; inst++) {
            String instance = "instance/cmst/unit_demand/" + INSTANCES[inst] + ".txt";
            int Capacity = 10;
            Data data = Input.read_CMST(instance, Capacity);
            data.build_mask();

            data.name = INSTANCES[inst];
            double t1 = System.nanoTime();
//        ArrayList<ArrayList<Integer>> ub_trees = new ArrayList<ArrayList<Integer>>();
//        double ub = Ub.get_ub(instance, data.Q, ub_trees);
//        System.out.println("upper bound: " + ub);
//        Check.check_solution(data, null, ub_trees);
            double t2 = System.nanoTime();
//        int a = 0;
            ArrayList<ArrayList<Integer>> init_columns = Simple_UB.initial_col_generation(data);

            String ub_path = "UB_values_Q_10/" + INSTANCES[inst] + "_UB.txt";
            double cost = findDoubleAfterString("UB value :", ub_path);
            double ub_time = findDoubleAfterString("Running Time :", ub_path);

            Tree tree = new Tree(data);
            tree.solve(init_columns, cost);
            double t3 = System.nanoTime();

            String output_Path = "result/Q_10/" + data.name + "_" + "Q_10.txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_Path));
            writer.write("ip cost : " + Math.round(tree.best_value));
            writer.newLine();
            writer.write("lp cost : " + String.format("%.2f", data.lp_cost));
            writer.newLine();
            writer.write("lp time : " + String.format("%.2f", (data.root_lp_time) / 1e9));
            writer.newLine();
            writer.write("lpc cost : " + String.format("%.2f", data.lpc_cost));
            writer.newLine();
            writer.write("lpc time :" + String.format("%.2f", (data.root_lpc_time) / 1e9));
            writer.newLine();
            writer.write("P1 Label : " + data.root_flabels);
            writer.newLine();
            writer.write("P2 Label : " + data.root_plabels);
            writer.newLine();
            writer.write("R Label : " + data.root_blabels);
            writer.newLine();
            writer.write("Root RCI Cuts : " + data.root_cap_num);
            writer.newLine();
            writer.write("Root SRI Cuts : " + data.root_sr_num);
            writer.newLine();
            writer.write("Total RCI Cuts : " + data.total_cap_num);
            writer.newLine();
            writer.write("Total SRI Cuts :" + data.total_sr_num );
            writer.newLine();
            writer.write("Nodes : " + data.node_num);
            writer.newLine();
            writer.write("Joining Time : " + String.format("%.2f", (data.join_time) / 1e9));
            writer.newLine();
            writer.write("Pruning Time : " + String.format("%.2f", (data.DP_1_time + data.DP_NG_time) / 1e9));
            writer.newLine();
            writer.write("Gap : " + 0);
            writer.newLine();
            double total_time = ub_time + (t3 - t1) / 1e9;
            writer.write("Running Time : " + String.format("%.2f", total_time));
            writer.close();


            System.out.println("LPC value " + data.lpc_cost);
            System.out.println("LPC time " + data.root_lpc_time / 1e9);
            System.out.println("Node Number " + data.node_num);
            System.out.println("upper bound time: " + (t2 - t1) / 1e9);
            System.out.println("optimal cost: " + tree.best_value);
            System.out.println("total time: " + (t3 - t1) / 1e9);

            System.out.println("bpc time: " + (t3 - t2) / 1e9);
//        System.out.println("Ub value " + ub);

            System.out.println("DP_1 time" + data.DP_1_time);
            System.out.println("DP_2 time" + data.DP_2_time);
            System.out.println("DP NG Time" + data.DP_NG_time);
        }

//        Check.check_EuclideanDistance(data);
        // BPC Process
//        ArrayList<ArrayList<Integer>> init_columns = new ArrayList<ArrayList<Integer>>() ;
//        for(int i = 0; i < data.n; i++){
//            ArrayList<Integer> column = new ArrayList<Integer>();
//            column.add(1);    // size
//            column.add(i);    // id
//            column.add(-1);   // root
//            init_columns.add(column);
//        }
//        RootNode_Test test = new RootNode_Test(data);
//        test.solve(init_columns, null);
    }
    public static Double findDoubleAfterString(String searchString, String filePath) {
        // 正则表达式匹配一个double数值（包括正负号、小数点、科学计数法）
        Pattern doublePattern = Pattern.compile(
                "^\\s*([-+]?\\d*\\.?\\d+([eE][-+]?\\d+)?)"   // 从行首或当前位置开始，跳过空白，捕获数值
        );

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                int index = line.indexOf(searchString);
                if (index >= 0) {
                    // 从字符串结束位置开始截取剩余部分
                    String after = line.substring(index + searchString.length());
                    Matcher matcher = doublePattern.matcher(after);
                    if (matcher.find()) {
                        String numberStr = matcher.group(1); // 获取匹配到的数字字符串
                        try {
                            return Double.parseDouble(numberStr);
                        } catch (NumberFormatException e) {
                            // 如果解析失败，继续搜索其他行（或可根据需要返回null）
                            // 这里选择忽略并继续查找
                        }
                    }
                }
            }
        } catch (IOException e) {
            // 文件读取异常，可根据实际需求处理（如打印日志或抛出运行时异常）
            e.printStackTrace();
            return null;
        }
        return null; // 未找到
    }
}