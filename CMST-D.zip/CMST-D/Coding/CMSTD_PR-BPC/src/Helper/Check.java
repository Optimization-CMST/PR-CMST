package Helper;

import BPC.Cut.CutPool;
import BPC.JC.Label;
import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

public class Check {
	
	public static void check_column(Data data, Node node, ArrayList<Integer> column){
		//check the capacity
		if(column.get(0) * 2 + 1 != column.size()){
			System.out.println("capacity error1");
			int z = column.get(0) * 2 + 1;
			int a = column.size();
			System.exit(0);
		}
		if(column.get(0) > data.Q){
			System.out.println("capacity error2");
			System.exit(0);
		}
		//check the root
		int size = column.get(0);
		int root = -1;
		for(int i = 1; i <= size; i++){
			if(column.get(size + i) == -1){
				if(root >= 0){
					System.out.println("multiple roots: " + Help.col2str2(column));
					System.exit(0);
				}
				root = column.get(i);
			}
		}
		if(node != null){
			for(int i = 1; i <= column.get(0); i++){
				int id1 = column.get(i);
				int id2 = data.n;
				if(column.get(i + column.get(0)) >= 0)
					id2 = column.get(column.get(i + column.get(0)));
				if(node.feasible_arc[id1][id2] == -1){
					System.out.println("arc error " + id1 + " " + id2);
					System.exit(0);
				}
			}
		}
		//check the reachablility
		for(int i = 1; i <= size; i++){
			int start = column.get(size + i);
			int count = 0;
			while(start >= 0){
				start = column.get(size + start);
				count++;
				if(count > data.n){
					System.out.println("column loop: " + Help.col2str2(column));
					System.exit(0);
				}
			}
			if(start != -1){
				System.out.println(start + " cannot reach the root " + root + " : " + Help.col2str2(column));
				System.exit(0);
			}
		}
		//check the column ordering
		for(int i = 1; i <= size; i++){
			ArrayList<Integer> csq = new ArrayList<Integer>();
			for(int j = size + 1; j <= 2 * size; j++){
				if(column.get(j) == i){
					csq.add(column.get(j - size));
				}
			}
			//check whether csq is in increasing order
			for(int j = 0; j < csq.size() - 1; j++){
				for(int k = j + 1; k < csq.size(); k++){
					if(csq.get(j) > csq.get(k)){
						System.out.println("column storing error");
						System.out.println(column);
						System.exit(0);
					}
				}
			}
		}
	}
	
	public static void check_column(Data data, Node node, ArrayList<Integer> column, int type){
		//check the root
		check_column(data, node, column);
		if(column.get(0) != type){
			System.out.println("column type error: " + column.get(0) + " " + type);
			System.out.println(Help.col2str2(column));
			System.exit(0);
		}
	}
	
	public static void check_solution(Data data, Node node, ArrayList<ArrayList<Integer>> columns){
		int[] visit = new int[data.n];
		for(int i = 0; i < columns.size(); i++){
			ArrayList<Integer> column = columns.get(i);
			check_column(data, node, column);
			int size = column.get(0);
			for(int j = 1; j <= column.get(0); j++){
				visit[column.get(j)]++;
			}
		}
		//check the visit constraint
		for(int i = 1; i < data.n; i++){
			if(visit[i] != 1){
				System.out.println("visit error");
				System.exit(0);
			}
		}
	}
	
	public static void check_node(Data data, Node node){
		//check the arc
		for(int i = 0; i < node.column_set.size(); i++){
			ArrayList<Integer> column = node.column_set.get(i);
			int size = column.get(0);
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(j + column.get(0)) >= 0)
					id2 = column.get(column.get(j + column.get(0)));
				if(node.feasible_arc[id1][id2] == -1){
					System.out.println("forbid arc error: " + id1 + "->" + id2);
					System.out.println(Help.col2str2(column));
					System.out.println("Node id :" +  node.fid);
					System.exit(0);
				}
			}
		}
	}

	public static void check_EuclideanDistance(Data data) {
		for (int i = 0; i < data.n + 1; i++)
			for (int j = 0; j < data.n + 1; j++)
				for (int k = 0; k < data.n + 1; k++){
					if (i == j || i == k || j == k)
						continue;
					if (data.d[i][k] + data.d[k][j] < data.d[i][j]){
						double d1 = data.d[i][k] + data.d[k][j];
						double d2 = data.d[i][j];
						System.out.println("The graph distance is not the EuclideanDistance");
						System.exit(-1);
					}
				}
	}

	public static void check_Symmetric(Data data) {
		for (int i = 0; i < data.n; i++)
			for (int j = i + 1; j < data.n + 1; j++)
				if (data.d[i][j] != data.d[j][i]) {
					System.out.println("Error in Symmetric" + i + " " + j);
//					System.exit(-1);
				}
	}

	public static void arc_elimination(Data data) {
		for (int i = 1; i < data.n + 1; i++)
			for (int j = 1; j < data.n + 1; j++){
				if (i == j) continue;
				if (data.d[i][j] > data.d[i][0]) {
					int a = 0;
				}
			}
	}

	public static void set_tree(Label label, int[] tree){
		if(label.child1 != null){
			if(label.arc1 == 1)
				tree[label.child1.id] = label.id;
			else if(label.arc1 == 2)
				tree[label.id] = label.child1.id;
			set_tree(label.child1, tree);
		}
		if(label.child2 != null){
			if(label.arc2 == 1)
				tree[label.child2.id] = label.id;
			else if(label.arc2 == 2)
				tree[label.id] = label.child2.id;
			set_tree(label.child2, tree);
		}
	}

	public static ArrayList<Integer> transform(Data data, int size, int[] tree){
		ArrayList<Integer> column = new ArrayList<Integer>();
		ArrayList<Integer> place = new ArrayList<Integer>();
		Stack<Integer> stack = new Stack<Integer>();
		Stack<Integer> father_stack = new Stack<Integer>();
		for(int i = 0; i < data.n; i++){
			if(tree[i] == data.n){//new change
				stack.add(i);
				father_stack.add(-1);
				break;
			}
		}
		column.add(size);
		while(stack.isEmpty() == false){
			int x = stack.pop();
			int father = father_stack.pop();
			column.add(x);
			place.add(father);
			ArrayList<Integer> ids = new ArrayList<Integer>();
			for(int i = 0; i < tree.length; i++){
				if(tree[i] == x){
					int insert = 0;
					while(insert < ids.size() && i < ids.get(insert))
						insert++;
					ids.add(insert, i);
				}
			}
			for(int i = 0; i < ids.size(); i++){
				stack.add(ids.get(i));
				father_stack.add(column.size() - 1);
			}
		}
		for(int i = 0; i < place.size(); i++){
			column.add(place.get(i));
		}
		return column;
	}

	public static  ArrayList<Integer> get_column(Data data, Label label){
		int[] tree = new int[data.n];
		Arrays.fill(tree, -1);
		set_tree(label, tree);
		tree[label.root] = data.n; //new change
		return transform(data, label.q, tree);
	}

	public static Label  extend2depot(Data data, RMP lp, Label label){
		Label new_label = new Label();
		new_label.c = label.c + data.d[label.id][data.n] - lp.mu[data.n] - lp.dual_arc[label.id][data.n];
		new_label.id = label.id;
		new_label.q = label.q;
		new_label.V1 = label.V1;
		new_label.V2 = label.V2;
		new_label.V3 = label.V3;
		new_label.V4 = label.V4;
		new_label.N1 = label.N1;
		new_label.N2 = label.N2;
		new_label.N3 = label.N3;
		new_label.N4 = label.N4;
		new_label.child1 = label;
		new_label.child2 = null;
		new_label.arc1 = 0;
		new_label.arc2 = 0;
		new_label.root = label.id;
		return new_label;
	}


	public static void check_elimentary(Data data, ArrayList<Integer> column){
		int[] visit = new int[data.n];
		for(int i = 1; i <= column.get(0); i++){
			int id = column.get(i);
			visit[id]++;
			if(visit[id] > 1){
				System.out.println("elementary constraints voilated");
				System.out.println(Help.col2str2(column));
				System.exit(0);
			}
		}
	}

	//check the reduced cost of a column
	public static void check_reduced_cost(Data data, RMP lp, ArrayList<Integer> column, double target){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		if(Math.abs(rc - target) > 1e-3){
			System.out.println("dp reduced cost error: " + rc + " " + target);
			System.out.println("cost " + cost + " profit " + dual_profit);
			System.out.println(Help.col2str2(column));
			System.out.println("mu:");
			double sum_mu = 0;
			for(int i = 1; i <= column.get(0); i++){
				System.out.print(column.get(i) + "(" + lp.mu[column.get(i)] + ") ");
				sum_mu += lp.mu[column.get(i)];
			}
			System.out.println("mu[data.n]: " + lp.mu[data.n]);
			System.out.println("sum_mu: " + (sum_mu + lp.mu[data.n]));
			System.out.println();
			for(int i = 0; i < lp.sr_cuts.size(); i++){
				ArrayList<Integer> cut = lp.sr_cuts.get(i);
				for(int j = 0; j < cut.size(); j++){
					System.out.print(cut.get(j) + " ");
				}
				System.out.println(": " + lp.sr_dual.get(i));
			}
			for(int i = 1; i <= column.get(0); i++){
				int id1 = column.get(i);
				int id2 = data.n;
				if(column.get(i + column.get(0)) >= 0)
					id2 = column.get(column.get(i + column.get(0)));
				System.out.println(id1 + " " + id2 + " " + lp.dual_arc[id1][id2] + " " + data.d[id1][id2]);
			}
			System.exit(0);
		}
	}
	
	public static boolean check_node_solvability(Data data, Node node, CutPool cut_pool) throws GRBException {
		RMP lp = new RMP(data);
		lp.construct(node, cut_pool);
		lp.model.optimize();
		int status = lp.model.get(GRB.IntAttr.Status);
		if(status != GRB.Status.OPTIMAL){
			System.out.println("check node sovability error");
			//System.exit(0);
			return false;
		}
		return true;
	}
	
}
