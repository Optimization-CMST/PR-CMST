package Common;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Input {
	public static Data read_CMST(String file, int Capacity) throws IOException{
		Scanner cin = new Scanner(new BufferedReader(new FileReader(file)));
		Data data = new Data();
//		String str = cin.next();
//		String[] sub_str = str.split("\\.");
//		data.name = sub_str[0];
		data.n = cin.nextInt();
		data.d = new double[data.n + 1][data.n + 1];
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				data.d[i][j] = cin.nextDouble();
			}
		}
		data.q = new int[data.n + 1];
		for(int i = 0; i < data.n; i++){
			data.q[i] = 1;
		}
		data.Q = Capacity;
		cin.close();
		return data;
	}
}
