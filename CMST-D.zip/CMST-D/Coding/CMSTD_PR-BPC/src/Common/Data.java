package Common;

public class Data {

	public int n; //the number of nodes, not including the depot
	public double[][] d; //the distance matrix
	public int[] q; //the demand of each vertex
	public int Q; //the capacity
	public String name; //instance name
	public long[] mask;
	
	//DP2 init masks
	public int init_limit = 50;
	public long[] intDC = {0x00, 0x00, 0x00, 0x00};
	//algorithm parameter
	public double time_limit = 48 * 60 * 60;
	public double start_time  = System.nanoTime();
	//output information - root node
	public boolean is_root = true;
	public double lp_cost;
	public double lpc_cost;
	public double root_lp_time  = 0;
	public double root_lpc_time = 0;
	public int root_flabels = 0;
	public int root_plabels = 0;
	public int root_blabels = 0;
	public int root_cap_num = 0;
	public int root_sr_num = 0;
	
	public double ip_cost;
	public double ip_time = 0;
	public int node_num = 0;
	public int total_cap_num = 0;
	public int total_sr_num = 0;


	public long all_mask;

	public double DP_1_time = 0;
	public double DP_2_time = 0;
	public double DP_NG_time = 0;
	public double join_time = 0;



	public Data() {
	}

	
	public void build_mask(){
//		start_time = System.nanoTime();
		mask = new long[2* (n + 1 )];
		long mk = 0x01;
		for(int i = 0; i < 2 * (n + 1); i++){
			mask[i] = mk;
			if(i == 63 || i == 127 || i == 191)
				mk = 0x01;
			else
				mk *= 2;
		}
		mk = 0x01;
		for(int i = 0; i < 64; i++){
			all_mask = all_mask | mk;
			mk *= 2;
		}
		//init_limit = n / 3 + 10;
		init_limit = 50;
	}
	
	public boolean time_out(){
		if((System.nanoTime() - start_time) / 1e9 > time_limit)
			return true;
		else
			return false;
	}
}
