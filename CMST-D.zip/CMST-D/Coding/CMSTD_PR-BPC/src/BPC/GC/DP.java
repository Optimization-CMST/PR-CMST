package BPC.GC;

import BPC.LP.RMP;
import Common.Data;

public class DP {

	public Data data;
	public double[][] db;
	
	public DP(Data d){
		data = d;
		db = new double[data.n + 1][data.n + 1];
	}

	public void run(RMP lp, double[][][] FT, double[][][] BT){
		//double[][][] FT = new double[data.n][data.n - 1][data.Q + 1];
		int[][][] f_pre = new int[data.n][data.n - 1][data.Q + 1];
		int[][][] f_preq = new int[data.n][data.n - 1][data.Q + 1];
		//double[][][] BT = new double[data.n][data.n - 1][data.Q + 1];
		int[][][] b_pre = new int[data.n][data.n - 1][data.Q + 1];
		int[][][] b_preq = new int[data.n][data.n - 1][data.Q + 1];
		//initialize the states
		for(int i = 0; i < data.n; i++){
			for(int k = 0; k < data.n - 1; k++){
				//forward state
				FT[i][k][0] = 1e15;
				FT[i][k][1] = -lp.mu[i];
				f_pre[i][k][0] = -1;
				f_pre[i][k][1] = -1;
				f_preq[i][k][0] = -1;
				f_preq[i][k][1] = -1;
				//backward state
				BT[i][k][0] = 1e15;
				BT[i][k][1] = db[i][data.n] - lp.mu[i] - lp.mu[data.n];
				b_pre[i][k][0] = -1;
				b_pre[i][k][1] = -1;
				b_preq[i][k][0] = -1;
				b_preq[i][k][1] = -1;
			}
		}
		//dp
		for(int q = 2; q <= data.Q; q++){
			for(int i = 0; i < data.n; i++){
				for(int k = 0; k < data.n  - 1; k++){
					FT[i][k][q] = 1e15;
					f_pre[i][k][q] = -1;
					f_preq[i][k][q] = -1;
					BT[i][k][q] = 1e15;
					b_pre[i][k][q] = -1;
					b_preq[i][k][q] = -1;
					//decision 1, from the k - 1 state
					if(k - 1 >= 0){
						if(FT[i][k - 1][q] < FT[i][k][q]){
							FT[i][k][q] = FT[i][k - 1][q];
							f_pre[i][k][q] = 0;
							f_preq[i][k][q] = -1;
						}
						if(BT[i][k - 1][q] < BT[i][k][q]){
							BT[i][k][q] = BT[i][k - 1][q];
							b_pre[i][k][q] = 0;
							b_preq[i][k][q] = -1;
						}
					}
					int jid = k;
					if(jid >= i)
						jid++;
					//decision 2, all from the next customer
					if(lp.node.feasible_arc[jid][i] != -1){
						double cost2 = db[jid][i]  - lp.mu[i] + FT[jid][data.n - 2][q - 1];
						if(cost2 < FT[i][k][q]){
							FT[i][k][q] = cost2;
							f_pre[i][k][q] = 1;
							f_preq[i][k][q] = -1;
						}
					}
					
					if(lp.node.feasible_arc[i][jid] != -1){
						double cost2 = db[i][jid]  - lp.mu[i] + BT[jid][data.n - 2][q - 1];
						if(cost2 < BT[i][k][q]){
							BT[i][k][q] = cost2;
							b_pre[i][k][q] = 1;
							b_preq[i][k][q] = -1;
						}
					}
					
					if(k - 1 >= 0){
						//decision 3, from two labels
						if(lp.node.feasible_arc[jid][i] != -1){
							for(int q2 = 1; q2 <= q - 2; q2++){
								double cost3 = FT[i][k - 1][q - q2] + db[jid][i] + FT[jid][data.n - 2][q2];
								if(cost3 < FT[i][k][q]){
									FT[i][k][q] = cost3;
									f_pre[i][k][q] = 2;
									f_preq[i][k][q] = q2;
								}
							}
							
							for(int q2 = 1; q2 <= q - 2; q2++){
								double cost3 = BT[i][k - 1][q - q2] + db[jid][i] + FT[jid][data.n - 2][q2];
								if(cost3 < BT[i][k][q]){
									BT[i][k][q] = cost3;
									b_pre[i][k][q] = 2;
									b_preq[i][k][q] = q2;
								}
							}
							
						}
						
						if(lp.node.feasible_arc[i][jid] != -1){
							for(int q2 = 1; q2 <= q - 2; q2++){
								double cost3 = FT[i][k - 1][q - q2] + db[i][jid] + BT[jid][data.n - 2][q2];
								if(cost3 < BT[i][k][q]){
									BT[i][k][q] = cost3;
									b_pre[i][k][q] = 3;
									b_preq[i][k][q] = q2;
								}
							}
						}
						
					}
					if(k == data.n - 2 && lp.node.feasible_arc[i][data.n] != -1){
						//decision 4 for the backward extension
						double cost4 = FT[i][k][q] + db[i][data.n] - lp.mu[data.n];
						if(cost4 < BT[i][k][q]){
							BT[i][k][q] = cost4;
							b_pre[i][k][q] = 4;
							b_preq[i][k][q] = -1;
						}
					}
				}
			}
		}
	}
	
	public void get_bound(RMP lp, double[][] fb, double[][] bb){
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				db[i][j] = data.d[i][j] - lp.dual_arc[i][j];
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int q = 0; q < data.Q; q++){
				fb[i][q] = db[i][data.n] - lp.mu[data.n] - lp.mu[i];
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int q = 0; q < data.Q; q++){
				bb[i][q] = 0.0;
			}
		}
		double[][][] FT = new double[data.n][data.n - 1][data.Q + 1];
		double[][][] BT = new double[data.n][data.n - 1][data.Q + 1];
		run(lp, FT, BT);

		for(int i = 0; i < data.n; i++){
			for(int q = 1; q < data.Q; q++){
				for(int j = 2; j <= data.Q - q; j++){
					double cost = BT[i][data.n - 2][j];
					if(cost < fb[i][q]){
						fb[i][q] = cost;          // fb里存储的是所有backward label可能到达i点的最低cost 注 ： i 点本身的cost不在里面
					}
				}
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int q = 1; q < data.Q; q++){
				for(int j = 2; j <= data.Q - q + 1; j++){
					double cost = FT[i][data.n - 2][j] + lp.mu[i];  // forward label可能到达i点的最低cost 注 ： i 点本身的cost不在里面
					if(cost < bb[i][q]){
						bb[i][q] = cost;
					}
				}
			}
		}
	}
}
