package BPC.Cut;

import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;

public class SRSep {
	public Data data;
	public ArrayList<ArrayList<Integer>> retS;
	
	public SRSep(Data d){
		data = d;
	}
	
	public void solve(RMP lp, int size){
		retS = new ArrayList<ArrayList<Integer>>();
		ArrayList<Double> values = new ArrayList<Double>();
		//-----------construct the map--------------------------------------------
		int[][] col_map = new int[lp.active_set.size()][data.n + 1];
		for(int i = 0; i < lp.active_set.size(); i++){
			ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
			for(int j = 1; j <= column.get(0); j++){
				col_map[i][column.get(j)]++;
			}
		}
		//----------enumerate all the three node set------------------------------
		for(int i = 1; i < data.n + 1; i++){
			for(int j = i + 1; j < data.n + 1; j++){
				for(int k = j + 1; k < data.n + 1; k++){
					double left = 0.0;
					for(int h = 0; h < lp.active_value.size(); h++){
						int count = col_map[h][i] + col_map[h][j] + col_map[h][k];
						left += Math.floor(count / 2.0) * lp.active_value.get(h);
					}
					if(left > 1.1){
						ArrayList<Integer> cut = new ArrayList<Integer>();
						cut.add(i);
						cut.add(j);
						cut.add(k);
						retS.add(cut);
						values.add(left - 1.1);
						//System.out.print(left + " ");
						//printer.print_array(cut);
					}
				}
			}
		}

		double[][] x_map = new double[data.n + 1][data.n + 1];
		for(int i = 0; i < lp.active_set.size(); i++){
			ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
			for(int j = 1; j < column.get(0); j++){
				for(int k = j + 1;  k < column.get(0); k ++){
					x_map[column.get(j)][column.get(k)] += lp.active_value.get(i);
				}
			}
		}
		
		for(int i = 1; i < data.n + 1; i++){
			for(int j = i + 1; j < data.n + 1; j++){
				if(x_map[i][j] + x_map[j][i] < 0.18)
					continue;
				for(int k = j + 1; k < data.n + 1; k++){
					if(x_map[i][j] + x_map[j][k] + x_map[k][i] + x_map[j][i] + x_map[i][k] + x_map[k][j] < 0.54)
						continue;
					for(int h = k + 1; h < data.n + 1; h++){
						if(x_map[i][j] + x_map[i][k] + x_map[i][h] + x_map[j][i] + x_map[j][k] + x_map[j][h]
								+ x_map[k][i] + x_map[k][j] + x_map[k][h] + x_map[h][i] + x_map[h][j] + x_map[h][k] < 1.08)
							continue;
						for(int l = h + 1; l < data.n + 1; l++){
							double left = 0.0;
							for(int x = 0; x < lp.active_value.size(); x++){
								int count = col_map[x][i] + col_map[x][j] + col_map[x][k] + col_map[x][h] + col_map[x][l];
								left += Math.floor(count / 2.0) * lp.active_value.get(x);
							}
							if(left > 2.15){
								ArrayList<Integer> cut = new ArrayList<Integer>();
								cut.add(i);
								cut.add(j);
								cut.add(k);
								cut.add(h);
								cut.add(l);
								retS.add(cut);
								values.add(left - 2.2);
								//System.out.print(left + " ");
								//printer.print_array(cut);
							}
						}
					}
				}
			}
		}
		
		System.out.println("raw sr cut size: " + retS.size());
		//if(retS.size() < 50){
			//retS.clear();
			//return;
		//}
		ArrayList<ArrayList<Integer>> ret_set = new ArrayList<ArrayList<Integer>>();
		while(ret_set.size() < size && retS.size() > 0){
			double max_value = -1e10;
			int place = -1;
			for(int i = 0; i < values.size(); i++){
				double v = values.get(i);
				if(v > max_value){
					max_value = v;
					place = i;
				}
			}
			ArrayList<Integer> add_in = retS.get(place);
			ret_set.add(add_in);
			retS.remove(place);
			values.remove(place);
		}
		/*
		if(retS.size() < 10){
			retS.clear();
			return;
		}
		*/
		if(ret_set.size() < 20)
			ret_set.clear();
		retS = ret_set;
	}
}
