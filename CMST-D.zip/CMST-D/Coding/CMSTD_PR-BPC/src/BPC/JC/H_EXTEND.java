package BPC.JC;

import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;

public class H_EXTEND {

	public Data data;
	public ArrayList<Integer> size;
	public int total_size;
	public int cap;
	public Label[][][] fpool;

	public H_EXTEND(Data d){
		data = d;
		size = new ArrayList<Integer>();
		total_size = 0;
		int m = data.n - 1;
		cap = data.Q;
		while(true){
			size.add(m);
			total_size += m;
			if(m == 1)
				break;
			m = (int) Math.ceil(((double)m) / 2.0);
		}
	}

	
	public static void f_sr_handle1(RMP lp, Label label, int i, Label new_label){
		new_label.sr_set = new ArrayList<Integer>();
		new_label.tsr = 0.0;
		ArrayList<Integer> node_set = lp.sr_node_set.get(i);
		for(int j = 0; j < label.sr_set.size(); j++){
			int s1 = label.sr_set.get(j);
			int s2 = node_set.get(j);
			new_label.c -= lp.sr_comp[j][s1 & s2];
			int s3 = s1 & (~s2) | (~s1) & s2;
			new_label.sr_set.add(s3);
			new_label.tsr += lp.sr_comp[j][s3];
		}
	}
	
	public static void f_sr_handle2(RMP lp, Label label1, Label label2, Label new_label){
		new_label.sr_set = new ArrayList<Integer>();
		new_label.tsr = 0.0;
		for(int j = 0; j < label1.sr_set.size(); j++){
			int s1 = label1.sr_set.get(j);
			int s2 = label2.sr_set.get(j);
			new_label.c -= lp.sr_comp[j][s1 & s2];
			int s3 = s1 & (~s2) | (~s1) & s2;
			new_label.sr_set.add(s3);
			new_label.tsr += lp.sr_comp[j][s3];
		}
	}
	
	public static void f_sr_handle3(RMP lp, Label label, int i){
		ArrayList<Integer> old_set = label.sr_set;
		label.sr_set = new ArrayList<Integer>();
		label.tsr = 0.0;
		ArrayList<Integer> node_set = lp.sr_node_set.get(i);
		for(int j = 0; j < old_set.size(); j++){
			int s1 = old_set.get(j);
			int s2 = node_set.get(j);
			label.c -= lp.sr_comp[j][s1 & s2];
			int s3 = s1 & (~s2) | (~s1) & s2;
			label.sr_set.add(s3);
			label.tsr += lp.sr_comp[j][s3];
		}
	}
	
	public void initialize_layer(RMP lp, int id, int j, int q, Label label){
		if (label == null) return;
			if(id < 64){
				if((label.V1 & data.mask[id]) != 0x00)
					return;
			}
			else if(id < 128){
				if((label.V2 & data.mask[id]) != 0x00)
					return;
			}
			else if(id < 192){
				if((label.V3 & data.mask[id]) != 0x00)
					return;
			}
			else{
				if((label.V4 & data.mask[id]) != 0x00)
					return;
			}
			if(lp.node.feasible_arc[label.id][id] == -1)
					return;
			Label new_label = new Label();
			new_label.c = label.c + data.d[label.id][id] - lp.dual_arc[label.id][id];
			new_label.id = id;
			new_label.q = label.q;
			new_label.V1 = label.V1;
			new_label.V2 = label.V2; 
			new_label.V3 = label.V3;
			new_label.V4 = label.V4;
			new_label.N1 = label.N1;
			new_label.N2 = label.N2;
			new_label.N3 = label.N3;
			new_label.N4 = label.N4;
			new_label.child1 = label;
			new_label.child2 = null;
			new_label.arc1 = 1;
			new_label.arc2 = 0;
			new_label.root = -1;
			if(lp.is_sr_add){
				new_label.tsr = label.tsr;
				new_label.sr_set = (ArrayList<Integer>) label.sr_set.clone();
			}
			fpool[id][j][q] = new_label;
	}
	
	public void crossover(int id, int j, int q,  Label label1, Label label2){
		if (label1 == null && label2 != null)
			fpool[id][j][q] = label2;
		if (label1 != null && label2 == null)
			fpool[id][j][q] = label1;
		if (label1 != null && label2 != null) {
			if (label1.c < label2.c)
				fpool[id][j][q] = label1;
			else
				fpool[id][j][q] = label2;
		}
	}
	
	public void combine1(RMP lp, int id, int j, int q,  Label label1, Label label2){
		if (label1 == null || label2 == null)
			return;
		//check feasibility
		if((label1.V1 & label2.V1 ) != 0x00 || (label1.V2 & label2.V2 ) != 0x00 || (label1.V3 & label2.V3 ) != 0x00 || (label1.V4 & label2.V4 ) != 0x00)
			return;
		Label new_label = new Label();
		new_label.c = label1.c + label2.c;
		new_label.id = id;
		new_label.q = label1.q + label2.q;
		new_label.V1 = label1.V1 | label2.V1;
		new_label.V2 = label1.V2 | label2.V2;
		new_label.V3 = label1.V3 | label2.V3;
		new_label.V4 = label1.V4 | label2.V4;
		new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
		new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
		new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
		new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
		new_label.child1 = label1;
		new_label.child2 = label2;
		new_label.arc1 = 0;
		new_label.arc2 = 0;
		new_label.root = -1;
		//handle the sr cuts
		if(lp.is_sr_add){
			f_sr_handle2(lp, label1, label2, new_label);
		}
		if (fpool[id][j][q] == null)
			fpool[id][j][q] = new_label;
		else if (new_label.c < fpool[id][j][q].c)
			fpool[id][j][q] = new_label;
	}
	
	public  void final_crossover1(RMP lp, int id, int j, int q,  Label label1, Label label2){
		Label new_label1 = new Label();
		if (label1 != null) {
			new_label1.c = label1.c - lp.mu[id];
			new_label1.id = id;
			new_label1.q = label1.q + 1;
			if (id < 64) {
				new_label1.V1 = label1.V1 | data.mask[id];
				new_label1.V2 = label1.V2;
				new_label1.V3 = label1.V3;
				new_label1.V4 = label1.V4;
				new_label1.N1 = label1.N1 | (label1.V1 & data.mask[id]);
				new_label1.N2 = label1.N2;
				new_label1.N3 = label1.N3;
				new_label1.N4 = label1.N4;
			} else if (id < 128) {
				new_label1.V1 = label1.V1;
				new_label1.V2 = label1.V2 | data.mask[id];
				new_label1.V3 = label1.V3;
				new_label1.V4 = label1.V4;
				new_label1.N1 = label1.N1;
				new_label1.N2 = label1.N2 | (label1.V2 & data.mask[id]);
				new_label1.N3 = label1.N3;
				new_label1.N4 = label1.N4;
			} else if (id < 192) {
				new_label1.V1 = label1.V1;
				new_label1.V2 = label1.V2;
				new_label1.V3 = label1.V3 | data.mask[id];
				new_label1.V4 = label1.V4;
				new_label1.N1 = label1.N1;
				new_label1.N2 = label1.N2;
				new_label1.N3 = label1.N3 | (label1.V3 & data.mask[id]);
				new_label1.N4 = label1.N4;
			} else {
				new_label1.V1 = label1.V1;
				new_label1.V2 = label1.V2;
				new_label1.V3 = label1.V3;
				new_label1.V4 = label1.V4 | data.mask[id];
				new_label1.N1 = label1.N1;
				new_label1.N2 = label1.N2;
				new_label1.N3 = label1.N3;
				new_label1.N4 = label1.N4 | (label1.V4 & data.mask[id]);
			}
			new_label1.child1 = label1;
			new_label1.child2 = null;
			new_label1.arc1 = 0;
			new_label1.arc2 = 0;
			new_label1.root = -1;
			if (lp.is_sr_add) {
				f_sr_handle1(lp, label1, id, new_label1);
			}
		}

		Label new_label2 = new Label();
		if (label2 != null) {
			new_label2.c = label2.c - lp.mu[id];
			new_label2.id = id;
			new_label2.q = label2.q + 1;
			if (id < 64) {
				new_label2.V1 = label2.V1 | data.mask[id];
				new_label2.V2 = label2.V2;
				new_label2.V3 = label2.V3;
				new_label2.V4 = label2.V4;
				new_label2.N1 = label2.N1 | (label2.V1 & data.mask[id]);
				new_label2.N2 = label2.N2;
				new_label2.N3 = label2.N3;
				new_label2.N4 = label2.N4;
			} else if (id < 128) {
				new_label2.V1 = label2.V1;
				new_label2.V2 = label2.V2 | data.mask[id];
				new_label2.V3 = label2.V3;
				new_label2.V4 = label2.V4;
				new_label2.N1 = label2.N1;
				new_label2.N2 = label2.N2 | (label2.V2 & data.mask[id]);
				new_label2.N3 = label2.N3;
				new_label2.N4 = label2.N4;
			} else if (id < 192) {
				new_label2.V1 = label2.V1;
				new_label2.V2 = label2.V2;
				new_label2.V3 = label2.V3 | data.mask[id];
				new_label2.V4 = label2.V4;
				new_label2.N1 = label2.N1;
				new_label2.N2 = label2.N2;
				new_label2.N3 = label2.N3 | (label2.V3 & data.mask[id]);
				new_label2.N4 = label2.N4;
			} else {
				new_label2.V1 = label2.V1;
				new_label2.V2 = label2.V2;
				new_label2.V3 = label2.V3;
				new_label2.V4 = label2.V4 | data.mask[id];
				new_label2.N1 = label2.N1;
				new_label2.N2 = label2.N2;
				new_label2.N3 = label2.N3;
				new_label2.N4 = label2.N4 | (label2.V4 & data.mask[id]);
			}
			new_label2.child1 = label2;
			new_label2.child2 = null;
			new_label2.arc1 = 0;
			new_label2.arc2 = 0;
			new_label2.root = -1;
			if (lp.is_sr_add) {
				f_sr_handle1(lp, label2, id, new_label2);
			}
		}

		if (label1 == null && label2 != null)
			fpool[id][j][q] = new_label2;
		if (label1 != null && label2 == null)
			fpool[id][j][q] = new_label1;
		if (label1 != null && label2 != null) {
			if (new_label1.c < new_label2.c)
				fpool[id][j][q] = new_label1;
			else
				fpool[id][j][q] = new_label2;
		}
	}
	
	public void final_combine1(RMP lp, int id, int j, int q,  Label label1, Label label2){
		if (label1 == null || label2 == null)
			return;
		//check feasibility
		if((label1.V1 & label2.V1) != 0x00 || (label1.V2 & label2.V2) != 0x00 || (label1.V3 & label2.V3) != 0x00 || (label1.V4 & label2.V4) != 0x00)
			return;
		Label new_label = new Label();
		new_label.c = label1.c + label2.c - lp.mu[id];
		new_label.id = id;
		new_label.q = label1.q + label2.q + 1;
		if(id < 64){
			new_label.V1 = label1.V1 | label2.V1 | data.mask[id];
			new_label.V2 = label1.V2 | label2.V2;
			new_label.V3 = label1.V3 | label2.V3;
			new_label.V4 = label1.V4 | label2.V4;
			new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & data.mask[id]) | (label2.V1 & data.mask[id]) | (label1.V1 & label2.V1);
			new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
			new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
			new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
		}
		else if(id < 128){
			new_label.V1 = label1.V1 | label2.V1;
			new_label.V2 = label1.V2 | label2.V2 | data.mask[id];
			new_label.V3 = label1.V3 | label2.V3;
			new_label.V4 = label1.V4 | label2.V4;
			new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
			new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & data.mask[id]) | (label2.V2 & data.mask[id]) | (label1.V2 & label2.V2);
			new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
			new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
		}
		else if(id < 192){
			new_label.V1 = label1.V1 | label2.V1;
			new_label.V2 = label1.V2 | label2.V2;
			new_label.V3 = label1.V3 | label2.V3 | data.mask[id];
			new_label.V4 = label1.V4 | label2.V4;
			new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
			new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
			new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & data.mask[id]) | (label2.V3 & data.mask[id]) | (label1.V3 & label2.V3);
			new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
		}
		else {
			new_label.V1 = label1.V1 | label2.V1;
			new_label.V2 = label1.V2 | label2.V2;
			new_label.V3 = label1.V3 | label2.V3;
			new_label.V4 = label1.V4 | label2.V4 | data.mask[id];
			new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
			new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
			new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
			new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & data.mask[id]) | (label2.V4 & data.mask[id]) | (label1.V4 & label2.V4);
		}
		new_label.child1 = label1;
		new_label.child2 = label2;
		new_label.arc1 = 0;
		new_label.arc2 = 0;
		new_label.root = -1;
		if(lp.is_sr_add){
			f_sr_handle2(lp, label1, label2, new_label);
			f_sr_handle3(lp, new_label, id);
		}
		if (fpool[id][j][q] == null)
			fpool[id][j][q] = new_label;
		else {
			if (new_label.c < fpool[id][j][q].c)
				fpool[id][j][q] = new_label;
		}
	}
	
	public void extend(RMP lp, Label[][] FT){
		fpool = new Label[data.n][total_size][cap + 1];
		//initialize
		for(int i = 0; i < data.n; i++){
			Label label = new Label();
			label.id = i;
			label.q = 1;
			label.c = -lp.mu[i];
			label.child1 = null;
			label.child2 = null;
			label.arc1 = 0;
			label.arc2 = 0;
			label.root = -1;
			if(i < 64){
				label.V1 = data.mask[i];
				label.V2 = 0x00;
				label.V3 = 0x00;
				label.V4 = 0x00;
			}
			else if(i < 128){
				label.V1 = 0x00;
				label.V2 = data.mask[i];
				label.V3 = 0x00;
				label.V4 = 0x00;
			}
			else if(i < 192){
				label.V1 = 0x00;
				label.V2 = 0x00;
				label.V3 = data.mask[i];
				label.V4 = 0x00;
			}
			else {
				label.V1 = 0x00;
				label.V2 = 0x00;
				label.V3 = 0x00;
				label.V4 = data.mask[i];
			}
			label.N1 = 0x00;
			label.N2 = 0x00;
			label.N3 = 0x00;
			label.N4 = 0x00;
			if(lp.is_sr_add){
				label.sr_set = (ArrayList<Integer>) lp.sr_node_set.get(i).clone();
				label.tsr = 0;
				for(int j = 0; j < label.sr_set.size(); j++){
					label.tsr += lp.sr_comp[j][label.sr_set.get(j)];
				}
			}
			fpool[i][total_size - 1][1] = label;
		}
		//extension
		for(int g = 2; g <= cap; g++){
			for(int i = 0; i < data.n; i++){
				//forward
				//intialize the first layer
				int lsize = size.get(0);
				for(int j = 0; j < lsize; j++){
					int id = j;
					if(id >= i)
						id++;
					if(lp.node.feasible_arc[id][i] == -1)
						continue;
					Label labels = fpool[id][total_size - 1][g - 1];
					initialize_layer(lp,  i, j, g, labels);
				}

				//move to the next layer
				int start = 0;
				for(int j = 1; j < size.size() - 1; j++){
					lsize = size.get(j);
					int pre_lsize = size.get(j - 1);
					for(int k = 0; k < lsize; k++){
						if(2 * k + 1 >= pre_lsize){
							//directly move
							fpool[i][start + pre_lsize + k][g] = fpool[i][start + 2 * k][g];
						}
						else{
							//crossover
							Label label1 = fpool[i][start + 2* k][g];
							Label label2 = fpool[i][start + 2 * k + 1][g];
							crossover(i, start + pre_lsize + k, g, label1, label2);
							for(int q = 2; q < g; q++){
								Label label3 = fpool[i][start + 2 * k][q];
								Label label4 = fpool[i][start + 2 * k + 1][g + 1 - q];
								combine1(lp, i,start + pre_lsize + k, g, label3, label4);
							}
						}
					}
					start += pre_lsize;
				}

				//final
				Label label1 = fpool[i][total_size - 3][g];
				Label label2 = fpool[i][total_size - 2][g];
				final_crossover1(lp, i, total_size - 1, g, label1, label2);
				for(int q = 2; q < g; q++){
					Label label3 = fpool[i][total_size - 3][q];
					Label label4 = fpool[i][total_size - 2][g + 1 - q];
					final_combine1(lp,  i, total_size - 1, g, label3, label4);
				}
			}
		}
		//get the results
		for(int i = 0; i < data.n; i++){
			for(int q = 1; q <= cap; q++){
				FT[i][q] = fpool[i][total_size - 1][q];
			}
		}
	}

}
