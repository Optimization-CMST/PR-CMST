package BPC.JC;


import BPC.LP.RMP;
import Common.Data;
import Helper.Check;
import Helper.Help;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Stack;

public class HJC {

	public Data data;
	public HJC(Data d){
		data = d;
	}
	
	public ArrayList<Double> solve(RMP lp, double thresh_hold, long[] CX, ArrayList<ArrayList<Integer>> columns) {

		ArrayList<Double> reduced_cost = new ArrayList<Double>();
		HashSet<ArrayList<Integer>> map = new HashSet<ArrayList<Integer>>();
		H_EXTEND EXT = new H_EXTEND(data);
		while(data.time_out() == false){
			Label[][] FT = new Label[data.n][data.Q + 1];

			EXT.extend(lp, FT);
			if(data.time_out())
				break;
			ArrayList<ArrayList<Label>> new_labels = new ArrayList<ArrayList<Label>>();
			for(int i = 0; i < data.n; i++){
				new_labels.add(new ArrayList<Label>());
			}
			for(int i = 0; i < data.n; i++){
				if(lp.node.feasible_arc[i][data.n] == -1)
					continue;
				for (int capacity = 1; capacity <= data.Q; capacity++) {
					Label label = FT[i][capacity];
					if (label != null && label.q <= data.Q) {
						Label new_label = new Label();
						new_label.id = label.id;
						new_label.c = label.c + data.d[label.id][data.n] - lp.mu[data.n] - lp.dual_arc[label.id][data.n];
						new_label.q = label.q;
						new_label.V1 = label.V1;
						new_label.V2 = label.V2;
						new_label.V3 = label.V3;
						new_label.N1 = label.N1;
						new_label.N2 = label.N2;
						new_label.N3 = label.N3;
						new_label.child1 = label;
						new_label.child2 = null;
						new_label.arc1 = 0;
						new_label.arc2 = 0;
						new_label.root = label.id;
						new_labels.get(i).add(new_label);
					}
				}
			}
			int new_label_size = 0;
			for(int i = 0; i < data.n; i++){
				new_label_size += new_labels.get(i).size();
			}
			System.out.print("new label size>>>" + new_label_size + "\t");

			ArrayList<ArrayList<Integer>> negative_column = new ArrayList<>();
			ArrayList<ArrayList<Integer>> elementary_column = new ArrayList<>();
			for(int i = 0; i < data.n; i++){
				ArrayList<Label> labels = new_labels.get(i);
				for(int k = 0; k < labels.size(); k++){
					Label label = labels.get(k);
					if(label.q > data.Q) {
						System.out.println("Capacity Error !");
						System.exit(0);
					}
					double rc = label.c;
					ArrayList<Integer> column = get_column(data, label);
					if (rc < thresh_hold)
						negative_column.add(column);
					if (label.N1 == 0x00 && label.N2 == 0x00 && label.N3 == 0x00 && label.N4 == 0x00)
						elementary_column.add(column);
					if(rc < thresh_hold && label.N1 == 0x00 && label.N2 == 0x00 && label.N3 == 0x00 && label.N4 == 0x00){ // store the elementary column
//						ArrayList<Integer> column = get_column(data, label);
						Check.check_column(data, lp.node, column, label.q);
						check_elimentary(data, column);
						check_reduced_cost(data, lp, column, rc);
						if(lp.pool.column2i(column) == -1 && map.contains(column) == false){
							columns.add(column);
							reduced_cost.add(rc);
							map.add(column);
						}
					}
				}
			}
			System.out.print("elementary label size>>>" + elementary_column.size() + "\t");
			System.out.print("negative label size>>>" + negative_column.size() + "\t");
			System.out.println("final label size>>>" + columns.size() + "\t");
			break;
		}
		//reduction
		ArrayList<Double> new_reduced_cost = new ArrayList<Double>();
		ArrayList<ArrayList<Integer>> new_columns = new ArrayList<ArrayList<Integer>>();
		while(new_columns.size() <= 100 && columns.size() > 0){
			int best_id = -1;
			double min_cost = 1e15;
			for(int i = 0; i < reduced_cost.size(); i++){
				double rc = reduced_cost.get(i);
				if(rc < min_cost){
					min_cost = rc;
					best_id = i;
				}
			}
			new_reduced_cost.add(reduced_cost.get(best_id));
			new_columns.add(columns.get(best_id));
			reduced_cost.remove(best_id);
			columns.remove(best_id);
		}
		columns.clear();
		reduced_cost.clear();
		for(int i = 0; i < new_columns.size(); i++){
			columns.add(new_columns.get(i));
			reduced_cost.add(new_reduced_cost.get(i));
		}
		return reduced_cost;
	}
	

	public static void check_elimentary(Data data, ArrayList<Integer> column){
		int[] visit = new int[data.n];
		for(int i = 1; i <= column.get(0); i++){
			int id = column.get(i);
			visit[id]++;
			if(visit[id] > 1){
				System.out.println("elementary constraints voilated");
				System.out.println(Help.col2str2(column));
				System.exit(0);
			}
		}
	}
	
	public static void print_set(Data data, long C1, long C2, long C3, long C4){
		int count = 0;
		for(int i = 0; i < data.n; i++){
			if(i < 64){
				if((data.mask[i] & C1) != 0x00){
					System.out.print(i + " ");
					count++;
				}
			}
			else if(i < 128){
				if((data.mask[i] & C2) != 0x00){
					System.out.print(i + " ");
					count++;
				}
			}
			else if(i < 192){
				if((data.mask[i] & C3) != 0x00){
					System.out.print(i + " ");
					count++;
				}
			}
			else {
				if((data.mask[i] & C4) != 0x00){
					System.out.print(i + " ");
					count++;
				}
			}
		}
		System.out.println();
		System.out.println(count);
	}
	
	public boolean debug_column(ArrayList<Integer> route){
		if(route.get(0) == 10 && route.get(1) == 104 && route.get(2) == 82 && route.get(3) == 29 && route.get(4) == 28 &&
				route.get(5) == 82 && route.get(6) == 115 && route.get(7) == 104 && route.get(8) == 104 &&
				route.get(9) == 115 && route.get(10) == 115){
			return true;
		}
		return false;
	}
	
	//check labels generated
	public double get_rc(RMP lp, ArrayList<Integer> column){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		return rc;
	}
	
	//check the reduced cost of a column
	public static void check_reduced_cost(Data data, RMP lp, ArrayList<Integer> column, double target){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		if(Math.abs(rc - target) > 1e-3){
			System.out.println("dp reduced cost error: " + rc + " " + target);
			System.out.println("cost " + cost + " profit " + dual_profit);
			System.out.println(Help.col2str2(column));
			System.out.println("mu:");
			double sum_mu = 0;
			for(int i = 1; i <= column.get(0); i++){
				System.out.print(column.get(i) + "(" + lp.mu[column.get(i)] + ") ");
				sum_mu += lp.mu[column.get(i)];
			}
			System.out.println("mu[data.n]: " + lp.mu[data.n]);
			System.out.println("sum_mu: " + (sum_mu + lp.mu[data.n]));
			System.out.println();
			for(int i = 0; i < lp.sr_cuts.size(); i++){
				ArrayList<Integer> cut = lp.sr_cuts.get(i);
				for(int j = 0; j < cut.size(); j++){
					System.out.print(cut.get(j) + " ");
				}
				System.out.println(": " + lp.sr_dual.get(i));
			}
			for(int i = 1; i <= column.get(0); i++){
				int id1 = column.get(i);
				int id2 = data.n;
				if(column.get(i + column.get(0)) >= 0)
					id2 = column.get(column.get(i + column.get(0)));
				System.out.println(id1 + " " + id2 + " " + lp.dual_arc[id1][id2] + " " + data.d[id1][id2]);
			}
			System.exit(0);
		}
	}
	public static ArrayList<Integer> transform(Data data, int size, int[] tree){
		ArrayList<Integer> column = new ArrayList<Integer>();
		ArrayList<Integer> place = new ArrayList<Integer>();
		Stack<Integer> stack = new Stack<Integer>();
		Stack<Integer> father_stack = new Stack<Integer>();
		for(int i = 0; i < data.n; i++){
			if(tree[i] == data.n){
				stack.add(i);
				father_stack.add(-1);
				break;
			}
		}
		column.add(size);
		while(stack.isEmpty() == false){
			int x = stack.pop();
			int father = father_stack.pop();
			column.add(x);
			place.add(father);
			ArrayList<Integer> ids = new ArrayList<Integer>();
			for(int i = 0; i < tree.length; i++){
				if(tree[i] == x){
					int insert = 0;
					while(insert < ids.size() && i < ids.get(insert))
						insert++;
					ids.add(insert, i);
				}
			}
			for(int i = 0; i < ids.size(); i++){
				stack.add(ids.get(i));
				father_stack.add(column.size() - 1);
			}
		}
		for(int i = 0; i < place.size(); i++){
			column.add(place.get(i));
		}
		return column;
	}
	
	public static  ArrayList<Integer> get_column(Data data, Label label){
		int[] tree = new int[data.n];
		Arrays.fill(tree, -1);
		set_tree(label, tree);
		tree[label.root] = data.n; //new change
		return transform(data, label.q, tree);
	}
	
	public static void set_tree(Label label, int[] tree){
		if(label.child1 != null){
			if(label.arc1 == 1)
				tree[label.child1.id] = label.id;
			else if(label.arc1 == 2)
				tree[label.id] = label.child1.id;
			set_tree(label.child1, tree);
		}
		if(label.child2 != null){
			if(label.arc2 == 1)
				tree[label.child2.id] = label.id;
			else if(label.arc2 == 2)
				tree[label.id] = label.child2.id;
			set_tree(label.child2, tree);
		}
	}
	
}