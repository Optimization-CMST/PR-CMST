package BPC.JC;

import BPC.LP.RMP;
import Common.Data;
import Helper.Check;

import java.util.ArrayList;
import java.util.HashSet;

public class JOIN {

	public static boolean is_relax = false;

	public static double f_sr_handle(RMP lp, Label label, int i){
		double sum_sr = 0;
		if(lp.is_sr_add == false)
			return sum_sr;
		ArrayList<Integer> node_set = lp.sr_node_set.get(i);
		for(int j = 0; j < label.sr_set.size(); j++){
			int s1 = label.sr_set.get(j);
			int s2 = node_set.get(j);
			sum_sr += lp.sr_comp[j][s1 & s2];
		}
		return sum_sr;
	}
	
	public  static double join(Data data, RMP lp, boolean _is_relax, ArrayList<Label>[][] FT_pes, ArrayList<Label>[][]BT, long C1, long C2, long C3, long C4, double[][] fb, double[][] bb, double thresh_hold, int col_size, ArrayList<Double> reduced_cost, ArrayList<ArrayList<Integer>> columns, HashSet<ArrayList<Integer>> map, double min_cost, long[] N, int[] count){
		// 这里的join分成两部分，第一部分的join 是scenario 0 情况下的join。 第二种情况是其他情况的join
		is_relax = _is_relax;
		int smallcap_forward = (int)Math.floor((double)data.Q/2);
		int smallcap_back = data.Q - smallcap_forward;
		int cap_start = (int)Math.floor((double)data.Q/2) + 2;
		int cap_end = data.Q;
		for (int q = cap_start; q <= cap_end; q++){    // 每次要找的是总capacity为q
			for (int g = 1; g <= (int)Math.ceil((double)q/2); g++){   // 这里的g指的是backward
				for (int i = 0; i < data.n; i++){
					int minQ = q - g - (int)Math.floor(((double)q)/ 2.0) + 1;
					ArrayList<Label> set1 = BT[i][g];
					ArrayList<Label> set2 = FT_pes[i][q - g];
					for (int x = 0; x < set1.size(); x++)
						for (int y = 0; y < set2.size(); y++){
							Label label1 = set1.get(x);
							Label label2 = set2.get(y);
							//check feasibility
							if (label2.min_subQ == 0) {
								System.out.println("Error subQ!!!");
								System.exit(-1);
							}
							if (label2.min_subQ < minQ) continue;
							if(label1.c + label2.c >= thresh_hold)
								continue;
							if((label1.V1 & label2.V1 & C1) != 0x00 || (label1.V2 & label2.V2 & C2) != 0x00 || (label1.V3 & label2.V3 & C3) != 0x00 || (label1.V4 & label2.V4 & C4) != 0x00)
								continue;
							Label new_label = new Label();
							new_label.c = label1.c + label2.c;
							new_label.id = i;
							new_label.q = label1.q + label2.q;
							new_label.V1 = label1.V1 | label2.V1;
							new_label.V2 = label1.V2 | label2.V2;
							new_label.V3 = label1.V3 | label2.V3;
							new_label.V4 = label1.V4 | label2.V4;
							new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
							new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
							new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
							new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
							if(new_label.c >= min_cost && (new_label.N1 | new_label.N2 | new_label.N3 | new_label.N4) != 0x00)
								continue;
							new_label.child1 = label1;
							new_label.child2 = label2;
							new_label.arc1 = 0;
							new_label.arc2 = 0;
							new_label.root = label1.root;
							//handle the sr cuts
							if(lp.is_sr_add){
								EXTEND.f_sr_handle2(lp, label1, label2, new_label);
							}
						if(new_label.c < thresh_hold && new_label.N1 == 0x00 && new_label.N2 == 0x00 && new_label.N3 == 0x00 && new_label.N4 == 0x00) {
							ArrayList<Integer> column = Check.get_column(data, new_label);
							Check.check_column(data, lp.node, column, new_label.q);
							Check.check_elimentary(data, column);
							Check.check_reduced_cost(data, lp, column, new_label.c);
							check_critical(data, new_label, column);
							if (lp.pool.column2i(column) == -1 && map.contains(column) == false) {
								columns.add(column);
								reduced_cost.add(new_label.c);
								map.add(column);
							}
						}

						if(new_label.c < min_cost){
							min_cost = new_label.c;
							N[0] = new_label.N1;
							N[1] = new_label.N2;
							N[2] = new_label.N3;
							N[3] = new_label.N4;
						}
						if(columns.size() > col_size){
							System.out.println("join 1 count: " + count[0]);
							return min_cost;
						}
					}
					if(data.time_out())
						break;
				}
				if(data.time_out())
					break;
			}
		}
		return min_cost;
	}
	
	public static void check_critical(Data data, Label label, ArrayList<Integer> column){
		int[] set = new int[data.n];
		for(int i = 1; i <= column.get(0); i++){
			int id = column.get(i);
			set[id] = 1;
		}
		for(int i = 0; i < data.n; i++){
			boolean mark = true;
			if(i < 64){
				if((data.mask[i] & label.V1) == 0x00)
					mark = false;
			}
			else if(i < 128){
				if((data.mask[i] & label.V2) == 0x00)
					mark = false;
			}
			else if(i < 192){
				if((data.mask[i] & label.V3) == 0x00)
					mark = false;
			}
			else {
				if((data.mask[i] & label.V4) == 0x00)
					mark = false;
			}
			if(mark == true && set[i] == 0 || mark == false && set[i] == 1){
				System.out.println("critical set error " + i);
				System.exit(0);
			}
		}
	}

	public static void update_bb(Data data, RMP lp, int i, ArrayList<Label> FT, double[][] bb){
		double[] new_bb = new double[data.Q + 1];
		for(int q = 1; q < data.Q; q++){
			new_bb[q] = 1e10;
		}
		for(int j = 0; j < FT.size(); j++){
			Label fl = FT.get(j);
			if(fl.c + lp.mu[i] < new_bb[fl.q]){
				new_bb[fl.q] = fl.c + lp.mu[i] ;
			}
		}
		for(int q = 1; q < data.Q; q++){
			double bound = 1e10;
			for(int w = 1; w <= data.Q - q + 1; w++){
				if(new_bb[w] > bound)
					bound = new_bb[w];
			}
			if(bound > bb[i][q])
				bb[i][q] = bound;
		}
	}
}
