package BPC.Branch;

import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRBException;

import java.util.ArrayList;

//branch on whether a panel is a root
public class BCV {
	public Data data;
	public double fv;
	public Node left_node;
	public Node right_node;
	
	public BCV(Data d){
		data = d;
	}
	
	public boolean fraction_v(RMP lp){
		fv = 0;
		for(int i = 0; i < lp.active_value.size(); i++){
			fv += lp.active_value.get(i);
		}
		if(Help.is_fractional(fv) == false)
			return false;
		if(Help.frac_cost(fv) > 0.4)
			return false;
		return true;
	}
	
	public void get_cuts(RMP lp, Node node){
		node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
		node.sr_cuts = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < lp.useful_sr.size(); i++){
			ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
			node.sr_cuts.add((ArrayList<Integer>) cut.clone());
		}
	}
	
	public boolean branch(RMP lp) throws GRBException {
		if(fraction_v(lp) == false)
			return false;
		left_node = lp.node;
		right_node = lp.node.duplicate();
		left_node.sudo_cost = lp.cost;
		right_node.sudo_cost = lp.cost;
		left_node.depth ++;
		right_node.depth = left_node.depth;
		get_cuts(lp, left_node);
		get_cuts(lp, right_node);
		//--------branch on root------------------------
		//change the direction of the branching arc
		left_node.kub = Help.floor(fv);
		right_node.klb = Help.ceiling(fv);
		//--------get the left route set and the right route set-----------------
		BigMV bigm = new BigMV(data);
		left_node.column_set = bigm.get_left_routeset(lp, left_node, left_node.kub);
		right_node.column_set = bigm.get_right_routeset(lp, right_node, right_node.klb);
		if(left_node.column_set == null){
			left_node.clear();
			left_node = null;
		}		
		if(right_node.column_set == null){
			right_node.clear();
			right_node = null;
		}
		return true;
	}
}
