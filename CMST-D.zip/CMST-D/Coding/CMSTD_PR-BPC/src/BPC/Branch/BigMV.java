package BPC.Branch;

import BPC.JC.JC;
import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBConstr;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBVar;

import java.util.ArrayList;

public class BigMV {
	
	public Data data;
	public int max_iter;
	
	public BigMV(Data d){
		data = d;
		max_iter = 5;
	}
	
	public double left_modify_lp(RMP lp, double ub) throws GRBException {
		GRBConstr range = lp.root_range_UB;
		double old_ub = range.get(GRB.DoubleAttr.RHS);
		range.set(GRB.DoubleAttr.RHS, ub);
		return old_ub;
	}
	
	public boolean left_strong_change(RMP lp, double ub) throws GRBException {
		GRBConstr range = lp.root_range_UB;
		double old_ub = range.get(GRB.DoubleAttr.RHS);
		range.set(GRB.DoubleAttr.RHS, ub);
		//add a slack variable
		GRBVar slack = lp.model.addVar(0, GRB.INFINITY, 1e6, GRB.CONTINUOUS, "slack");
		lp.model.chgCoeff(range, slack, -1);
		//re-optimize the problem
		if(lp.solve() == false){
			System.out.println("left_strong change, should not solve false");
			System.exit(-1);
		}
		lp.set_dual();
		JC gc = new JC(data);
		boolean success = false;
		int iter = 0;
		System.out.println("restore left node feasibility: intial lp cost: " + lp.cost);
		long[] CX = new long[4];
		while(iter++ < 10){
			ArrayList<Integer> index = new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> columns = new ArrayList<ArrayList<Integer>>();
			ArrayList<Double> reduced_cost = gc.solve(lp, -1e-1, CX, columns, false);
			for(int i = 0; i < columns.size(); i++){
				ArrayList<Integer> column = columns.get(i);
				double rc = reduced_cost.get(i);
				//debug the reduced cost
				if(rc < -1e-3 && lp.pool.column2i(column) == -1){
					index.add(lp.pool.add_column(column));
				}
			}
			lp.add_col(index);
			lp.solve();
			lp.set_dual();
			System.out.println("restore left node feasibility dp: " + index.size() + " " + lp.cost);
			//check the feasibility of the problem:
			boolean all_zero = true;
			if (slack.get(GRB.DoubleAttr.X) > 1e-6) {
				all_zero = false;
			}
			if (all_zero){
				lp.set_value();
				success = true;
				break;
			}
			if (index.size() <= 0)
				break;
		}
		//restore the model
		range.set(GRB.DoubleAttr.RHS, old_ub);
		lp.model.remove(slack);
		return success;
	}
	
	public double right_modify_lp(RMP lp, double lb) throws GRBException {
		//add the constraints
		GRBConstr range = lp.root_range_LB;
		double old_lb = range.get(GRB.DoubleAttr.RHS);
		range.set(GRB.DoubleAttr.RHS, lb);
		return old_lb;
	}
	
	public boolean right_strong_change(RMP lp, double lb) throws GRBException {
		GRBConstr range =  lp.root_range_LB;
		double old_lb = range.get(GRB.DoubleAttr.RHS);
		range.set(GRB.DoubleAttr.RHS, lb);
		//add a slack variable
		GRBVar slack = lp.model.addVar(0, GRB.INFINITY, 1e6, GRB.CONTINUOUS, "slack");
		lp.model.chgCoeff(range, slack, 1);
		//re-optimize the problem
		if(lp.solve() == false){
			System.out.println("right_strong change, should not solve false");
			System.exit(-1);
		}
		lp.set_dual();
		JC gc = new JC(data);
		boolean success = false;
		int iter = 0;
		System.out.println("restore ritht node feasibility: intial lp cost: " + lp.cost);
		long[] CX = new long[4];
		while(iter++ < 10){
			ArrayList<Integer> index = new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> columns = new ArrayList<ArrayList<Integer>>();
			ArrayList<Double> reduced_cost = gc.solve(lp, -1e-1, CX, columns, false);
			for(int i = 0; i < columns.size(); i++){
				ArrayList<Integer> column = columns.get(i);
				double rc = reduced_cost.get(i);
				//debug the reduced cost
				if(rc < -1e-3 && lp.pool.column2i(column) == -1){
					index.add(lp.pool.add_column(column));
				}
			}
			lp.add_col(index);
			lp.solve();
			lp.set_dual();
			System.out.println("restore left node feasibility dp: " + index.size() + " " + lp.cost);
			//check the feasibility of the problem:
			boolean all_zero = true;
			if (slack.get(GRB.DoubleAttr.X) > 1e-6) {
				all_zero = false;
			}
			if (all_zero){
				lp.set_value();
				success = true;
				break;
			}
			if (index.size() <= 0)
				break;
		}
		//restore the model
		range.set(GRB.DoubleAttr.RHS, old_lb);
		lp.model.remove(slack);
		return success;
	}
	
	//get_left_routeset must be invoked before get_right_routeset
	public ArrayList<ArrayList<Integer>> get_left_routeset(RMP lp, Node node, int ub) throws GRBException {
		ArrayList<ArrayList<Integer>> retS = null;
		//modify the lp
		double old_ub = left_modify_lp(lp, ub);
		lp.model.optimize();
		int status = lp.model.get(GRB.IntAttr.Status);
		if(status == GRB.Status.OPTIMAL){
			retS = new ArrayList<>();
			lp.get_columns(retS);
		}
		//restore the lp
		left_modify_lp(lp, old_ub);
		
		if(retS == null){         // current columns are infeasible
			//use gc to restore the feasibility of the problem
			Node backup_node = lp.node;
			lp.node = node;
			boolean success = left_strong_change(lp, ub);
			lp.node = backup_node;
			if(success){
				retS = new ArrayList<ArrayList<Integer>>();
				lp.get_columns(retS);
				System.out.println("restore left node feasibility success");
			}
			else{
				System.out.println("restore left node feasibility fail");
			}
		}
		
		return retS;
	}
	
	public ArrayList<ArrayList<Integer>> get_right_routeset(RMP lp, Node node, int lb) throws GRBException {
		ArrayList<ArrayList<Integer>> retS = null;
		//modify the lp
		double old_lb = right_modify_lp(lp, lb);
		lp.model.optimize();
		int status = lp.model.get(GRB.IntAttr.Status);
		if(status == GRB.Status.OPTIMAL){
			retS = new ArrayList<>();
			lp.get_columns(retS);
		}
		right_modify_lp(lp, old_lb);
		if(retS == null){
			//use gc to restore the feasibility of the problem
			Node backup_node = lp.node;
			lp.node = node;
			boolean success = right_strong_change(lp, lb);
			lp.node = backup_node;
			if(success){
				retS = new ArrayList<ArrayList<Integer>>();
				lp.get_columns(retS);
				System.out.println("restore right node feasibility success");
			}
			else{
				System.out.println("restore right node feasibility fail");
			}
		}
		return retS;
	}
}
