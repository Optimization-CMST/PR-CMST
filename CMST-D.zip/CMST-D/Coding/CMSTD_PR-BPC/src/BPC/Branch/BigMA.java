package BPC.Branch;

import BPC.JC.JC;
import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBVar;

import java.util.ArrayList;

public class BigMA {
	
	public Data data;
	public int max_iter;
	
	public BigMA(Data d){
		data = d;
		max_iter = 5;
	}
	
	public void left_modify_lp(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
		for(int i = 0; i < zero_set.size(); i++){
			GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
			var.set(GRB.DoubleAttr.UB, 0);
		}
	}
	
	public void left_restore_lp(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
		for(int i = 0; i < zero_set.size(); i++){
			GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
			var.set(GRB.DoubleAttr.UB, 1);
		}
	}
	
	public boolean left_strong_change(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Integer> set = lp.ij2ri.get(id1).get(id2);
		ArrayList<Double> column_cost = new ArrayList<Double>();
		ArrayList<GRBVar> vars = new ArrayList<GRBVar>();
		for(int i = 0; i < set.size(); i++){
			GRBVar var = lp.column_vars.get(lp.r2p.get(set.get(i)));
			vars.add(var);
			column_cost.add(lp.pool.get_column_cost(set.get(i)));
		}
		//change the coefficients of the objective
		for(int i = 0; i < vars.size(); i++){
			vars.get(i).set(GRB.DoubleAttr.Obj, 1e6);
		}
		//re-optimize the problem
		if(lp.solve() == false){
			System.out.println("left_strong change, should not solve false");
			System.exit(-1);
		}
		lp.set_dual();
		JC gc = new JC(data);
		long[] CX = new long[4];
		boolean success = false;
		int iter = 0;
		System.out.println("restore left node feasibility: intial lp cost: " + lp.cost);
		while(iter++ < 10){
			ArrayList<Integer> index = new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> columns = new ArrayList<ArrayList<Integer>>();
			ArrayList<Double> reduced_cost = gc.solve(lp, -1e-1, CX, columns, false);
			for(int i = 0; i < columns.size(); i++){
				ArrayList<Integer> column = columns.get(i);
				double rc = reduced_cost.get(i);
				//debug the reduced cost
				if(rc < -1e-3 && lp.pool.column2i(column) == -1){
					index.add(lp.pool.add_column(column));
				}
			}
			lp.add_col(index);
			lp.solve();
			lp.set_dual();
			System.out.println("restore left node feasibility dp: " + index.size() + " " + lp.cost);
			//check the feasibility of the problem:
			boolean all_zero = true;
			for(int i = 0; i < vars.size(); i++){
				if(vars.get(i).get(GRB.DoubleAttr.X) > 1e-6){
					all_zero = false;
					break;
				}
			}
			if(all_zero){
				lp.set_value();
				success = true;
				break;
			}
			if(index.size() <= 0)
				break;
		}
		//restore the model
		for(int i = 0; i < vars.size(); i++){
			vars.get(i).set(GRB.DoubleAttr.Obj, column_cost.get(i));
		}
		return success;
	}
	
	public void right_modify_lp(RMP lp, int id1, int id2) throws GRBException {
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
				for(int j = 0; j < zero_set.size(); j++){
					GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
					var.set(GRB.DoubleAttr.UB, 0);
				}
			}
		}
	}
	
	public void right_restore_lp(RMP lp, int id1, int id2) throws GRBException {
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
				for(int j = 0; j < zero_set.size(); j++){
					GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
					var.set(GRB.DoubleAttr.UB, 1);
				}
			}
		}
	}
	
	public boolean right_strong_change(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Double> column_cost = new ArrayList<Double>();
		ArrayList<GRBVar> vars = new ArrayList<GRBVar>();
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
				for(int j = 0; j < zero_set.size(); j++){
					GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
					vars.add(var);
					column_cost.add(lp.pool.get_column_cost(zero_set.get(j)));
				}
			}
		}
		//change the coefficients of the objective
		for(int i = 0; i < vars.size(); i++){
			vars.get(i).set(GRB.DoubleAttr.Obj, 1e6);
		}
		//re-optimize the problem
		if(lp.solve() == false){
			System.out.println("right_strong change, should not solve false");
		}
		lp.set_dual();
		JC gc = new JC(data);
		long[] CX = new long[4];
		boolean success = false;
		int iter = 0;
		System.out.println("restore right node feasibility: intial lp cost: " + lp.cost);
		while(iter++ < 10){
			ArrayList<Integer> index = new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> columns = new ArrayList<ArrayList<Integer>>();
			ArrayList<Double> reduced_cost = gc.solve(lp, -1e-1, CX, columns, false);
			for(int i = 0; i < columns.size(); i++){
				ArrayList<Integer> column = columns.get(i);
				double rc = reduced_cost.get(i);
				//debug the reduced cost
				if(rc < -1e-3 && lp.pool.column2i(column) == -1){
					index.add(lp.pool.add_column(column));
				}
			}
			lp.add_col(index);
			lp.solve();
			lp.set_dual();
			System.out.println("restore right node feasibility dp: " + index.size() + " " + lp.cost);
			//check the feasibility of the problem:
			boolean all_zero = true;
			for(int i = 0; i < vars.size(); i++){
				if(vars.get(i).get(GRB.DoubleAttr.X) > 1e-6){
					all_zero = false;
					break;
				}
			}
			if(all_zero){
				lp.set_value();
				success = true;
				break;
			}
			if(index.size() <= 0)
				break;
		}
		//restore the model
		for(int i = 0; i < vars.size(); i++){
			vars.get(i).set(GRB.DoubleAttr.Obj, column_cost.get(i));
		}
		return success;
	}
	
	//get_left_routeset must be invoked before get_right_routeset
	public ArrayList<ArrayList<Integer>> get_left_routeset(RMP lp, Node node, int id1, int id2) throws GRBException {
		ArrayList<ArrayList<Integer>> retS = null;
		//modify the lp
		left_modify_lp(lp, id1, id2);
		lp.model.optimize();
		int status = lp.model.get(GRB.IntAttr.Status);
		if(status == GRB.Status.OPTIMAL){
			retS = new ArrayList<ArrayList<Integer>>();
			lp.set_value();
			lp.set_dual();
			lp.get_columns(retS);
		}
		//restore the lp
		left_restore_lp(lp, id1, id2);
		
		if(retS == null){
			//use gc to restore the feasibility of the problem
			Node backup_node = lp.node;
			lp.node = node;
			boolean success = left_strong_change(lp, id1, id2);
			lp.node = backup_node;
			if(success){
				retS = new ArrayList<ArrayList<Integer>>();
				lp.get_columns(retS);
				System.out.println("restore left node feasibility success");
			}
			else{
				System.out.println("restore left node feasibility fail");
			}
		}
		return retS;
	}
	
	public ArrayList<ArrayList<Integer>> get_right_routeset(RMP lp, Node node, int id1, int id2) throws GRBException {
		ArrayList<ArrayList<Integer>> retS = null;
		//modify the lp
		right_modify_lp(lp, id1, id2);
		lp.model.optimize();
		int status = lp.model.get(GRB.IntAttr.Status);
		if(status == GRB.Status.OPTIMAL){
			retS = new ArrayList<ArrayList<Integer>>();
			lp.set_value();
			lp.set_dual();
			lp.get_columns(retS);
		}
		
		//restore the lp
		right_restore_lp(lp, id1, id2);
		
		if(retS == null){
			//use gc to restore the feasibility of the problem
			Node backup_node = lp.node;
			lp.node = node;
			boolean success = right_strong_change(lp, id1, id2);
			lp.node = backup_node;
			if(success){
				retS = new ArrayList<ArrayList<Integer>>();
				lp.get_columns(retS);
				/*
				for(int i = 0; i < lp.active_set.size(); i++){
					int index = lp.active_set.get(i);
					ArrayList<Integer> column = lp.pool.get_column(index);
					retS.add((ArrayList<Integer>) column.clone());
				}
				*/
				System.out.println("restore right node feasibility success");
			}
			else{
				System.out.println("restore right node feasibility fail");
			}
		}
		return retS;
	}
}
