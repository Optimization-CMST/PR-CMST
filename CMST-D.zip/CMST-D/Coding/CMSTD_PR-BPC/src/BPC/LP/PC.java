package BPC.LP;

import BPC.Cut.*;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Scanner;

public class PC {

	public Data data;
	public boolean keep;
	public long[] keep_C;

	public PC(){}
	
	public PC (Data d) {
		data = d;
		keep = false;
		keep_C = new long[4];
	}
	
	public ArrayList<Integer> cut_set2idx(RMP lp, ArrayList<ArrayList<Integer>> cuts, ArrayList<Integer> rights){
		ArrayList<Integer> index_set = new ArrayList<Integer>();
		for(int i = 0; i < cuts.size(); i++){
			int index = lp.cut_pool.add_cut(cuts.get(i), rights.get(i));
			index_set.add(index);
		}
		return index_set;
	}
	
	public boolean add_cut(RMP lp) throws GRBException {
		CSep csep = new CSep(data);
		CSep2 csep2 = new CSep2(data);
		System.out.println("start seperating capapcity and 2-path inequality");
		csep.solve(lp);
		csep2.solve(lp);
		System.out.println("end seperating capapcity and 2-path inequality");
		ArrayList<ArrayList<Integer>> cuts = new ArrayList<ArrayList<Integer>>();
		HashSet<ArrayList<Integer>> cut_map = new HashSet<ArrayList<Integer>>();
		ArrayList<Integer> rights = new ArrayList<Integer>();
		for(int i = 0; i < csep.retS.size(); i++){
			ArrayList<Integer> cut = csep.retS.get(i);
			int right = csep.rightS.get(i);
			Collections.sort(cut);
			if(cut_map.contains(cut) == false){
				cuts.add(cut);
				cut_map.add(cut);
				rights.add(right);
			}
		}
		for(int i = 0; i < csep2.retS.size(); i++){
			ArrayList<Integer> cut = csep2.retS.get(i);
			int right = csep2.rightS.get(i);
			Collections.sort(cut);
			if(cut_map.contains(cut) == false){
				cuts.add(cut);
				cut_map.add(cut);
				rights.add(right);
			}
		}
		if(cuts.size() == 0)
			return false;
		data.total_cap_num += cuts.size();
		ArrayList<Integer> cut_index = cut_set2idx(lp, cuts, rights);
		System.out.println("cut size " + cuts.size());
		lp.add_cuts(cut_index);
		System.out.println("finish adding capapcity and 2-path  inequality-----------------------------------------");
		return true;
	}
	
	
	public boolean add_sr_cut(RMP lp) throws GRBException {
		SRSep sr_sep = new SRSep(data);
		System.out.println("start seperating SR inequality");
		sr_sep.solve(lp, 20);
		System.out.println("end seperating SR inequality");
		if(sr_sep.retS.size() == 0){
			return false;
		}
		data.total_sr_num += sr_sep.retS.size();
		System.out.println("new cut size " + sr_sep.retS.size());
		lp.add_sr_cut(sr_sep.retS);
		System.out.println("total cut size " + lp.sr_cuts.size());
		System.out.println("finish adding SR  inequality-----------------------------------------");
		return true;
	}
	
	
	public void solve(RMP lp, double ub) throws FileNotFoundException, GRBException {
		//ArrayList<ArrayList<Integer>> optimal_set = read_optimal("optimal.txt");
		//System.out.println(optimal_set);
		LPSOLVE lp_solve = new LPSOLVE(data);
//		LPSOLVE_elementary E_lp_solve = new LPSOLVE_elementary(data);
		boolean flag = true;
		double t1 = System.nanoTime();
		while(true){
			double gc_ub = 1e10;
			if(data.is_root == false)
				gc_ub = ub - 1;
		   lp_solve.solve(lp, flag, lp.node.C, gc_ub);
		   if(keep == false && lp_solve.keep == true){
			   for(int i = 0; i < 4; i++)
				   keep_C[i] = lp_solve.keep_C[i];
			   keep = true;
		   }

//		   if(true){
//			   double t2 = System.nanoTime();
//			   System.out.println("lp cost: " + lp.cost + " " + "lp time: " + (t2 - t1)/1e9);
//			   System.out.println("pruning time" + (data.DP_1_time  + data.DP_2_time + data.DP_NG_time));
//			   System.out.println("Join time :" + data.join_time/1e9);
//			   System.exit(-1);
//		   }


//		   double t2 = System.nanoTime();
//		   if(data.is_root && data.root_lp_time < 1e-3){
//			   data.lp_cost = lp.cost;
//			   data.root_lp_time = t2 - t1;
//		   }
//		   System.out.println("lp cost: " + lp.cost + " " + "lp time: " + (t2 - t1)/1e9);
//		   System.out.println("DP_1 time" + data.DP_1_time);
//		   System.out.println("ng time" + data.DP_NG_time);


//		 //  solve the first node
//		   if(true)
//			   break;
//		   flag = false;
		   if(lp.cost > ub - 1 && Math.abs(lp.cost - ub + 1) > 1e-5)
			   break;
		   boolean ret = add_cut(lp);
		   if(lp.is_sr_add || ret == false){
			   ret = add_sr_cut(lp);
			   if(ret == false) {
//				   double t2 = System.nanoTime();
//				   System.out.println("lp cost: " + lp.cost + " " + "lp time: " + (t2 - t1)/1e9);
//				   System.out.println("pruning time" + (data.DP_1_time  + data.DP_2_time + data.DP_NG_time));
//				   System.exit(-1);
				   break;
			   }
		   }
			double t2 = System.nanoTime();
			if(data.is_root && data.root_lp_time < 1e-3){
				data.lp_cost = lp.cost;
				data.root_lp_time = t2 - t1;
			}
		}
		lp.set_useful();
		double t3 = System.nanoTime();
		System.out.println("lp cost: " + lp.cost + " " + "total lp time: " + (t3 - t1)/1e9);
		System.out.println("Capacity Cuts : " + data.total_cap_num + "\t" + "SR Cuts :" + data.total_sr_num);
//		lp.node.tsr = -lp.sum_sr;
		/*
		double total_v = 0;
		double size_v = 0;
		for(int i =  0; i < lp.active_set.size(); i++){
			double v = lp.active_value.get(i);
			ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
			IloNumVar var = lp.matrix.getNumVar(lp.r2p.get(lp.active_set.get(i)));
			//System.out.println(column + " " + lp.cplex.getReducedCost(var));
			for(int j = 0; j < column.size(); j++){
				System.out.print(column.get(j) + " ");
			}
			System.out.println();
			total_v += v;
			if(column.get(0) >= data.n / data.Q)
				size_v += v;
		}
		System.out.println("total v: " + total_v);
		System.out.println("size v: " + size_v);
		*/

		if(data.is_root){
			data.lpc_cost = lp.cost;
			data.root_lpc_time = t3 - t1;
		}
		if(data.is_root){
			data.root_cap_num = lp.cap_index.size();
			data.root_sr_num = lp.sr_cuts.size();
		}
		
		//print the reduced cost
		/*
		for(int i = 0; i < optimal_set.size(); i++){
			ArrayList<Integer> column = optimal_set.get(i);
			System.out.println(column + " " + get_rc(lp, column));
		}
		System.exit(0);
		*/
	}
	
	public ArrayList<ArrayList<Integer>> read_optimal(String path) throws FileNotFoundException{
		Scanner cin=new Scanner(new BufferedReader(new FileReader(path)));
		ArrayList<ArrayList<Integer>> route_set = new ArrayList<ArrayList<Integer>>();
		//cin.nextLine();
		while(cin.hasNextLine()){
			String line = cin.nextLine();
			String[] str= line.split(" ");
			ArrayList<Integer> route = new ArrayList<Integer>();
			for(int i = 0; i < str.length; i++){
				route.add(Integer.parseInt(str[i]));
			}
			route_set.add(route);
		}
		return route_set;
	}
	
	public double get_rc(RMP lp, ArrayList<Integer> column){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		return rc;
	}
}
