import BPC.SearchTree.Tree;
import Common.Data;
import Common.Input;
import Helper.Check;
import Heuristic_UB.Simple_UB;
import Heuristic_UB.Ub;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Run_UB {
    public static void main(String[] args) throws IOException, GRBException {
        for (int inst = 1; inst <= 27; inst++) {
            // initialization
            String[] INSTANCES = {"tc40-1", "tc80-1", "tc80-2", "tc80-3", "tc80-4", "tc80-5",
                    "te80-1", "te80-2", "te80-3", "te80-4", "te80-5",
                    "td80-1", "td80-2", "td80-3", "td80-4", "td80-5",
                    "tc120-1", "tc120-2", "tc120-3", "tc120-4", "tc120-5",
                    "te120-1", "te120-2", "te120-3", "te120-4", "te120-5",
                    "tc160-1", "te160-1"};
            String instance = "instance/cmst/unit_demand/" + INSTANCES[inst] + ".txt";
            int Capacity = 5;
            Data data = Input.read_CMST(instance, Capacity);
            data.build_mask();
            data.name = INSTANCES[inst];


            double t1 = System.nanoTime();
            ArrayList<ArrayList<Integer>> ub_trees = new ArrayList<ArrayList<Integer>>();
            double ub = Ub.get_ub(instance, data.Q, ub_trees);
            System.out.println("upper bound: " + ub);
            Check.check_solution(data, null, ub_trees);
            double t2 = System.nanoTime();

            String output_Path = "UB_values_Q_5/" + data.name + "_" + "UB.txt";
            BufferedWriter writer = new BufferedWriter(new FileWriter(output_Path));
            writer.write("UB value : " + ub);
            writer.newLine();
            writer.write("Running Time : " + String.format("%.2f", (t2 - t1)/1e9));
            writer.close();
        }
    }
}