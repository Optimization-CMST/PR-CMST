package BPC.JC;


import BPC.GC.DP;
import BPC.GC.NG_DP;
import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;

public class JC {

	public Data data;
	//critical resource information
	double[][] fb;
	double[][] bb;
	public int keep_size;
	public boolean keep;
	public boolean is_relax = false;
	public long[] keep_C;
	int keep_num = -1;
	public boolean is_cut_added = true;

	public JC(Data d){
		data = d;
		keep_size = (int) (data.n * 0.6);
		keep_num = (int) (data.n * 0.85);
		keep = false;
		keep_C = new long[4];
		fb = new double[data.n][data.Q];
		bb = new double[data.n][data.Q];
	}
	public void fb_bb_elimination() {
		for (int i = 0; i < fb.length; i++)
			Arrays.fill(fb[i], -1e9);
		for (int i = 0; i < bb.length; i++)
			Arrays.fill(bb[i], -1e9);
	}
	
	public void get_bound(RMP lp, double thresh_hold) {
		double bd_t1 = System.nanoTime();
		DP dp = new DP(data);
		dp.get_bound(lp, fb, bb);
		double bd_t2 = System.nanoTime();
		data.DP_1_time += bd_t2 - bd_t1;
		System.out.println("DP1 Time : " + (bd_t2 - bd_t1)/1e9);
	}
	
	public ArrayList<Double> solve(RMP lp, double thresh_hold, long[] CX, ArrayList<ArrayList<Integer>> columns, boolean _is_relax){
		is_relax = _is_relax;
		int col_size = 100;
		if(is_relax)
			col_size = 1000000000;

		//test
		int[] C_sr = new int[lp.seg_size];   // 初始化sr全为0


		long C1 = CX[0];
		long C2 = CX[1];
		long C3 = CX[2];
		long C4 = CX[3];
		
//		if (is_relax) {
			C1 = data.all_mask;
			C2 = data.all_mask;
			C3 = data.all_mask;
			C4 = data.all_mask;
//		}

		
		get_bound(lp, thresh_hold);


		double bd_t1 = System.nanoTime();
		NG_DP dp_ng = new NG_DP(data);
		dp_ng.parameter = 0.5;
		dp_ng.get_bound(lp, thresh_hold, fb, bb);
		double bd_t2 = System.nanoTime();
		if (!data.time_out()) {
			data.DP_NG_time += bd_t2 - bd_t1;
		}
		System.out.println("DP_NG Time : " + (bd_t2 - bd_t1)/1e9);
		if ((bd_t2 - bd_t1)/1e9 > 10)
			is_cut_added = false;

//		if (lp.is_sr_add){
//			double bd_t1 = System.nanoTime();
//			DP2 dp2 = new DP2(data);
//			dp2.get_bound(lp, thresh_hold, fb, bb);
//			double bd_t2 = System.nanoTime();
//			data.DP_2_time += (bd_t2 - bd_t1)/1e9;
//			System.out.println("DP2 Time : " + (bd_t2 - bd_t1)/1e9);
//		}


		long DC1 = data.intDC[0] & C1;
		long DC2 = data.intDC[1] & C2;
		long DC3 = data.intDC[2] & C3;
		long DC4 = data.intDC[3] & C4;
//		if(lp.is_sr_add){
//			NG ng = new NG(data);
//			double t3 = System.nanoTime();
//			//ng.get_bound(lp, data.Q - 2, thresh_hold, fb, bb);
//			double t4 = System.nanoTime();
//			if(data.is_root){
//				data.root_bd2_time += t4 - t3;
//			}
//		}
//		DP2 dp2 = new DP2(data);
		ArrayList<Double> reduced_cost = new ArrayList<Double>();
		HashSet<ArrayList<Integer>> map = new HashSet<ArrayList<Integer>>();
		EXTEND EXT = new EXTEND(data, is_relax);
		while(data.time_out() == false){
			ArrayList<Label>[][] FT_pes = new ArrayList[data.n][data.Q];
			ArrayList[][] BT = new ArrayList[data.n][data.Q];
			for (int i = 0; i < data.n; i++)
				for (int j = 0; j < data.Q; j++)
					FT_pes[i][j] = new ArrayList<>();
			for (int i = 0; i < data.n; i++)
				for (int j = 3; j <= 9; j++)
					BT[i][j] = new ArrayList();
			long[] in_C = new long[4];
			double min_cost = 1e10;
			//System.out.println("start dp2");
			double t5 = System.nanoTime();
//			if(is_relax == false)
//				dp2.get_bound(lp, DC1, DC2, DC3, DC4, fcap + 2, thresh_hold, fb, bb);
			double t6 = System.nanoTime();
			if(data.is_root){
				data.root_bd3_time += t6 - t5;
			}
			//System.out.println("end dp2");
			//extend
			//System.out.println("start extension...");
			double ext_t1 = System.nanoTime();
			min_cost = EXT.extend(lp, C1, C2, C3, C4, C_sr, fb, bb, thresh_hold, FT_pes, BT, col_size, columns, reduced_cost, map,  min_cost, in_C);
			if (columns.size() > col_size) break;  //此时仅仅前向产生的label就已经足以产生大于需求的col_size了，所以无需后向和join
//			update_fb(lp, BT, bcap, fb);
			if(data.time_out())
				break;
			//ArrayList<Integer> min_route = new ArrayList<Integer>();
			//manupulate the instances
			int fcount = 0;
			for (int i = 0; i < data.n; i++){
				for (int q = 1; q < (int)Math.floor(((double)data.Q/2)) + 1; q++){
					fcount += FT_pes[i][q].size();
				}
			}
			int p_fcount = 0;
			for(int i = 0; i < data.n; i++){
				for (int q = (int)Math.floor(((double)data.Q/2)) + 1; q < data.Q; q++)
					p_fcount += FT_pes[i][q].size();
			}
			int bcount = 0;
			for(int i = 0; i < data.n; i++){
				for (int q = 1; q < data.Q; q++) {
					if (BT[i][q] != null) {
						bcount += BT[i][q].size();
					}
				}
			}
			System.out.print("pesuo fcount : " + p_fcount + " fcount : " + fcount  + " bcount : " + bcount);

			if(data.is_root == true){
				data.root_flabels = fcount;
				data.root_plabels = p_fcount;
				data.root_blabels = bcount;
			}

			//joining two labels
			int[] join_count = new int[1];
			double join_t1 = System.nanoTime();
			//这里，我们已经将 Q <= (int)Math.floor(data.Q/2) + 1的 column 加入到model里，接下来加入剩余的column
			min_cost = JOIN.join(data, lp, _is_relax,  FT_pes, BT, C1, C2, C3, C4, fb, bb, thresh_hold, col_size, reduced_cost, columns, map, min_cost, in_C, join_count);
			double join_t2 = System.nanoTime();
			if(data.is_root){
				data.root_join_time += join_t2 - join_t1;
			}
			if (!data.time_out()) {
				data.total_join_time += join_t2 - join_t1;
			}
			System.out.print("\t" + " final label size>>>" + columns.size() + "\t");
			System.out.print("Set elementary>>>" + set_size(C1, C2, C3, C4));
			System.out.println("Join Time : " + (join_t2 - join_t1)/1e9);
			if(is_relax)
				break;
			if(min_cost > thresh_hold)
				break;
			if(columns.size() > col_size)   //这里需要把这个columns提前，因为，只有column的数量没超过预设值，才能保证当前求到的最小值是真正的最小值。
				break;
			if(in_C[0] == 0x00 && in_C[1] == 0x00 && in_C[2] == 0x00 && in_C[3] == 0x00)
				break;
			C1 = C1 | in_C[0];
			C2 = C2 | in_C[1];
			C3 = C3 | in_C[2];
			C3 = C3 | in_C[3];

			DC1 = DC1 | in_C[0];
			DC2 = DC2 | in_C[1];
			DC3 = DC3 | in_C[2];
			DC4 = DC4 | in_C[3];

			//keep the critical C
			if(keep == false && set_size(C1, C2, C3, C4) > keep_size){
				keep_C[0] = C1;
				keep_C[1] = C2;
				keep_C[2] = C3;
				keep_C[3] = C4;
				keep = true;
			}
			if(data.time_out())
				break;
		}
		if(_is_relax == false){
			CX[0] = C1;
			CX[1] = C2;
			CX[2] = C3;
			CX[3] = C4;
		}
//		//reduction 现在的版本不需要reduction了，因为产生的column最多就是col_size + 1
//		ArrayList<Double> new_reduced_cost = new ArrayList<Double>();
//		ArrayList<ArrayList<Integer>> new_columns = new ArrayList<ArrayList<Integer>>();
//		while(new_columns.size() <= 100 && columns.size() > 0){
//			int best_id = -1;
//			double min_cost = 1e15;
//			for(int i = 0; i < reduced_cost.size(); i++){
//				double rc = reduced_cost.get(i);
//				if(rc < min_cost){
//					min_cost = rc;
//					best_id = i;
//				}
//			}
//			new_reduced_cost.add(reduced_cost.get(best_id));
//			new_columns.add(columns.get(best_id));
//			reduced_cost.remove(best_id);
//			columns.remove(best_id);
//		}
//		columns.clear();
//		reduced_cost.clear();
//		for(int i = 0; i < new_columns.size(); i++){
//			columns.add(new_columns.get(i));
//			reduced_cost.add(new_reduced_cost.get(i));
//		}
		return reduced_cost;
	}
	
/*
	public void update_fb(LP lp, ArrayList<ArrayList<ArrayList<ArrayList<Label>>>> BT, int bcap, double[][] fb){
		//get the bounds
		for(int i = 0; i < data.n; i++){
			for(int q = data.Q - bcap + 1; q < data.Q; q++){
				fb[i][q] = db[i][data.n] - lp.mu[data.n];
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int q = data.Q - bcap + 1; q < data.Q; q++){
				for(int j = 2; j <= data.Q - q + 1; j++){
					ArrayList<Label> labels = BT.get(j).get(i).get(data.n - 2);
					for(int k = 0; k < labels.size(); k++){
						double cost = labels.get(k).c + lp.mu[i];
						if(cost < fb[i][q]){
							fb[i][q] = cost;
						}
					}
				}
			}
		}
	}
	*/
	
	public void update_fb(RMP lp, ArrayList<ArrayList<Label>> BT, int bcap, double[][] fb){
		//get the bounds
		for(int i = 0; i < data.n; i++){
			for(int q = data.Q - bcap + 1; q < data.Q; q++){
				fb[i][q] = data.d[i][data.n] - lp.dual_arc[i][data.n] - lp.mu[data.n];
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int q = data.Q - bcap + 1; q < data.Q; q++){
				for(int j = 0; j < BT.get(i).size(); j++){
					Label label = BT.get(i).get(j);
					if (label.q >= 2 && label.q <= data.Q - q + 1) {
						double cost = label.c + lp.mu[i];
						if(cost < fb[i][q]){
							fb[i][q] = cost;
						}
					}
				}
			}
		}
	}
	
	public int set_size(long C1, long C2, long C3, long C4){
		int count = 0;
		for(int i = 0; i < data.n; i++){
			if(i < 64){
				if((data.mask[i] & C1) != 0x00)
					count++;
			}
			else if(i < 128){
				if((data.mask[i] & C2) != 0x00)
					count++;
			}
			else if(i < 192){
				if((data.mask[i] & C3) != 0x00)
					count++;
			}
			else{
				if((data.mask[i] & C4) != 0x00)
					count++;
			}
		}
		return count;
	}
	

	
}