package BPC.GC;

import BPC.JC.Label;
import BPC.LP.RMP;
import Common.Data;
import Helper.Check;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.stream.IntStream;

public class NG_DP {
    public Data data;
    public double[][] db;
    public ArrayList<Label>[][][] fpool;
    public ArrayList<Integer> size;
    public static boolean is_relax = false;
    public int total_size;
    public ArrayList<Label>[][][] bpool;
    public ArrayList<Label>[][] real_fpool;
    public long[] NG1;
    public long[] NG2;
    public long[] NG3;
    public long[] NG4;
    public int N;
    public int sr_size = -1;
    public double parameter = -1;
    public int[] LB;
    public int[] UB;
    int[] C_sr;
    public int[] mask;
    public NG_DP(Data d){
        data = d;
        db = new double[data.n + 1][data.n + 1];
        int m = data.n - 1;
        size = new ArrayList<Integer>();
        while(true){
            size.add(m);
            total_size += m;
            if(m == 1)
                break;
            m = (int) Math.ceil(((double)m) / 2.0);
        }
        LB = new int[data.Q];
        UB = new int[data.Q];
        LB[1] = 1; LB[2] = 1; LB[3] = 1; LB[4] = 1; LB[5] = 1; LB[6] = 1; LB[7] = 1; LB[8] = 1; LB[9] = 1;
        UB[1] = 9; UB[2] = 8; UB[3] = 7; UB[4] = 6; UB[5] = 5; UB[6] = 4; UB[7] = 3; UB[8] = 2; UB[9] = 1;
        N = 5;
    }

    public void build_NG(RMP lp) {
        mask = new int[lp.seg_size];
        int m = 0x01;
        for(int i = 0; i < lp.seg_size; i++){
            mask[i] = m;
            m *= 2;
        }
        for(int i = 0; i < data.n + 1; i++){
            for(int j = 0; j < data.n + 1; j++){
                if (i == j)
                    db[i][j] = 0;
                else
                    db[i][j] = data.d[i][j] * 4.5 - lp.dual_arc[i][j];
            }
        }
        NG1 = new long[data.n]; NG2 = new long[data.n]; NG3 = new long[data.n]; NG4 = new long[data.n];
        for (int i = 0; i < data.n; i++){
            NG1[i] = 0x00; NG2[i] = 0x00; NG3[i] = 0x00; NG4[i] = 0x00;
        }

        for (int i = 0; i < data.n; i++){
            int[] closet = find_N_closet(i, N);
            for (int j = 0; j < closet.length; j++){
                int index = closet[j];
                if (index < 64) {
                    NG1[i] = data.mask[index] | NG1[i];
                }
                else if (i < 128){
                    NG2[i] = data.mask[index] | NG2[i];
                }
                else if (i < 192){
                    NG3[i] = data.mask[index] | NG3[i];
                }else{
                    NG4[i] = data.mask[index] | NG4[i];
                }
            }
        }
        if (lp.neg_index.size() != 0) {
            sr_size = (int)Math.ceil((double)lp.neg_index.size() * parameter);
            int size = (int) Math.ceil(((double) lp.neg_index.size()) / lp.seg_size);
            C_sr = new int[size];
            double[] negative_sr_value = new double[lp.neg_index.size()];
            for (int i = 0; i < negative_sr_value.length; i++) {
                negative_sr_value[i] = lp.sr_dual.get(lp.neg_index.get(i));
            }
            Integer[] indices = new Integer[lp.neg_index.size()];
            for (int i = 0; i < lp.neg_index.size(); i++) {
                indices[i] = i;
            }
            Arrays.sort(indices, (i, j) -> Double.compare(negative_sr_value[i], negative_sr_value[j]));
            for (int i = 0; i < Math.min(sr_size, lp.neg_index.size()); i++) {
                ArrayList<Integer> active = lp.neg_index2neg_size(indices[i]);
                int first_level = active.get(0);
                int second_level = active.get(1);
                C_sr[first_level] = C_sr[first_level] | mask[second_level];
            }
        }

    }

    public int[] find_N_closet(int node, int N) {
        double[] arr = db[node].clone();
        arr[data.n] = 1e9;
        int[] return_arr = IntStream.range(0, arr.length)
                .boxed()
                .sorted((i, j) -> Double.compare(arr[i], arr[j]))
                .limit(Math.min(N, arr.length))
                .mapToInt(Integer::intValue)
                .toArray();
       return return_arr;
    }


    public static boolean dominate(RMP lp, ArrayList<Label> labels, long C1, long C2, long C3, long C4, Label l){
        for(int i = 0; i < labels.size(); i++){
            if(labels.get(i).dominate(lp, C1, C2, C3, C4, l,is_relax))
                return true;
        }
        for(int i = 0; i < labels.size(); i++){
            if(l.dominate(lp, C1, C2, C3, C4, labels.get(i),is_relax)){
                labels.remove(i);
                i--;
            }
        }
        return false;
    }

    public  boolean dominate2(RMP lp, long C1, long C2, long C3, long C4, Label l){
        for(int q = 1; q < l.q; q++){
            ArrayList<Label> set = fpool[l.id][total_size - 1][q];
            for(int j = 0; j < set.size(); j++){
                if(set.get(j).dominate(lp, C1, C2, C3, C4, l,is_relax))
                    return true;
            }
        }
        return false;
    }

    public boolean dominate3(RMP lp, ArrayList<Label> labels, long C1, long C2, long C3, long C4, Label l){
        for(int i = 0; i < labels.size(); i++){
            if(labels.get(i).dominate(lp, C1, C2, C3, C4, l,is_relax))
                return true;
        }
        for(int q = 1; q < l.q; q++){
            ArrayList<Label> set = fpool[l.id][total_size - 1][q];
            for(int j = 0; j < set.size(); j++){
                if(set.get(j).dominate(lp, C1, C2, C3, C4, l,is_relax))
                    return true;
            }
        }
        for(int i = 0; i < labels.size(); i++){
            if(l.dominate(lp, C1, C2, C3, C4, labels.get(i),is_relax)){
                labels.remove(i);
                i--;
            }
        }
        return false;
    }

    public boolean dominate4(RMP lp,  long C1, long C2, long C3, long C4, Label l, int outflow){
        for(int q = 0; q < data.Q; q++){
            ArrayList<Label> set = bpool[l.id][outflow][q];
            for(int j = 0; j < set.size(); j++){
                if(set.get(j).dominate(lp, C1, C2, C3, C4, l,is_relax))
                    return true;
                if (l.dominate(lp, C1, C2, C3, C4, set.get(j), is_relax)){
                    set.remove(j);
                    j--;
                }
            }
        }
        return false;
    }


    public  void f_sr_handle1(RMP lp, Label label, int i, Label new_label){   // 从伪标签转到真实标签
        new_label.sr_set = new ArrayList<Integer>();
        new_label.tsr = 0.0;
        ArrayList<Integer> node_set = lp.sr_node_set.get(i);
        for(int j = 0; j < label.sr_set.size(); j++){
            int s1 = label.sr_set.get(j);
            int s2 = node_set.get(j) & C_sr[j];
            new_label.c -= lp.sr_comp[j][s1 & s2];
            int s3 = s1 & (~s2) | (~s1) & s2;
            new_label.sr_set.add(s3);
            new_label.tsr += lp.sr_comp[j][s3];
        }
    }

    public static void f_sr_handle2(RMP lp, Label label1, Label label2, Label new_label){  //两个伪标签合并
        new_label.sr_set = new ArrayList<Integer>();
        new_label.tsr = 0.0;
        for(int j = 0; j < label1.sr_set.size(); j++){
            int s1 = label1.sr_set.get(j);
            int s2 = label2.sr_set.get(j);
            new_label.c -= lp.sr_comp[j][s1 & s2];
            int s3 = s1 & (~s2) | (~s1) & s2;
            new_label.sr_set.add(s3);
            new_label.tsr += lp.sr_comp[j][s3];
        }
    }

    public void combine2(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double[][] bb, double thresh_hold, int id1, int id2, ArrayList<Label> set1, ArrayList<Label> set2, ArrayList<Label> target, int outflow){
        for(int a = 0; a < set1.size(); a++){
            for(int b = 0; b < set2.size(); b++){
                Label label1 = set1.get(a);
                Label label2 = set2.get(b);
                //check feasibility
                if(label1.id == label2.id)
                    continue;
                if((label1.V1 & label2.V1 & C1) != 0x00 || (label1.V2 & label2.V2 & C2) != 0x00 || (label1.V3 & label2.V3 & C3) != 0x00 || (label1.V4 & label2.V4 & C4) != 0x00)
                    continue;
                Label new_label = new Label();
                new_label.c = label2.c + label1.c +  data.arc_cost(id1, id2, outflow + label1.q) - lp.dual_arc[id1][id2];
                new_label.id = id1;
                new_label.q = label1.q + label2.q;
                new_label.V1 = label1.V1 | (label2.V1 & NG1[id1]);
                new_label.V2 = label1.V2 | (label2.V2 & NG2[id1]);
                new_label.V3 = label1.V3 | (label2.V3 & NG3[id1]);
                new_label.V4 = label1.V4 | (label2.V4 & NG4[id1]);
                new_label.N1 = label1.N1 | label2.N1 | (label1.V1 & label2.V1);
                new_label.N2 = label1.N2 | label2.N2 | (label1.V2 & label2.V2);
                new_label.N3 = label1.N3 | label2.N3 | (label1.V3 & label2.V3);
                new_label.N4 = label1.N4 | label2.N4 | (label1.V4 & label2.V4);
                new_label.child1 = label1;
                new_label.child2 = label2;
                new_label.arc1 = 0;
                new_label.arc2 = 2;
                new_label.root = label2.root;
                if(new_label.c + bb[new_label.id][outflow] >= thresh_hold)
                    continue;
                //handle the sr cuts
                if(lp.is_sr_add){
                    f_sr_handle2(lp, label1, label2, new_label);
//					b_sr_handle(lp, label1, label2, new_label);
                }
                if(new_label.c + bb[new_label.id][outflow] >= thresh_hold)
                    continue;
                if(dominate4(lp,  C1, C2, C3, C4, new_label, outflow) == false){
                    target.add(new_label);
                }
            }
        }
    }





    public void initialize_layer(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double thresh_hold, int id, ArrayList<Label> set, ArrayList<Label> target){
        for(int h = 0; h < set.size(); h++){
            Label label = set.get(h);
            if(id < 64){
                if((label.V1 & data.mask[id] & C1) != 0x00)
                    continue;
            }
            else if(id < 128){
                if((label.V2 & data.mask[id] & C2) != 0x00)
                    continue;
            }
            else if(id < 192){
                if((label.V3 & data.mask[id] & C3) != 0x00)
                    continue;
            }
            else{
                if((label.V4 & data.mask[id] & C4) != 0x00)
                    continue;
            }
            if(lp.node.feasible_arc[label.id][id] == -1)
                continue;
            Label new_label = new Label();
            new_label.c = label.c + data.arc_cost(label.id, id, label.q) - lp.dual_arc[label.id][id];
            new_label.id = id;
            new_label.q = label.q;
            new_label.min_subQ = label.q;
            new_label.V1 = label.V1 & NG1[id];
            new_label.V2 = label.V2 & NG2[id];
            new_label.V3 = label.V3 & NG3[id];
            new_label.V4 = label.V4 & NG4[id];
            new_label.N1 = label.N1;
            new_label.N2 = label.N2;
            new_label.N3 = label.N3;
            new_label.N4 = label.N4;
            new_label.child1 = label;
            new_label.child2 = null;
            new_label.arc1 = 1;
            new_label.arc2 = 0;
            new_label.root = -1;
            if(lp.is_sr_add){
                new_label.tsr = label.tsr;
                new_label.sr_set = (ArrayList<Integer>) label.sr_set.clone();
            }
            if (new_label.c >= 0) continue; // dominated by empty label
            if(new_label.c + fb[id][new_label.q] >= thresh_hold){
                continue;
            }
            target.add(new_label);
        }
    }

    public void crossover(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double thresh_hold, int id, ArrayList<Label> set1, ArrayList<Label> set2, ArrayList<Label> target){
        for(int h = 0; h < set1.size(); h++){
            Label label = set1.get(h);
            target.add(label);
        }
        ArrayList<Label> non_set = new ArrayList<Label>();
        for(int h = 0; h < set2.size(); h++){
            Label label = set2.get(h);
            if(dominate(lp, target, C1, C2, C3, C4, label) == false)
                non_set.add(label);
        }
        target.addAll(non_set);
    }

    public void combine1(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double thresh_hold, int id, ArrayList<Label> set1, ArrayList<Label> set2, ArrayList<Label> target){
        for(int x = 0; x < set1.size(); x++){
            for(int y = 0; y < set2.size(); y++){
                Label label1 = set1.get(x);
                Label label2 = set2.get(y);
                //check feasibility
                if(label1.c + label2.c + fb[id][label1.q + label2.q] >= thresh_hold){
                    continue;
                }
                if((label1.V1 & label2.V1 & C1) != 0x00 || (label1.V2 & label2.V2 & C2) != 0x00 || (label1.V3 & label2.V3 & C3) != 0x00 || (label1.V4 & label2.V4 & C4) != 0x00)
                    continue;
                Label new_label = new Label();
                new_label.c = label1.c + label2.c;
                new_label.id = id;
                new_label.q = label1.q + label2.q;
                new_label.min_subQ = Math.min(label1.min_subQ, label2.min_subQ);
                new_label.V1 = (label1.V1 | label2.V1) ;
                new_label.V2 = (label1.V2 | label2.V2) ;
                new_label.V3 = (label1.V3 | label2.V3) ;
                new_label.V4 = (label1.V4 | label2.V4) ;
                new_label.child1 = label1;
                new_label.child2 = label2;
                new_label.arc1 = 0;
                new_label.arc2 = 0;
                new_label.root = -1;
                //handle the sr cuts
                if(lp.is_sr_add){
                    f_sr_handle2(lp, label1, label2, new_label);
                }
                if (new_label.c >= 0) continue; // dominated by empty label
                if(new_label.c  + fb[new_label.id][new_label.q] < thresh_hold && dominate(lp, target, C1, C2, C3, C4, new_label) == false){
                    target.add(new_label);
                }
            }
        }
    }


    public Label transform_reallabel(RMP lp, Label label, double[][] fb, double thresh_hold){
        int id = label.id;
        Label new_label = new Label();
        new_label.c = label.c - lp.mu[id];
        new_label.id = id;
        new_label.q = label.q + 1;
        if(id < 64){
            new_label.V1 = (label.V1 | data.mask[id]);
            new_label.V2 = label.V2;
            new_label.V3 = label.V3;
            new_label.V4 = label.V4;
        }
        else if(id < 128){
            new_label.V1 = label.V1;
            new_label.V2 = (label.V2 | data.mask[id]);
            new_label.V3 = label.V3;
            new_label.V4 = label.V4;
        }
        else if(id < 192){
            new_label.V1 = label.V1;
            new_label.V2 = label.V2;
            new_label.V3 = (label.V3 | data.mask[id]);
            new_label.V4 = label.V4;
        }
        else {
            new_label.V1 = label.V1;
            new_label.V2 = label.V2;
            new_label.V3 = label.V3;
            new_label.V4 = (label.V4 | data.mask[id]);
        }
        new_label.child1 = label;
        new_label.child2 = null;
        new_label.arc1 = 0;
        new_label.arc2 = 0;
        new_label.root = -1;
        if(lp.is_sr_add){
            f_sr_handle1(lp, label, id, new_label);
        }
        return new_label;
    }


    public  void final_crossover1(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double thresh_hold, int id, ArrayList<Label> set1, ArrayList<Label> set2, ArrayList<Label> target){
        ArrayList<Label> non_set = new ArrayList<Label>();
        for(int h = 0; h < set1.size(); h++){
            Label label = set1.get(h);
            if(dominate2(lp, C1, C2, C3, C4, label) == false)
                target.add(label);
        }
        for(int h = 0; h < set2.size(); h++){
            Label label = set2.get(h);
            if(dominate3(lp, target, C1, C2, C3, C4, label) == false)
                non_set.add(label);
        }
        target.addAll(non_set);
    }

    public void final_combine1(RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double thresh_hold, int id, ArrayList<Label> set1, ArrayList<Label> set2, ArrayList<Label> target){
        for(int x = 0; x < set1.size(); x++){
            for(int y = 0; y < set2.size(); y++){
                Label label1 = set1.get(x);
                Label label2 = set2.get(y);
                //check feasibility
                if(label1.c + label2.c + fb[id][label1.q + label2.q] >= thresh_hold){
                    continue;
                }
                if((label1.V1 & label2.V1 & C1) != 0x00 || (label1.V2 & label2.V2 & C2) != 0x00 || (label1.V3 & label2.V3 & C3) != 0x00 || (label1.V4 & label2.V4 & C4) != 0x00)
                    continue;
                Label new_label = new Label();
                new_label.c = label1.c + label2.c;
                new_label.id = id;
                new_label.q = label1.q + label2.q;
                new_label.min_subQ = Math.min(label1.min_subQ, label2.min_subQ);
                new_label.V1 = (label1.V1 | label2.V1);
                new_label.V2 = (label1.V2 | label2.V2);
                new_label.V3 = (label1.V3 | label2.V3);
                new_label.V4 = (label1.V4 | label2.V4);
                new_label.child1 = label1;
                new_label.child2 = label2;
                new_label.arc1 = 0;
                new_label.arc2 = 0;
                new_label.root = -1;
                if(lp.is_sr_add){
                    f_sr_handle2(lp, label1, label2, new_label);
                }
                if (new_label.c >= 0) continue;  // dominated by empty label
                if(new_label.c + fb[new_label.id][new_label.q] < thresh_hold && dominate3(lp, target, C1, C2, C3, C4, new_label) == false){
                    target.add(new_label);
                }
            }
        }
    }



    public void extend(RMP lp, long C1, long C2, long C3, long C4,  double[][] fb, double[][] bb, double thresh_hold){
        fpool = new ArrayList[data.n][total_size][data.Q];
        for(int i = 0; i < data.n; i++){
            for(int j = 0; j < total_size; j++){
                for(int k = 0; k < data.Q; k++){
                    fpool[i][j][k] = new ArrayList<>();
                }
            }
        }
        real_fpool = new ArrayList[data.n][data.Q]; // +1 因为q是从1开始计算，+2 是因为顶点还有一个q
        for (int i = 0; i < data.n; i++){
            for (int k = 1; k < data.Q; k++){
                real_fpool[i][k] = new ArrayList<>();
            }
        }

        bpool = new ArrayList[data.n][data.Q][data.Q];
        for(int i = 0; i < data.n; i++){
            for (int j = 0; j < data.Q; j++) {
                for (int k = 0; k < data.Q; k++)
                    bpool[i][j][k] = new ArrayList<>();
            }
        }

        //---------------************************ forward extension ************************-----------------
        //initialize for real label
        for(int i = 0; i < data.n; i++){
            Label label = new Label();
            label.id = i;
            label.q = 1;
            label.c = -lp.mu[i];
            label.child1 = null;
            label.child2 = null;
            label.arc1 = 0;
            label.arc2 = 0;
            label.root = -1;
            if(i < 64){
                label.V1 = data.mask[i];
                label.V2 = 0x00;
                label.V3 = 0x00;
                label.V4 = 0x00;
            }
            else if(i < 128){
                label.V1 = 0x00;
                label.V2 = data.mask[i];
                label.V3 = 0x00;
                label.V4 = 0x00;
            }
            else if(i < 192){
                label.V1 = 0x00;
                label.V2 = 0x00;
                label.V3 = data.mask[i];
                label.V4 = 0x00;
            }
            else {
                label.V1 = 0x00;
                label.V2 = 0x00;
                label.V3 = 0x00;
                label.V4 = data.mask[i];
            }
            label.N1 = 0x00;
            label.N2 = 0x00;
            label.N3 = 0x00;
            label.N4 = 0x00;
            if(lp.is_sr_add){
                label.sr_set = (ArrayList<Integer>) lp.sr_node_set.get(i).clone();     //与i点相关的所有dual值为负的sr index
                label.tsr = 0;
                for(int j = 0; j < label.sr_set.size(); j++){
                    label.sr_set.set(j, label.sr_set.get(j) & C_sr[j]);
                    label.tsr += lp.sr_comp[j][label.sr_set.get(j)];
                }
            }
            real_fpool[i][1].add(label);   // 这种情况下伪label是空(rc = 0,所以大于0的伪label都会被丢弃)，所以初始化是在real label里做的
        }

        for(int g = 1; g < data.Q; g++) {
            if (data.time_out())
                break;
            for (int i = 0; i < data.n; i++) {
                if (data.time_out())
                    break;
                //forward
                //intialize the first layer
                int lsize = size.get(0);
                for (int j = 0; j < lsize; j++) {
//                    if (data.time_out())
//                        break;
                    int id = j;
                    if (id >= i)
                        id++;
                    if (lp.node.feasible_arc[id][i] == -1)
                        continue;
                    ArrayList<Label> labels = real_fpool[id][g]; // real label 有g个点，可以完整传过来
                    ArrayList<Label> target = fpool[i][j][g];
                    initialize_layer(lp, C1, C2, C3, C4, fb, thresh_hold, i, labels, target);
                }
                //move to the next layer
                int start = 0;
                for (int j = 1; j < size.size() - 1; j++) {
//                    if (data.time_out())
//                        break;
                    lsize = size.get(j);
                    int pre_lsize = size.get(j - 1);
                    for (int k = 0; k < lsize; k++) {
//                        if (data.time_out())
//                            break;
                        if (2 * k + 1 >= pre_lsize) {
                            //directly move
                            ArrayList<Label> set = fpool[i][start + 2 * k][g];
                            ArrayList<Label> target = fpool[i][start + pre_lsize + k][g];
                            for (int h = 0; h < set.size(); h++) {
//                                if (data.time_out())
//                                    break;
                                target.add(set.get(h));
                            }
                        } else {
                            //crossover
                            ArrayList<Label> set1 = fpool[i][start + 2 * k][g];
                            ArrayList<Label> set2 = fpool[i][start + 2 * k + 1][g];
                            ArrayList<Label> target = fpool[i][start + pre_lsize + k][g];
                            crossover(lp, C1, C2, C3, C4, fb, thresh_hold, i, set1, set2, target);
                            for (int q = 1; q < g; q++) {
//                                if (data.time_out())
//                                    break;
                                set1 = fpool[i][start + 2 * k][q];
                                set2 = fpool[i][start + 2 * k + 1][g - q];
                                combine1(lp, C1, C2, C3, C4, fb, thresh_hold, i, set1, set2, target);
                            }
                        }
                    }
                    start += pre_lsize;
                }
                //final
                ArrayList<Label> set1 = fpool[i][total_size - 3][g];
                ArrayList<Label> set2 = fpool[i][total_size - 2][g];
                ArrayList<Label> target = fpool[i][total_size - 1][g];
                final_crossover1(lp, C1, C2, C3, C4, fb, thresh_hold, i, set1, set2, target);          //感觉这里的label有问题, 回头自己测一下。
                for (int q = 1; q < g; q++) {
//                    if (data.time_out())
//                        break;
                    set1 = fpool[i][total_size - 3][q];
                    set2 = fpool[i][total_size - 2][g - q];
                    final_combine1(lp, C1, C2, C3, C4, fb, thresh_hold, i, set1, set2, target);
                }
                // transform peosuo label to real label, 此时，悬挂在i点且q为g+1 的这些label一定不会被支配
                for (int l = 0; l < fpool[i][total_size - 1][g].size(); l++){
//                    if (data.time_out())
//                        break;
                    Label pesu_l = fpool[i][total_size - 1][g].get(l);
                    Label real_l = transform_reallabel(lp, pesu_l, fb, thresh_hold);
                    if (real_l == null) continue;
                    if (g + 1 >= data.Q) continue;
                    real_fpool[i][g + 1].add(real_l);
                }
            }
        }

        //---------------************************ backward extension ************************-----------------
        for (int g = 9; g >= 1; g--){
            if (data.time_out())
                break;
            for (int i = 0; i < data.n; i++) {
                if (data.time_out())
                    break;
                // 首先，将后向连到depot
                for (int k = LB[g]; k <= UB[g]; k++){
//                    if (data.time_out())
//                        break;
                    ArrayList<Label>  set1 = real_fpool[i][k];
                    ArrayList<Label> target = bpool[i][g][k];
                    if (lp.node.feasible_arc[i][data.n] != -1) {
                        f2b(data, lp, C1, C2, C3, C4, fb, bb, thresh_hold, set1, target, g);
                    }
                    // combine
                    for (int u = 9; u > g; u--) {
//                        if (data.time_out())
//                            break;
                        // 如果是从u拓展过来的，那么拓展的个数是u - g
                        int capacity = k - (u - g);
                        if (capacity < LB[u] || capacity > UB[u]) continue;
                        // 此时可以拓展
                        set1 = real_fpool[i][u - g];
                        for (int j = 0; j < data.n; j++) {
//                            if (data.time_out())
//                                break;
                            if (j == i || lp.node.feasible_arc[i][j] == -1)
                                continue;
                            ArrayList<Label> set2 = bpool[j][u][capacity];
                            combine2(lp, C1, C2, C3, C4, fb, bb, thresh_hold, i, j, set1, set2, target,  g);
                        }
                    }
                }
            }
        }

    }

    public void f2b(Data data, RMP lp, long C1, long C2, long C3, long C4, double[][] fb, double[][] bb, double thresh_hold,  ArrayList<Label> set, ArrayList<Label> target, int out_flow){
        for(int h = 0; h < set.size(); h++){
            Label label = set.get(h);
            Label new_label = new Label();
            new_label.c = label.c + data.arc_cost(label.id, data.n, label.q + out_flow) - lp.mu[data.n] - lp.dual_arc[label.id][data.n];
            new_label.id = label.id;
            new_label.q = label.q;
            new_label.V1 = label.V1;
            new_label.V2 = label.V2;
            new_label.V3 = label.V3;
            new_label.V4 = label.V4;
            new_label.N1 = label.N1;
            new_label.N2 = label.N2;
            new_label.N3 = label.N3;
            new_label.N4 = label.N4;
            new_label.child1 = label;
            new_label.child2 = null;
            new_label.arc1 = 0;
            new_label.arc2 = 0;
            new_label.root = label.id;
            if(new_label.c + bb[new_label.id][out_flow] >= thresh_hold)
                continue;
            //handle the sr cuts
            if(lp.is_sr_add){
                new_label.sr_set = (ArrayList<Integer>) label.sr_set.clone();
                new_label.tsr = label.tsr;
            }
            if(dominate4(lp, C1, C2, C3, C4, new_label, out_flow) == false){
                target.add(new_label);
            }
        }
    }



    public void update_fb_bb(RMP lp, ArrayList<Label>[][][] fpool, ArrayList<Label>[][][] bpool, double[][] old_fb, double[][] old_bb){
        double[][] new_fb = new double[data.n][data.Q];
        double[][] new_bb = new double[data.n][data.Q];
        for(int i = 0; i < data.n; i++){
            for(int q = 0; q < data.Q; q++){
                new_fb[i][q] = data.arc_cost(i, data.n, q + 1) - lp.dual_arc[i][data.n] - lp.mu[data.n] - lp.mu[i];
            }
        }
        for(int i = 0; i < data.n; i++){
            new_bb[i][0] = 0.0;
            for(int q = 1; q < data.Q; q++){
                new_bb[i][q] = 1e10;
            }
        }

        for(int i = 0; i < data.n; i++){
            for(int g = 1; g < data.Q; g++){
                for(int q = 1; q <  data.Q; q++){
                    ArrayList<Label> labels = bpool[i][g][q];
                    for (int l = 0; l < labels.size(); l++){
                        double cost = labels.get(l).c;
                        if (cost < new_fb[i][g])
                            new_fb[i][g] = cost;
                    }
                }
            }
        }

        for(int i = 0; i < data.n; i++) {
            for (int q = 1; q < data.Q; q++) {
                ArrayList<Label> labels = fpool[i][total_size - 1][q];
                for (int l = 0; l < labels.size(); l++) {
                    double cost = labels.get(l).c;
                    if (cost < new_bb[i][q])
                        new_bb[i][q] = cost;
                }
            }
        }

        for(int i = 0; i < data.n; i++) {
            for (int q = 0; q < data.Q; q++) {
                if (Math.abs(new_fb[i][q] - old_fb[i][q]) > 1e-3) {
                    if (new_fb[i][q] > old_fb[i][q])
                        old_fb[i][q] = new_fb[i][q];
                    else {
//						System.out.println("Label pruning fb error");
//						System.exit(-1);
                    }
                }
                if (Math.abs(new_bb[i][q] - old_bb[i][q]) > 1e-3) {
                    if (new_bb[i][q] >= old_bb[i][q])
                        old_bb[i][q] = new_bb[i][q];
                    else {
                        System.out.println("Label pruning bb error");
                        System.exit(-1);
                    }
                }
            }
        }
    }

    public void get_bound(RMP lp,  double thresh_hold, double[][] fb, double[][] bb){
        build_NG(lp);
//        boolean sign = lp.is_sr_add;
//        lp.is_sr_add = false;
        long C1 = data.all_mask;
        long C2 = data.all_mask;
        long C3 = data.all_mask;
        long C4 = data.all_mask;
        extend(lp, C1, C2, C3, C4, fb, bb, thresh_hold);
        update_fb_bb(lp, fpool, bpool, fb, bb);
//        lp.is_sr_add = sign;
    }
}
