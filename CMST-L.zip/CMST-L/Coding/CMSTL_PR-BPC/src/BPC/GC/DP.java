package BPC.GC;

import BPC.LP.RMP;
import Common.Data;

public class DP {

	public Data data;
	
	public DP(Data d){
		data = d;
	}

	public void run(RMP lp, double[][][] FT, double[][][][] BT){
		//initialize the states
		for(int i = 0; i < data.n; i++){
			for(int k = 0; k < data.n - 1; k++){
				//forward state
				FT[i][k][0] = 1e15;
				FT[i][k][1] = -lp.mu[i];
				//backward state
				for(int h = 0; h < data.Q; h++){
					BT[i][k][0][h] = 1e15;
					BT[i][k][1][h] = data.arc_cost(i, data.n, h + 1) - lp.mu[i] - lp.mu[data.n] - lp.dual_arc[i][data.n];
				}
			}
		}
		//dp
		for(int q = 2; q <= data.Q; q++){
			for(int i = 0; i < data.n; i++){
				for(int k = 0; k < data.n-1; k++){
					FT[i][k][q] = 1e15;
					for(int h = 0; h <= data.Q - q; h++)
						BT[i][k][q][h] = 1e15;
					//decision 1, from the k - 1 state
					if(k - 1 >= 0){
						if(FT[i][k - 1][q] < FT[i][k][q]){
							FT[i][k][q] = FT[i][k - 1][q];
						}
						for(int h = 0; h <= data.Q - q; h++){
							if(BT[i][k - 1][q][h] < BT[i][k][q][h]){
								BT[i][k][q][h] = BT[i][k - 1][q][h];
							}
						}
					}
					int jid = k;
					if(jid >= i)
						jid++;
					//decision 2, all from the next customer
					if(lp.node.feasible_arc[jid][i] != -1){
						double cost2 = data.arc_cost(jid, i, q - 1) - lp.dual_arc[jid][i]  - lp.mu[i] + FT[jid][data.n - 2][q - 1];
						if(cost2 < FT[i][k][q]){
							FT[i][k][q] = cost2;
						}
					}

					if(lp.node.feasible_arc[i][jid] != -1){
						for(int h = 0; h <= data.Q - q; h++){
							double cost2 = data.arc_cost(i, jid, h + 1) - lp.dual_arc[i][jid] - lp.mu[i] + BT[jid][data.n - 2][q - 1][h + 1];
							if(cost2 < BT[i][k][q][h]){
								BT[i][k][q][h] = cost2;
							}
						}
					}

					if(k - 1 >= 0){
						//decision 3, from two labels
						if(lp.node.feasible_arc[jid][i] != -1){
							for(int q2 = 1; q2 <= q - 2; q2++){
								double cost3 = FT[i][k - 1][q - q2] + data.arc_cost(jid, i, q2) - lp.dual_arc[jid][i] + FT[jid][data.n - 2][q2];
								if(cost3 < FT[i][k][q]){
									FT[i][k][q] = cost3;
								}
							}
							for(int h = 0; h <= data.Q - q; h++){
								for(int q2 = 1; q2 <= q - 2; q2++){
									double cost3 = BT[i][k - 1][q - q2][q2 + h] + data.arc_cost(jid, i, q2) - lp.dual_arc[jid][i] + FT[jid][data.n - 2][q2];
									if(cost3 < BT[i][k][q][h]){
										BT[i][k][q][h] = cost3;
									}
								}
							}
						}

						if(lp.node.feasible_arc[i][jid] != -1){
							for(int h = 0; h <= data.Q - q; h++){
								for(int q2 = 1; q2 <= q - 2; q2++){
									double cost3 = FT[i][k - 1][q - q2] + data.arc_cost(i, jid, q - q2 + h) - lp.dual_arc[i][jid] + BT[jid][data.n - 2][q2][q - q2 + h];
									if(cost3 < BT[i][k][q][h]){
										BT[i][k][q][h] = cost3;
									}
								}
							}
						}
					}
					if(k == data.n - 2 && lp.node.feasible_arc[i][data.n] != -1){
						//decision 4 for the backward extension
						for(int h = 0; h <= data.Q - q; h++){
							double cost4 = FT[i][k][q] + data.arc_cost(i, data.n, q + h) - lp.dual_arc[i][data.n] - lp.mu[data.n];
							if(cost4 < BT[i][k][q][h]){
								BT[i][k][q][h] = cost4;
							}
						}
					}
				}
			}
		}
	}
	
	public void get_bound(RMP lp, double[][] fb, double[][] bb){
		for(int i = 0; i < data.n; i++){
			for(int q = 0; q < data.Q; q++){
				fb[i][q] = data.arc_cost(i, data.n, q + 1) - lp.dual_arc[i][data.n] - lp.mu[data.n] - lp.mu[i];
			}
		}
		for(int i = 0; i < data.n; i++){
			bb[i][0] = 0.0;
			for(int q = 1; q < data.Q; q++){
				bb[i][q] = 1e10;
			}
		}
		double[][][] FT = new double[data.n][data.n - 1][data.Q + 1];
		double[][][][] BT = new double[data.n][data.n - 1][data.Q + 1][data.Q + 1];
		run(lp, FT, BT);
		for(int i = 0; i < data.n; i++){
			for(int q = 1; q < data.Q; q++){
				for(int j = 2; j <= data.Q - q; j++){
					double cost = BT[i][data.n - 2][j][q];
					if(cost < fb[i][q]){
						fb[i][q] = cost;
					}
				}
			}
		}

		for(int i = 0; i < data.n; i++){
			for(int q = 1; q < data.Q; q++){
				double cost = FT[i][data.n - 2][q + 1] + lp.mu[i];
				if(cost < bb[i][q]){
					bb[i][q] = cost;
				}
			}
		}
	}
}
