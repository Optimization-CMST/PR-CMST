package BPC.Branch;

import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRBException;

import java.util.ArrayList;

//branch on whether a panel is a root
public class BCA {
	public Data data;
	public int id1;
	public int id2;
	public double av;
	public Node left_node;
	public Node right_node;
	
	public BCA(Data d){
		data = d;
	}
	/*
	public void fraction_root(LP lp){
		id1 = id2 = -1;
		double min_cost = Double.MAX_VALUE;
		double max_dist = 0.0;
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				if(i == j)
					continue;
				if(Help.is_fractional(lp.arc_map[i][j]) == false)
					continue;
				double fra_cost = Help.frac_cost(lp.arc_map[i][j]);
				if(fra_cost > 0.02)
					continue;
				if(data.d[i][j] > max_dist){
					min_cost = fra_cost;
					max_dist = data.d[i][j];
					id1 = i;
					id2 = j;
					av = lp.arc_map[i][j];
				}
			}
		}
		if(id1 != -1 && id2 != -1)
			return;
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				if(i == j)
					continue;
				if(Help.is_fractional(lp.arc_map[i][j]) == false)
					continue;
				double fra_cost = Help.frac_cost(lp.arc_map[i][j]);
				if(fra_cost < min_cost){
					min_cost = fra_cost;
					max_dist = data.d[i][j];
					id1 = i;
					id2 = j;
					av = lp.arc_map[i][j];
				}
			}
		}
	}
	*/
	public void fraction_root2(RMP lp){
		id1 = id2 = -1;
		double max_dist = 0.0;
		double thresh_hold = 0.01;
		while(id1 == -1 && id2 == -1){
			for(int i = 0; i < data.n + 1; i++){
				for(int j = 0; j < data.n + 1; j++){
					if(i == j)
						continue;
					if(Help.is_fractional(lp.arc_map[i][j]) == false)
						continue;
					double fra_cost = Help.frac_cost(lp.arc_map[i][j]);
					if(fra_cost > thresh_hold)
						continue;
					if(data.d[i][j] > max_dist){
						max_dist = data.d[i][j];
						id1 = i;
						id2 = j;
						av = lp.arc_map[i][j];
					}
				}
			}
			thresh_hold += 0.01;
			System.out.println("threshold: " + thresh_hold);
		}
	}
	
	public void get_cuts(RMP lp, Node node){
		node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
		node.sr_cuts = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < lp.useful_sr.size(); i++){
			ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
			node.sr_cuts.add((ArrayList<Integer>) cut.clone());
		}
	}
	
	public void branch(RMP lp) throws GRBException {
		fraction_root2(lp);
		left_node = lp.node;
		right_node = lp.node.duplicate();
		left_node.sudo_cost = lp.cost;
		right_node.sudo_cost = lp.cost;
		left_node.depth ++;
		right_node.depth = left_node.depth;
		get_cuts(lp, left_node);
		get_cuts(lp, right_node);
		//--------branch on root------------------------
		//change the direction of the branching arc
		left_node.feasible_arc[id1][id2] = -1;
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				right_node.feasible_arc[id1][i] = -1;
			}
		}
		right_node.feasible_arc[id1][id2] = 1;
		//--------get the left route set and the right route set-----------------
		BigMA bigm = new BigMA(data);
		left_node.column_set = bigm.get_left_routeset(lp, left_node, id1, id2);
		right_node.column_set = bigm.get_right_routeset(lp, right_node, id1, id2);
		if(left_node.column_set == null){
			left_node.clear();
			left_node = null;
		}		
		if(right_node.column_set == null){
			right_node.clear();
			right_node = null;
		}
	}
}
