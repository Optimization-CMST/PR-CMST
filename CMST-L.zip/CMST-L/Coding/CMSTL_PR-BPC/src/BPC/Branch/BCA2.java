package BPC.Branch;

import BPC.LP.RMP;
import BPC.SearchTree.Node;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;
import com.gurobi.gurobi.GRBVar;

import java.util.ArrayList;

//branch on whether a panel is a root
public class BCA2 {
	public Data data;
	public Node left_node;
	public Node right_node;
	public int id1;
	public int id2;
	public double av;
	public double left_obj;
	public double right_obj;
	public ArrayList<ArrayList<Integer>> left_set;
	public ArrayList<ArrayList<Integer>> right_set;
	public double thresh_hold = 0.5;
	public double max_value;
	
	public BCA2(Data d){
		data = d;
	}
	
	public boolean select(RMP lp, double[][] map) throws GRBException {
		double ocost = lp.cost;
		//compute change cost
		double[][] left_cost = new double[data.n + 1][data.n + 1];
		double[][] right_cost = new double[data.n + 1][data.n + 1];
		ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>> left_matrix = new ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>();
		ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>> right_matrix = new ArrayList<ArrayList<ArrayList<ArrayList<Integer>>>>();
		for(int i = 0; i < data.n + 1; i++){
			left_matrix.add(new ArrayList<ArrayList<ArrayList<Integer>>>());
			right_matrix.add(new ArrayList<ArrayList<ArrayList<Integer>>>());
			for(int j = 0; j < data.n + 1; j++){
				left_matrix.get(i).add(new ArrayList<ArrayList<Integer>>());
				right_matrix.get(i).add(new ArrayList<ArrayList<Integer>>());
			}
		}
		//forbid node
		boolean[] fnode = new boolean[data.n + 1];
		for(int i = 0; i < data.n; i++){
			for(int j = 0; j < data.n; j++){
				if(i != j && (lp.node.feasible_arc[i][j] == 1 || lp.node.feasible_arc[j][i] == 1)){
					fnode[i] = true;
					break;
				}
			}
		}
		thresh_hold = 0.2;
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				if(i == j || Help.frac_cost(map[i][j]) > 0.1 || fnode[i] || fnode[j])
					continue;
				//modify the lp
				double lobj = -1e10;
				double robj = -1e10;
				ArrayList<ArrayList<Integer>> lset = new ArrayList<ArrayList<Integer>>();
				ArrayList<ArrayList<Integer>> rset = new ArrayList<ArrayList<Integer>>();
				left_modify_lp(lp, i, j);
				lp.model.update();
				lp.model.optimize();
				int status = lp.model.get(GRB.IntAttr.Status);
				if(status == GRB.Status.OPTIMAL){
					lp.set_value();
					lobj = lp.model.get(GRB.DoubleAttr.ObjVal);
					lp.get_columns(lset);
				}
				left_restore_lp(lp, i, j);
				if(lobj - ocost < thresh_hold)
					continue;
				right_modify_lp(lp, i, j);
				lp.model.update();
				lp.model.optimize();
				status = lp.model.get(GRB.IntAttr.Status);
				if(status == GRB.Status.OPTIMAL){
					lp.set_value();
					robj = lp.model.get(GRB.DoubleAttr.ObjVal);
					lp.get_columns(rset);
				}
				right_restore_lp(lp, i, j);
				if(robj - ocost < thresh_hold)
					continue;
				left_cost[i][j] = lobj;
				right_cost[i][j] = robj;
				left_matrix.get(i).set(j, lset);
				right_matrix.get(i).set(j, rset);
			}
		}
		//select the arcs
		max_value = 0;
		thresh_hold = 0.5;
		while(max_value < 1e-1 && thresh_hold > 0.1){
			for(int i = 0; i < data.n + 1; i++){
				for(int j = 0; j < data.n + 1; j++){
					if(i == j || Help.frac_cost(map[i][j]) > 0.1)
						continue;
					if(left_cost[i][j] - ocost < thresh_hold)
						continue;
					if(right_cost[i][j] - ocost < thresh_hold)
						continue;
					System.out.println(i + "," + j + "," + left_cost[i][j] + "," + right_cost[i][j] + "," + map[i][j]);
					if(left_cost[i][j] + right_cost[i][j] > max_value){
						max_value = left_cost[i][j] + right_cost[i][j];
						id1 = i;
						id2 = j;
						av = map[i][j];
						left_obj = left_cost[i][j];
						right_obj = right_cost[i][j];
						left_set = left_matrix.get(i).get(j);
						right_set = right_matrix.get(i).get(j);
					}
				}
			}
			thresh_hold -= 0.1;
			System.out.println("thresh_hold value * " + thresh_hold);
		}
		lp.cost = ocost;
		if(max_value < 1e-1)
			return false;
		else
			return true;
	}
	
	public void left_modify_lp(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
		for(int i = 0; i < zero_set.size(); i++){
			GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
			var.set(GRB.DoubleAttr.UB, 0);
		}
	}
	
	public void left_restore_lp(RMP lp, int id1, int id2) throws GRBException {
		ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(id2);
		for(int i = 0; i < zero_set.size(); i++){
			GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(i)));
			var.set(GRB.DoubleAttr.UB, 1);
		}
	}
	
	public void right_modify_lp(RMP lp, int id1, int id2) throws GRBException {
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
				for(int j = 0; j < zero_set.size(); j++){
					GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
					var.set(GRB.DoubleAttr.UB, 0);
				}
			}
		}
	}
	
	public void right_restore_lp(RMP lp, int id1, int id2) throws GRBException {
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				ArrayList<Integer> zero_set = lp.ij2ri.get(id1).get(i);
				for(int j = 0; j < zero_set.size(); j++){
					GRBVar var = lp.column_vars.get(lp.r2p.get(zero_set.get(j)));
					var.set(GRB.DoubleAttr.UB, 1);
				}
			}
		}
	}
	
	
	public void get_cuts(RMP lp, Node node){
		node.cc_index = (ArrayList<Integer>) lp.useful_cc.clone();
		node.sr_cuts = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < lp.useful_sr.size(); i++){
			ArrayList<Integer> cut = lp.sr_cuts.get(lp.useful_sr.get(i));
			node.sr_cuts.add((ArrayList<Integer>) cut.clone());
		}
	}
	
	public boolean branch(RMP lp) throws GRBException {
		double[][] map = new double[data.n + 1][data.n + 1];
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				map[i][j] = lp.arc_map[i][j];
			}
		}
		if(select(lp, map) == false){
			for(int i = 0; i < data.n + 1; i++){
				for(int j = 0; j < data.n + 1; j++){
					lp.arc_map[i][j] = map[i][j];
				}
			}
			return false;
		}
		left_node = lp.node;
		right_node = lp.node.duplicate();
		left_node.sudo_cost = lp.cost;
		right_node.sudo_cost = lp.cost;
		left_node.depth ++;
		right_node.depth = left_node.depth;
		get_cuts(lp, left_node);
		get_cuts(lp, right_node);
		//--------branch on root------------------------
		//change the direction of the branching arc
		left_node.feasible_arc[id1][id2] = -1;
		for(int i = 0; i < data.n + 1; i++){
			if(i != id2){
				right_node.feasible_arc[id1][i] = -1;
			}
		}
		right_node.feasible_arc[id1][id2] = 1;
		//--------get the left route set and the right route set-----------------
		left_node.column_set = left_set;
		right_node.column_set = right_set;
		return true;
	}
}
