package BPC.Cut;
//checking 2015-1-5
//checked 2015-1-5

import java.io.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

public class CutPool {
	//---------cut pool--------------------------------------
	public ArrayList<ArrayList<Integer>> cut_pool;
	public ArrayList<Integer> right;
	public HashMap<ArrayList<Integer>, Integer> cut_check_map;
	
	
	public CutPool(){
		cut_pool = new ArrayList<ArrayList<Integer>>();
		right = new ArrayList<Integer>();
		cut_check_map = new HashMap<ArrayList<Integer>, Integer>();
	}
	
	public int add_cut(ArrayList<Integer> cut, int r){
		Collections.sort(cut);
		cut_pool.add(cut);
		right.add(r);
		cut_check_map.put(cut, cut_pool.size() - 1);
		return cut_pool.size() - 1;
	}
	
	public int cut2i(ArrayList<Integer> cut){
		Collections.sort(cut);
		if(cut_check_map.containsKey(cut) == false)
			return -1;
		return cut_check_map.get(cut);
	}
	
	public void export() throws IOException{
		String path = "pool.txt";
		BufferedWriter out=new BufferedWriter(new FileWriter(path));
		out.write(cut_pool.size() + "");
		out.newLine();
		for(int i = 0; i < cut_pool.size(); i++){
			ArrayList<Integer> cut = cut_pool.get(i);
			out.write(cut.size() + " ");
			for(int j = 0; j < cut.size(); j++){
				out.write(cut.get(j) + " ");
			}
			out.write(right.get(i) + "");
			out.newLine();
		}
		out.close();
	}
	
	public void _import() throws FileNotFoundException{
		String file = "pool.txt";
		Scanner cin = new Scanner(new BufferedReader(new FileReader(file)));
		int n = cin.nextInt();
		for(int i = 0; i < n; i++){
			ArrayList<Integer> cut = new ArrayList<Integer>();
			int m = cin.nextInt();
			for(int j = 0; j < m; j++){
				cut.add(cin.nextInt());
			}
			int r = cin.nextInt();
			add_cut(cut, r);
		}
		cin.close();
	}
}
