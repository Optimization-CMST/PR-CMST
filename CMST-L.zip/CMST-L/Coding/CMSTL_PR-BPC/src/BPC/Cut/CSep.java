package BPC.Cut;
//checking 2015-1-5
//checked 2015-1-5

import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;

public class CSep {
	
	public Data data;
	public double[][] map;
	public ArrayList<ArrayList<Integer>> retS;
	public ArrayList<Integer> rightS;
	public int[] rec_S;
	public int[] left_comp;
	
	public CSep(){};
	
	public CSep(Data d){
		data = d;
	}
	
	public class SortObject implements Comparable{
		public int id;
		public double val;
		
		public int compareTo(Object o){
			 SortObject obj = (SortObject) o;
			 if(val < obj.val)
				 return 1;
			 else if(val == obj.val)
				 return 0;
			 else 
				 return -1;
		}
	}
	
	public void shrink(double[][] y){
		//-------------copy the map------------------------------
		ArrayList<ArrayList<Double>> map = new ArrayList<ArrayList<Double>>();
		ArrayList<Integer> demand = new ArrayList<Integer>();
		for(int i = 0; i < data.n + 1; i++){
			ArrayList<Double> row = new ArrayList<Double>();
			for(int j = 0; j < data.n + 1; j++)
				row.add(y[i][j]);
			map.add(row);
			demand.add(1);
		}
		ArrayList<ArrayList<Integer>> node = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n + 1; i++){
			ArrayList<Integer> s = new ArrayList<Integer>();
			s.add(i);
			node.add(s);
		}
		while(node.size() > 3){
			double max_y = 0.0;
			int i_id = -1;
			int j_id = -1;
			//-----initialize the edge set---------------------------
			for(int i = 0; i < node.size() - 1; i++){
				for(int j = i + 1; j < node.size() - 1; j++){
					double v = map.get(i).get(j) + map.get(j).get(i);
					if(v > max_y){
						max_y = v;
						i_id = i;
						j_id = j;
					}
				}
			}
			if(max_y <= 0.5)
				break;
			//------shrink node j into node i-------------------------
			for(int k = 0; k < node.size(); k++){
				if(k != i_id && k != j_id){
					map.get(k).set(i_id, map.get(k).get(i_id) + map.get(k).get(j_id));
					map.get(i_id).set(k, map.get(i_id).get(k) + map.get(j_id).get(k));
				}
			}
			for(int k = 0; k < node.size(); k++)
				map.get(k).remove(j_id);
			map.remove(j_id);
			for(int k = 0; k < node.get(j_id).size(); k++){
				node.get(i_id).add(node.get(j_id).get(k));
			}
			node.remove(j_id);
			demand.set(i_id, demand.get(i_id) + demand.get(j_id));
			demand.remove(j_id);
			//--------------------------------------------------------
			//--------check whehter node i is valid cut---------------
			//--------------------------------------------------------
			int right = (int)Math.ceil(((double)demand.get(i_id)) / data.Q);
			double left = 0;
			for(int k = 0; k < node.size(); k++){
				if(k != i_id){
						left += map.get(i_id).get(k);
				}
			}
			if(left + 0.01  < right){
				retS.add((ArrayList<Integer>) node.get(i_id).clone());
				rightS.add(right);
			}
		}
	}
	
	public void recursive(double[][] y, int id){
		rec_S[id] = 1;
		for(int i = 0; i < data.n; i++)
			if((y[id][i] > 0 || y[i][id] > 0)&& rec_S[i] == 0 && left_comp[i] == 0)
				recursive(y, i);
	}
	
	public ArrayList<ArrayList<Integer>> max_comp(double[][] y){
		ArrayList<ArrayList<Integer>> comps = new ArrayList<ArrayList<Integer>>();
		rec_S = new int[data.n + 1];
		left_comp = new int[data.n + 1];
		while(true){
			//------------------------------------------
			//---initialize the set---------------------
			//------------------------------------------
			int start_point = -1;
			//-----------------------------------------
			//----find the start point-----------------
			//-----------------------------------------
			for(int i = 0; i < data.n; i++)
				if(left_comp[i] == 0){
					start_point = i;
					break;
				}
			if(start_point == -1)
				break;
			//------------------------------------------
			//-------search-----------------------------
			//------------------------------------------
			recursive(y, start_point);
			//------------------------------------------
			//----add the result------------------------
			//------------------------------------------
			ArrayList<Integer> comp = new ArrayList<Integer>();
			for(int i = 0; i < data.n; i++){
				if(rec_S[i] == 1){
					left_comp[i] = 1;
					rec_S[i] = 0;
					comp.add(i);
				}
			}
			comps.add(comp);
		}
		return comps;
	}
	
	
	public void route_base(RMP lp){
		//------get the maximum components---------------------------
		ArrayList<ArrayList<Integer>> max_comps = max_comp(map);
		//-----------------------------------------------------------
		//----algorithms start---------------------------------------
		//-----------------------------------------------------------
		while(max_comps.size() > 0){
			HashSet<ArrayList<Integer>> hash = new HashSet<ArrayList<Integer>>();
			//-------------------------------------------------------
			//-----get the component---------------------------------
			//-------------------------------------------------------
			ArrayList<Integer> comp = max_comps.get(0);
			max_comps.remove(0);
			//-------------------------------------------------------
			//--------find the best route----------------------------
			//-------------------------------------------------------
			ArrayList<SortObject> col_list = new ArrayList<SortObject>();
			for(int i = 0; i < lp.active_value.size(); i++){
				ArrayList<Integer> route = lp.pool.column_pool.get(lp.active_set.get(i));
				//------------------------------------------------
				//-----check the connected size-------------------
				//------------------------------------------------
				int in_count = 0;
				double sq = 0;
				for(int j = 1; j <= route.get(0); j++)
					if(comp.contains(route.get(j)) == true){
						sq += 1;
						in_count++;
					}
				if(comp.size() - in_count < 2)
					continue;
				SortObject obj = new SortObject();
				obj.id = lp.active_set.get(i);;
				obj.val = lp.active_value.get(i) - sq / data.Q;
				col_list.add(obj);
			}
			Collections.sort(col_list);
			//-------------------------------------------------------
			//---------analyze the components------------------------
			//-------------------------------------------------------
			for(int k = 0; k < col_list.size(); k++){
				//-----------tabu customer---------------------------
				int[] tabu = new int[data.n + 1];
				int remove_size = 0;
				ArrayList<Integer> route = lp.pool.column_pool.get(col_list.get(k).id);
				for(int i = 1; i <= route.get(0); i++)
					tabu[route.get(i)] = 1;
				//---------------------------------------------------
				//-------test whether comp is a valid cut------------
				//---------------------------------------------------
				double sq = 0;
				for(int i = 0; i < comp.size(); i++){
					if(tabu[comp.get(i)] == 0)
						sq += 1;
					else
						remove_size++;
				}
				if(remove_size > 5)
					break;
				int right = (int) Math.ceil(sq / data.Q);
				double left = 0;
				for(int i = 0; i < data.n + 1; i++){
					if(tabu[i] == 1 || comp.contains(i) == false){
						for(int j = 0; j < comp.size(); j++)
							if(tabu[comp.get(j)] == 0)
						    	left += map[comp.get(j)][i];
					}
				}
				if(left + 0.01  < right){
					ArrayList<Integer> cut = new ArrayList<Integer>();
					for(int i = 0; i < comp.size(); i++)
						if(tabu[comp.get(i)] == 0)
							cut.add(comp.get(i));
					if(hash.contains(cut) == false){
						hash.add(cut);
						retS.add(cut);
						rightS.add(right);
					}
				}
			}
			//---------------------------------------------------
			//--------remove the customers-----------------------
			//---------------------------------------------------
			comp.remove(0);
		}
	}
	
	public void solve(RMP lp){
		map = lp.arc_map;
		retS = new ArrayList<ArrayList<Integer>>();
		rightS = new ArrayList<Integer>();
		route_base(lp);
		shrink(map);
	}
}
