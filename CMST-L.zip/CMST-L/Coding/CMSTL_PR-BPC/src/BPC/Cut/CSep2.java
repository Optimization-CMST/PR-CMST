package BPC.Cut;
//checking 2015-1-5
//checked 2015-1-5

import BPC.LP.RMP;
import Common.Data;

import java.util.ArrayList;
import java.util.HashSet;

public class CSep2 {

	
	public Data data;
	public ArrayList<ArrayList<Integer>> retS;
	public ArrayList<Integer> rightS;
	public ArrayList<Double> gaps;
	public int limit_size;
	
	public ArrayList<Long> con1;
	public ArrayList<Long> con2;
	public ArrayList<Long> con3;
	public ArrayList<Long> con4;
	
	public HashSet<ArrayList<Long>> hash;
	public int count = 0;
	
	//debug 
	public ArrayList<Integer> path;
	public long d1;
	public long d2;
	public long d3;
	public long d4;
	
	public CSep2(){};
	
	public CSep2(Data d){
		data = d;
		limit_size = 10;
		path = new ArrayList<Integer>();
		path.add(14);
		path.add(42);
		path.add(49);
		path.add(43);
		path.add(69);
		path.add(66);
		path.add(8);
		path.add(59);
		path.add(62);
		//path.add(84);
		//path.add(95);
		for(int i = 0; i < path.size(); i++){
			int id = path.get(i);
			if(id < 64)
				d1 = d1 | data.mask[id];
			else if(id < 128)
				d2 = d2 | data.mask[id];
			else if(id < 192)
				d3 = d3 | data.mask[id];
			else 
				d4 = d4 | data.mask[id];
		}
	}
	
	public void recursive(double[][]y, long S1, long S2, long S3, long S4, ArrayList<Integer> cut, int start, double sq, double v, int depth, long I1, long I2, long I3, long I4){
		//if(depth > 31)
			//return;
		count++;
		if(count > 2000000)
			return;
		//-------------------------------------------------
		//-----calculate the simga(d_{i})------------------
		//-------------------------------------------------
		if(start >= 0 && start < data.n)
			sq += 1;
		//-------------------------------------------------
		//--------calculate delta(S)-----------------------
		//-------------------------------------------------
		if(start >= 0 && start < data.n){
			for(int i = 0; i < data.n + 1; i++){ 
				if(i < 64){
					if((S1 & data.mask[i]) != 0x00)
						v -= y[i][start];
					else
						v += y[start][i];
				}
				else if(i < 128){
					if((S2 & data.mask[i]) != 0x00)
						v -= y[i][start];
					else
						v += y[start][i];
				}
				else if(i < 192){
					if((S3 & data.mask[i]) != 0x00)
						v -= y[i][start];
					else
						v += y[start][i];
				}
				else{
					if((S4 & data.mask[i]) != 0x00)
						v -= y[i][start];
					else
						v += y[start][i];
				}
			}
		}
		int right = (int)Math.ceil(sq/data.Q);

		if(v + 0.05 < right){
			retS.add((ArrayList<Integer>) cut.clone());
			rightS.add(right);
			gaps.add(right - v);
			return;
		}
		if(v - right > 1.3){
			return;
		}
		//-------------------------------------------------
		//--------extend to the next level-----------------
		//-------------------------------------------------
		for(int i = 0; i < data.n; i++){
			boolean is_continue = true;
			if(depth == 0){
				is_continue = false;
			}
			else if(i < 64){
				if((I1 & data.mask[i]) != 0x00)
					is_continue = false;
			}
			else if(i < 128){
				if((I2 & data.mask[i]) != 0x00)
					is_continue = false;
			}
			else if(i < 192){
				if((I3 & data.mask[i]) != 0x00)
					is_continue = false;
			}
			else{
				if((I4 & data.mask[i]) != 0x00)
					is_continue = false;
			}
			if(is_continue)
				continue;
			long tS1 = S1;
			long tS2 = S2;
			long tS3 = S3;
			long tS4 = S4;
			if(i < 64){
				tS1 = tS1 | data.mask[i];
			}
			else if(i < 128){
				tS2 = tS2 | data.mask[i];
			}
			else if(i < 192){
				tS3 = tS3 | data.mask[i];
			}
			else{
				tS4 = tS4 | data.mask[i];
			}
			long t1 = (I1 | con1.get(i)) & (~tS1);
			long t2 = (I2 | con2.get(i)) & (~tS2);
			long t3 = (I3 | con3.get(i)) & (~tS3);
			long t4 = (I4 | con4.get(i)) & (~tS4);
			ArrayList<Long> key = new ArrayList<Long>();
			key.add(tS1);
			key.add(tS2);
			key.add(tS3);
			key.add(tS4);
			if(hash.contains(key))
				continue;
			cut.add(i);
			hash.add(key);
			recursive(y, tS1, tS2, tS3, tS4, cut, i, sq, v, depth + 1, t1, t2, t3, t4);
			cut.remove(cut.size() - 1);
		}
	}
	
	public void solve(RMP lp){
		retS = new ArrayList<ArrayList<Integer>>();
		rightS = new ArrayList<Integer>();
		gaps = new ArrayList<Double>();
		con1 = new ArrayList<Long>();
		con2 = new ArrayList<Long>();
		con3 = new ArrayList<Long>();
		con4 = new ArrayList<Long>();
		hash = new HashSet<ArrayList<Long>>();
		for(int i = 0; i < data.n + 1; i++){
			long I1 = 0x00;
			long I2 = 0x00;
			long I3 = 0x00;
			long I4 = 0x00;
			for(int j = 0; j < data.n + 1; j++){
				if(lp.arc_map[j][i] > 0 || lp.arc_map[i][j] > 0){
					if(j < 64)
						I1 = I1 | data.mask[j];
					else if(j < 128)
						I2 = I2 | data.mask[j];
					else if(j < 192)
						I3 = I3 | data.mask[j];
					else 
						I4 = I4 | data.mask[j];
				}
			}
			con1.add(I1);
			con2.add(I2);
			con3.add(I3);
			con4.add(I4);
		}
		//int[] S = new int[data.N + 1];
		ArrayList<Integer> cut = new ArrayList<Integer>();
		long I1 = 0x00;
		long I2 = 0x00;
		long I3 = 0x00;
		long I4 = 0x00;
		long S1 = 0x00;
		long S2 = 0x00;
		long S3 = 0x00;
		long S4 = 0x00;
		count = 0;
		recursive(lp.arc_map, S1, S2, S3, S4, cut, data.n, 0, 0, 0, I1, I2, I3, I4);
		System.out.println("count " + count);
		//select the results
		ArrayList<ArrayList<Integer>> new_retS = new ArrayList<ArrayList<Integer>>(); 
		ArrayList<Integer> new_rights = new ArrayList<Integer>();
		while(new_retS.size() < 10 && retS.size() > 0){
			//select the best
			int best_id = -1;
			double max_v = 0;
			for(int i = 0; i < gaps.size(); i++){
				if(gaps.get(i) > max_v){
					max_v = gaps.get(i);
					best_id = i;
				}
			}
			new_retS.add(retS.get(best_id));
			new_rights.add(rightS.get(best_id));
			retS.remove(best_id);
			rightS.remove(best_id);
			gaps.remove(best_id);
		}
		retS = new_retS;
		rightS = new_rights;
	}
	
}
