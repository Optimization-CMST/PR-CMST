package BPC.LP;

import BPC.Cut.CutPool;
import BPC.SearchTree.Node;
import Common.Data;
import Helper.*;
import com.gurobi.gurobi.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

public class RMP {

	//-------common data------------------------------------------------------
	public Data data;
	public Pool pool;
	public Node node;
	//-------route information------------------------------------------------
	public ArrayList<Integer> route_index;
	public HashSet<Integer> route_hashset; //to fast check whether an index in route index or not
	public ArrayList<GRBVar> column_vars;
	//------lp solution information-------------------------------------------
	public ArrayList<Double> active_value;
	public ArrayList<Integer> active_set;
	public ArrayList<Integer> reduced_set;
	public double[] inverter_map;
	public double[][] arc_map;
	public double cost;
	//------cplex model--------------------------------------------------------
	public GRBModel model;
	public GRBEnv env;
	public GRBExpr obj;
	//------map from customer or arc to matrix row----------------------------
	//constraints (1): very panel must be covered;
	public GRBConstr[] visit_ranges;
	public GRBConstr root_range_UB;
	public GRBConstr root_range_LB;
	//------matrix mapping information ---------------------------------------
	public HashMap<Integer, Integer> r2p;  //map from the route index to the position of column in the model matrix
	//------route mapping information------------------------------------------
	public ArrayList<ArrayList<Integer>> i2ri;
	public ArrayList<ArrayList<ArrayList<Integer>>> ij2ri;
	//------dual information---------------------------------------------------
	public double[] mu; //variable dual profit
	//------solution information-----------------------------------------------
	public ArrayList<ArrayList<Integer>> route_set;
	//------other information--------------------------------------------------
	public boolean non_negative;
	//-----for the sr cuts-----------------------------------------------------
	public ArrayList<ArrayList<ArrayList<Integer>>> i_j2ri;
	public boolean is_sr_add;
	public ArrayList<ArrayList<Integer>> sr_cuts;
	public ArrayList<Integer> sr_index;  //the row index in the matrix
	public ArrayList<Double> sr_dual; //the dual values of the sr cuts
	public ArrayList<Integer> neg_index; //the set of sr_cuts with negative dual values
	public ArrayList<ArrayList<Integer>> node_index;
	public ArrayList<GRBConstr> sr_ranges;
	//-----for the capacity inequalities--------------------------------------
	public ArrayList<Integer> cap_index;
	public CutPool cut_pool;
	public HashMap<Integer, Integer> c2p;
	public ArrayList<ArrayList<ArrayList<Integer>>> ij2cap;
	public ArrayList<GRBConstr> cap_ranges;
	public double[][] dual_arc;
	//----useful cuts---------------------------------------------------------
	public ArrayList<Integer> useful_cc;     //当前LP下有效的cut
	public ArrayList<Integer> useful_sr;
	//---for computation of the sr inequalities--------------------------------
	public int seg_size = 15;
	//public ArrayList<HashMap<Integer, Double>> sr_comp;
	public double[][] sr_comp;    // this structure stores the dual values of subset row cuts
	public ArrayList<ArrayList<Integer>> sr_node_set;
	public HashMap<ArrayList<Integer>, ArrayList<Integer>> sr_map;
	//recode labels number
	public int[] join_count;
	public int[][] join_countx;
	//----stablized column generation-----------------------------------------
//	public double sum_sr;
//	public boolean is_all_zero;
//	public double sr_step;
//	public double sr_ub;
//	public GRBVar tsr_var = null;
//	public boolean pos_tsr;
//	public GRBVar[] mu_slacks;
//	public double[] mu_ub;
//	public double mu_step;
//	public boolean[] pos_mu;
	//---branch dual limitation-----------------------------------------------
//	public double[][] br_dual_ub;
//	public GRBVar[][] br_var;
//	public boolean[][] pos_br;
//	public double br_step;
	//consecutive non-nonpositive
	public int non_impr = 0;
	//--vehicle number variable----------------------------------------------
//	public GRBVar slack_vpos;
//	public GRBVar slack_vneg;

	public RMP(Data d){
		data = d;
	}

	public RMP copy_to(){
		RMP new_lp = new RMP(data);
		return new_lp;
	}

	public void construct(Node n, CutPool cp) throws GRBException {
		//common data
		node = n;
		//construct the pool
		pool = new Pool(data, node.column_set);
		ArrayList<Integer> init_colset = new ArrayList<Integer> ();
		for(int i = 0; i < node.column_set.size(); i++){
			init_colset.add(i);
		}
		//route information
		route_index = new ArrayList<Integer>();
		route_hashset = new HashSet<Integer>();
		column_vars = new ArrayList<GRBVar>();
		//lp solution information
		active_value = new ArrayList<Double>();
		active_set = new ArrayList<Integer>();
		reduced_set = new ArrayList<Integer>();
		inverter_map = new double[data.n];
		arc_map = new double[data.n + 1][data.n + 1];
		cost = 1e10;
		//gurobi model
		env = new GRBEnv(true);
        env.set("OutputFlag", "0");
		env.start();
		model = new GRBModel(env);
		obj = new GRBLinExpr();
		model.setObjective(obj, GRB.MINIMIZE);
//		cplex.setParam(IloCplex.IntParam.Threads, 1);
//		cplex.setParam(IloCplex.DoubleParam.EpOpt, 1e-2);
//		cplex.setParam(IloCplex.DoubleParam.EpMrk, 0.1);
//		cplex.setParam(IloCplex.IntParam.ScaInd, 1);
		//cplex.setParam(IloCplex.DoubleParam.EpRHS, 1e-9);
		visit_ranges = new GRBConstr[data.n + 1];
		//matrix mapping information
		r2p = new HashMap<Integer, Integer>();
		//route mapping information
		i2ri = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n; i++){
			i2ri.add(new ArrayList<Integer>());
		}
		ij2ri = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n + 1; i++){
			ij2ri.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n + 1; j++){
				ij2ri.get(i).add(new ArrayList<Integer>());
			}
		}
		//dual information
		mu = new double[data.n + 1];
		//new the sr information
		i_j2ri = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n; i++){
			i_j2ri.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n; j++){
				i_j2ri.get(i).add(new ArrayList<Integer>());
			}
		}
		is_sr_add = false;
		sr_cuts = new ArrayList<ArrayList<Integer>>();
		sr_index = new ArrayList<Integer>();
		sr_dual = new ArrayList<Double>();
		neg_index = new ArrayList<Integer>();
		node_index = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n; i++){
			node_index.add(new ArrayList<Integer>());
		}
		sr_ranges = new ArrayList<GRBConstr>();
		//new the capacity inequalities information
		cap_index = new ArrayList<Integer>();
		cut_pool = cp;
		ij2cap = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n + 1; i++){
			ij2cap.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n + 1; j++){
				ij2cap.get(i).add(new ArrayList<Integer>());
			}
		}
		cap_ranges = new ArrayList<GRBConstr>();
		c2p = new HashMap<Integer, Integer>();
		dual_arc = new double[data.n + 1][data.n + 1];
		//useful cuts
		useful_cc = new ArrayList<Integer>();
		useful_sr = new ArrayList<Integer>();
		//-----------construct the cplex model--------------------------------------
		//total route constraints
		//constraints (1)
		for(int i = 0; i < data.n + 1; i++){
			if(i == data.n){
				GRBLinExpr emptyExpr_1 = new GRBLinExpr();
				GRBLinExpr emptyExpr_2 = new GRBLinExpr();
				root_range_LB = model.addConstr(emptyExpr_1, GRB.GREATER_EQUAL, node.klb, "lb");
				root_range_UB = model.addConstr(emptyExpr_2, GRB.LESS_EQUAL, node.kub, "ub");
			}
			else {
				GRBLinExpr emptyExpr = new GRBLinExpr();
				visit_ranges[i] = model.addConstr(emptyExpr, GRB.EQUAL, 1.0, "RC," + i);
			}
		}
		//add the two slack number
//		if(node.klb > 0 || node.kub < data.n){
//			slack_vpos = model.addVar(0, GRB.INFINITY, 1e9, GRB.CONTINUOUS, "slack_vpos");
//			slack_vneg = model.addVar(0, GRB.INFINITY, 1e9, GRB.CONTINUOUS, "slack_vneg");
//
//			GRBLinExpr expr = model.getRow(visit_ranges[data.n]);
//			expr.addTerm(1, 	slack_vpos);
//			expr.addTerm(-1, slack_vneg);
//		}

		//-------the stablized column generation------------------------------------------
//		is_all_zero = false;
//		sr_step = 10;
//		sr_ub = node.tsr;
//		tsr_var = null;
//		pos_tsr = false;
//		mu_slacks = new GRBVar[data.n + 1];
//		mu_ub =new double[data.n + 1];
//		pos_mu = new boolean[data.n + 1];
//		mu_step = 2;
		//--------branch dual information--------------------------------------------------
//		br_dual_ub = new double[data.n + 1][data.n + 1];
//		br_var = new GRBVar[data.n + 1][data.n + 1];
//		for(int i = 0; i < data.n + 1; i++){
//			for(int j = 0; j < data.n + 1; j++){
//				if(i == j)
//					continue;
//				br_dual_ub[i][j] = 5;
//				br_var[i][j] = null;
//			}
//		}
//		pos_br = new boolean[data.n + 1][data.n + 1];
//		br_step = 5;
		//--------solution information-----------------------------------------------------
		route_set = new ArrayList<ArrayList<Integer>>();
		//--------add the model to cplex---------------------------------------------------
		System.out.println("initial column set size: " + init_colset.size());
		add_col(init_colset);
		//--------add the cuts to cplex----------------------------------------------------
		add_cuts(node.cc_index);
		System.out.println("cc_index size : " + node.cc_index.size());
		add_sr_cut(node.sr_cuts);
		System.out.println("sr_index size : " + node.sr_cuts.size());
	}

	public void construct_IP(ArrayList<ArrayList<Integer>> column_set, CutPool cp) throws GRBException {
		//construct the pool
		ArrayList<ArrayList<Integer>> IP_column = (ArrayList<ArrayList<Integer>>) column_set.clone();
		pool = new Pool(data, IP_column);
		ArrayList<Integer> init_colset = new ArrayList<Integer> ();
		for(int i = 0; i < IP_column.size(); i++){
			init_colset.add(i);
		}
		//route information
		route_index = new ArrayList<Integer>();
		route_hashset = new HashSet<Integer>();
		column_vars = new ArrayList<GRBVar>();
		//lp solution information
		active_value = new ArrayList<Double>();
		active_set = new ArrayList<Integer>();
		reduced_set = new ArrayList<Integer>();
		inverter_map = new double[data.n];
		arc_map = new double[data.n + 1][data.n + 1];
		cost = 1e10;
		//gurobi model
		env = new GRBEnv(true);
		env.set("OutputFlag", "0");
		env.start();
		model = new GRBModel(env);
		obj = new GRBLinExpr();
		model.setObjective(obj, GRB.MINIMIZE);
		visit_ranges = new GRBConstr[data.n + 1];
		//matrix mapping information
		r2p = new HashMap<Integer, Integer>();
		//route mapping information
		i2ri = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n; i++){
			i2ri.add(new ArrayList<Integer>());
		}
		ij2ri = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n + 1; i++){
			ij2ri.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n + 1; j++){
				ij2ri.get(i).add(new ArrayList<Integer>());
			}
		}
		//dual information
		mu = new double[data.n + 1];
		//new the sr information
		i_j2ri = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n; i++){
			i_j2ri.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n; j++){
				i_j2ri.get(i).add(new ArrayList<Integer>());
			}
		}
		is_sr_add = false;
		sr_cuts = new ArrayList<ArrayList<Integer>>();
		sr_index = new ArrayList<Integer>();
		sr_dual = new ArrayList<Double>();
		neg_index = new ArrayList<Integer>();
		node_index = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n; i++){
			node_index.add(new ArrayList<Integer>());
		}
		sr_ranges = new ArrayList<GRBConstr>();
		//new the capacity inequalities information
		cap_index = new ArrayList<Integer>();
		cut_pool = cp;
		ij2cap = new ArrayList<ArrayList<ArrayList<Integer>>>();
		for(int i = 0; i < data.n + 1; i++){
			ij2cap.add(new ArrayList<ArrayList<Integer>>());
			for(int j = 0; j < data.n + 1; j++){
				ij2cap.get(i).add(new ArrayList<Integer>());
			}
		}
		cap_ranges = new ArrayList<GRBConstr>();
		c2p = new HashMap<Integer, Integer>();
		dual_arc = new double[data.n + 1][data.n + 1];
		//useful cuts
		useful_cc = new ArrayList<Integer>();
		useful_sr = new ArrayList<Integer>();
		//-----------construct the cplex model--------------------------------------
		//total route constraints
		//constraints (1)
		for(int i = 0; i < data.n + 1; i++){
			if(i == data.n){
				GRBLinExpr emptyExpr_1 = new GRBLinExpr();
				GRBLinExpr emptyExpr_2 = new GRBLinExpr();
				root_range_LB = model.addConstr(emptyExpr_1, GRB.GREATER_EQUAL, 0, "lb");
				root_range_UB = model.addConstr(emptyExpr_2, GRB.LESS_EQUAL, data.n + 1, "ub");
			}
			else {
				GRBLinExpr emptyExpr = new GRBLinExpr();
				visit_ranges[i] = model.addConstr(emptyExpr, GRB.EQUAL, 1.0, "RC," + i);
			}
		}
		//--------solution information-----------------------------------------------------
		route_set = new ArrayList<ArrayList<Integer>>();
		//--------add the model to cplex---------------------------------------------------
		System.out.println("initial column set size: " + init_colset.size());
		add_col_IP(init_colset);
	}

	public void add_col(ArrayList<Integer> cset) throws GRBException {
		for(int i = 0; i < cset.size(); i++){
			ArrayList<Integer> column = pool.get_column(cset.get(i));
			double cost = pool.get_column_cost(cset.get(i));
			int size = column.get(0);
			//IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "" + cset.get(i));
			//get the cover size
			int root = column.get(1);
			int is_size = 0;
			if(root_range_LB != null && root_range_UB != null){
				is_size = 1;
			}
			ArrayList<Integer> cc = new ArrayList<Integer>();      // which capacity cuts is violated
			ArrayList<Integer> ccv = new ArrayList<Integer>();     // number of violated
			HashMap<Integer, Integer> cc_map = new HashMap<Integer, Integer>();
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(size + j) >= 0)      // its father
					id2 = column.get(column.get(size + j));
				ArrayList<Integer> cuts = ij2cap.get(id1).get(id2);
				for(int k = 0; k < cuts.size(); k++){
					int cindex= cuts.get(k);
					if(cc_map.containsKey(cindex)){
						int place = cc_map.get(cindex);
						ccv.set(place, ccv.get(place) + 1);
					}
					else{
						cc.add(cindex);
						ccv.add(1);
						cc_map.put(cindex, cc.size() - 1);
					}
				}
			}
			ArrayList<Integer> sr = new ArrayList<Integer>();
			ArrayList<Integer> srv = new ArrayList<Integer>();
			if(is_sr_add){
				int[]  col_map = new int[data.n];
				for(int j = 1; j <= size; j++){
					col_map[column.get(j)]++;
				}
				for(int j = 0; j < sr_index.size(); j++){
					ArrayList<Integer> cut = sr_cuts.get(j);
					int count = 0;
					for(int k = 0; k < cut.size(); k++){
						count += col_map[cut.get(k)];
					}
					int v = Help.floor(count / 2.0);
					if(v > 0){
						sr.add(sr_index.get(j));
						srv.add(v);
					}
				}
			}
			//set the column
			GRBColumn col = new GRBColumn();
			for(int j = 1; j <= size; j++){
				int id = column.get(j);
				col.addTerm(1, visit_ranges[id]);
			}
			if(is_size > 0){
				col.addTerm(1, root_range_LB);
				col.addTerm(1, root_range_UB);
			}
			for(int j = 0; j < cc.size(); j++){
				GRBConstr range = cap_ranges.get(c2p.get(cc.get(j)));
				col.addTerm(ccv.get(j), range);
			}
			for(int j = 0; j < sr.size(); j++){
				GRBConstr range = sr_ranges.get(sr.get(j));
				col.addTerm(srv.get(j), range);
			}
			//add to the matrix
			double t1 = System.nanoTime();
			GRBVar var = model.addVar(0.0, GRB.INFINITY, cost, GRB.CONTINUOUS, col, "column" + col);
			column_vars.add(var);
			r2p.put(cset.get(i), column_vars.size() - 1);
			double t2 = System.nanoTime();
			//data.configure.addcol_cplex_time += t2 - t1;
			//add to the index set
			route_index.add(cset.get(i));
			route_hashset.add(cset.get(i));            // cset stor the index of column in the pool set
			//add to the route map
			for(int j = 1; j <= size; j++){
				int id = column.get(j);
				i2ri.get(id).add(cset.get(i));
			}
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(size + j) >= 0)
					id2 = column.get(column.get(size + j));
				ij2ri.get(id1).get(id2).add(cset.get(i));
			}
			for(int j = 1; j < size; j++){
				for(int k = j + 1; k <= size; k++){
					i_j2ri.get(column.get(j)).get(column.get(k)).add(cset.get(i));
				}
			}
		}
	}


	public void add_col_IP(ArrayList<Integer> cset) throws GRBException {
		for(int i = 0; i < cset.size(); i++){
			ArrayList<Integer> column = pool.get_column(cset.get(i));
			double cost = pool.get_column_cost(cset.get(i));
			int size = column.get(0);
			//IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "" + cset.get(i));
			//get the cover size
			int root = column.get(1);
			int is_size = 0;
			if(root_range_LB != null && root_range_UB != null){
				is_size = 1;
			}
			ArrayList<Integer> cc = new ArrayList<Integer>();      // which capacity cuts is violated
			ArrayList<Integer> ccv = new ArrayList<Integer>();     // number of violated
			HashMap<Integer, Integer> cc_map = new HashMap<Integer, Integer>();
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(size + j) >= 0)      // its father
					id2 = column.get(column.get(size + j));
				ArrayList<Integer> cuts = ij2cap.get(id1).get(id2);
				for(int k = 0; k < cuts.size(); k++){
					int cindex= cuts.get(k);
					if(cc_map.containsKey(cindex)){
						int place = cc_map.get(cindex);
						ccv.set(place, ccv.get(place) + 1);
					}
					else{
						cc.add(cindex);
						ccv.add(1);
						cc_map.put(cindex, cc.size() - 1);
					}
				}
			}
			ArrayList<Integer> sr = new ArrayList<Integer>();
			ArrayList<Integer> srv = new ArrayList<Integer>();
			if(is_sr_add){
				int[]  col_map = new int[data.n];
				for(int j = 1; j <= size; j++){
					col_map[column.get(j)]++;
				}
				for(int j = 0; j < sr_index.size(); j++){
					ArrayList<Integer> cut = sr_cuts.get(j);
					int count = 0;
					for(int k = 0; k < cut.size(); k++){
						count += col_map[cut.get(k)];
					}
					int v = Help.floor(count / 2.0);
					if(v > 0){
						sr.add(sr_index.get(j));
						srv.add(v);
					}
				}
			}
			//set the column
			GRBColumn col = new GRBColumn();
			for(int j = 1; j <= size; j++){
				int id = column.get(j);
				col.addTerm(1, visit_ranges[id]);
			}
			if(is_size > 0){
				col.addTerm(1, root_range_LB);
				col.addTerm(1, root_range_UB);
			}
			for(int j = 0; j < cc.size(); j++){
				GRBConstr range = cap_ranges.get(c2p.get(cc.get(j)));
				col.addTerm(ccv.get(j), range);
			}
			for(int j = 0; j < sr.size(); j++){
				GRBConstr range = sr_ranges.get(sr.get(j));
				col.addTerm(srv.get(j), range);
			}
			//add to the matrix
			double t1 = System.nanoTime();
			GRBVar var = model.addVar(0.0, GRB.INFINITY, cost, GRB.BINARY, col, "column" + col);
			column_vars.add(var);
			r2p.put(cset.get(i), column_vars.size() - 1);
			double t2 = System.nanoTime();
			//data.configure.addcol_cplex_time += t2 - t1;
			//add to the index set
			route_index.add(cset.get(i));
			route_hashset.add(cset.get(i));            // cset stor the index of column in the pool set
			//add to the route map
			for(int j = 1; j <= size; j++){
				int id = column.get(j);
				i2ri.get(id).add(cset.get(i));
			}
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(size + j) >= 0)
					id2 = column.get(column.get(size + j));
				ij2ri.get(id1).get(id2).add(cset.get(i));
			}
			for(int j = 1; j < size; j++){
				for(int k = j + 1; k <= size; k++){
					i_j2ri.get(column.get(j)).get(column.get(k)).add(cset.get(i));
				}
			}
		}
	}

	public void add_cuts(ArrayList<Integer> cut_set) throws GRBException {
		for(int i = 0; i < cut_set.size(); i++){
			int cindex = cut_set.get(i);
			ArrayList<Integer> S = cut_pool.cut_pool.get(cindex);
			ArrayList<Integer> relative_route = new ArrayList<Integer>();
			HashMap<Integer, Integer> map = new HashMap<Integer, Integer>();
			for(int j = 0; j < S.size(); j++){
				for(int k = 0; k < data.n + 1; k++){
					if(S.contains(k) == false){
						ArrayList<Integer> route_set = ij2ri.get(S.get(j)).get(k);
						for(int h = 0; h < route_set.size(); h++){
							int ri = route_set.get(h);
							if(map.containsKey(ri) == true){
								int v = map.get(ri);
								map.put(ri, v + 1);
							}
							else{
								relative_route.add(ri);
								map.put(ri, 1);
							}
						}
					}
				}
			}
			GRBLinExpr expr = new GRBLinExpr();
			for(int j = 0; j < relative_route.size(); j++){
				int ri = relative_route.get(j);
				expr.addTerm(map.get(ri), column_vars.get((r2p.get(ri))));
			}
			GRBConstr range = model.addConstr(expr, GRB.GREATER_EQUAL, cut_pool.right.get(cindex), "CUT," + cindex);
			cap_ranges.add(range);

			c2p.put(cindex, cap_ranges.size() - 1);
			for(int j = 0; j < S.size(); j++){
				for(int k = 0; k < data.n + 1; k++){
					if(S.contains(k) == false){
						ij2cap.get(S.get(j)).get(k).add(cindex);
					}
				}
			}
		}
		for(int i = 0; i < cut_set.size(); i++){
			cap_index.add(cut_set.get(i));
		}
	}

	public void add_sr_cut(ArrayList<ArrayList<Integer>> cuts) throws GRBException {
		if(cuts.size() > 0){
			is_sr_add = true;
		}
		for (int i = 0; i < cuts.size(); i++){
			ArrayList<Integer> cut = cuts.get(i);
			sr_cuts.add(cut);
			HashMap<Integer, Integer> hash = new HashMap<Integer, Integer>();
			ArrayList<Integer> var = new ArrayList<Integer>();
			ArrayList<Double> count = new ArrayList<Double>();
			for(int j = 0; j < cut.size(); j++){
				int id = cut.get(j);
				ArrayList<Integer> col_set = i2ri.get(id);
				for(int k = 0; k < col_set.size(); k++){
					int cid = col_set.get(k);
					if(hash.containsKey(cid)){
						int p = hash.get(cid);
						count.set(p, count.get(p) + 1);
					}
					else{
						var.add(cid);
						count.add(1.0);
						hash.put(cid, var.size() - 1);
					}
				}
			}
			double right = Math.floor(((double)cut.size())/2.0);
			GRBLinExpr expr =  new GRBLinExpr();
			for(int j = 0; j < var.size(); j++){
				GRBVar numvar = column_vars.get(r2p.get(var.get(j)));
				double coef = Math.floor(count.get(j) / 2.0);
				expr.addTerm(coef, numvar);
			}
//			GRBVar slack = model.addVar(0, GRB.INFINITY, 1e9,  GRB.CONTINUOUS, "slack");
//			expr.addTerm(-1, slack);
//			if(tsr_var != null)
//				expr.addTerm(-1, tsr_var);
			GRBConstr range = model.addConstr(expr, GRB.LESS_EQUAL, right, "subset");
			sr_ranges.add(range);
			sr_index.add(sr_ranges.size() - 1);
		}
	}


	public boolean is_feasible() {
		//check the integrity of each route
		for(int i = 0; i < active_value.size(); i++){
			double v = active_value.get(i);
			if(Help.is_fractional(v) == true)
				return false;
		}
		//--------get the solution----------------------------------
		route_set.clear();
		for(int i = 0; i < active_set.size(); i++){
			ArrayList<Integer> route = pool.get_column(active_set.get(i));
			route_set.add((ArrayList<Integer>) route.clone());
		}
		return true;
	}

	public void set_dual() throws GRBException {
		double[] old_delta = new double[data.n];
		for(int i = 0; i < data.n; i++){
			for(int j = 0; j < data.n; j++){
				if(j == i)
					old_delta[i] -= mu[j];
				else
					old_delta[i] += mu[j];
			}
		}
		for(int i = 0; i < data.n + 1; i++){
			if(i != data.n)
				mu[i] = visit_ranges[i].get(GRB.DoubleAttr.Pi);
			else{
				if (root_range_UB != null && root_range_LB !=null)
					mu[i] = root_range_UB.get(GRB.DoubleAttr.Pi) + root_range_LB.get(GRB.DoubleAttr.Pi);
			}

		}
		double[] new_delta = new double[data.n];
		for(int i = 0; i < data.n; i++){
			for(int j = 0; j < data.n; j++){
				if(j == i)
					new_delta[i] -= mu[j];
				else
					new_delta[i] += mu[j];
			}
		}
		for(int i = 0; i < data.n; i++){
			for(int j = 0; j < data.n + 1; j++){
				dual_arc[i][j] = 0.0;
				if(i == j)
					continue;
				ArrayList<Integer> cut_index = ij2cap.get(i).get(j);
				for(int k = 0; k < cut_index.size(); k++){
					dual_arc[i][j] += cap_ranges.get((c2p.get(cut_index.get(k)))).get(GRB.DoubleAttr.Pi);
				}
			}
		}
		if(is_sr_add){
			sr_dual.clear();
//			sum_sr = 0;
			for(int i = 0; i < sr_index.size(); i++){
				double dual = Math.min(0, sr_ranges.get(sr_index.get(i)).get(GRB.DoubleAttr.Pi));
				sr_dual.add(dual);
//				sum_sr += dual;
			}
			neg_index.clear();
			for(int i = 0; i < sr_dual.size(); i++){
				if(sr_dual.get(i) < -1e-3){
					neg_index.add(i);
				}
			}
			for(int i = 0; i < data.n; i++){
				node_index.get(i).clear();
			}
			for(int i = 0; i < neg_index.size(); i++){
				int index = neg_index.get(i);
				ArrayList<Integer> cut = sr_cuts.get(index);
				for(int j = 0; j < cut.size(); j++){
					node_index.get(cut.get(j)).add(i);          // node——index中纪录了每个节点上的对应的负的dual sr cuts索引集合
				}
			}
			build_sr_comp();
			build_sr_map();
		}
//		if(limit){
//			boolean add = false;
//			if(sum_sr < -sr_ub && tsr_var == null){
//				tsr_var = model.addVar(0, GRB.INFINITY, sr_ub, GRB.CONTINUOUS, "tsr_var");
//				for(int i = 0; i < sr_index.size(); i++){
//					int cp = sr_index.get(i);
//					//add a slack variable
//					GRBConstr range = sr_ranges.get(cp);
//					model.chgCoeff(range, tsr_var, -1);
//				}
//				add = true;
//			}
//			for(int i = 0; i < data.n; i++){
//				if(mu[i] < 10.0){
//					for(int j = 0; j < data.n + 1; j++){
//						if(node.feasible_arc[j][i] == 1 && br_var[j][i] == null){
//							add_branch_dual(j, i);
//							add = true;
//							break;
//						}
//					}
//				}
//			}
//
//			for(int i = 0; i < data.n; i++){
//				//if(old_delta[i] > 100 && new_delta[i] - old_delta[i] > 10 && mu_slacks[i] == null){
//				//capacity 5: 10 10 2
//				//capacity 10: -10
//				if(data.is_root == false && data.n < 100 && data.Q >= 10 && mu[i] < 10 && mu_slacks[i] == null){
//					mu_ub[i] = old_delta[i] - 10;
//					IloNumVar var = cplex.numVar(0.0, 1e10);
//					for(int j = 0; j < data.n; j++){
//						IloRange range = visit_ranges[j];
//						IloNumExpr expr = range.getExpr();
//						if(j == i)
//							expr = cplex.sum(expr, cplex.prod(-1, var));
//						else
//							expr = cplex.sum(expr, var);
//						range.setExpr(expr);
//					}
//					IloLinearNumExpr obj = (IloLinearNumExpr) cplex.getObjective().getExpr();
//					obj.addTerm(mu_ub[i], var);
//					cplex.getObjective().setExpr(obj);
//					mu_slacks[i] = var;
//					add = true;
//				}
//			}
//
//			if(add){
//				solve();
//				set_dual(true);
//			}
//		}
	}

	public void build_sr_comp(){
		seg_size = 19;
		int size = (int) Math.ceil(((double) neg_index.size()) / seg_size);
		//sr_comp = new ArrayList<HashMap<Integer, Double>>();
		sr_comp = new double[size][1024 * 512];
		int[] mask = new int[seg_size];
		int m = 0x01;
		for(int i = 0; i < seg_size; i++){
			mask[i] = m;
			m *= 2;
		}
		sr_node_set = new ArrayList<ArrayList<Integer>>();
		for(int i = 0; i < data.n; i++){
			ArrayList<Integer> set = new ArrayList<Integer>();
			for(int j = 0; j < size; j++){
				set.add(0);                     //Initialization
			}
			ArrayList<Integer> c_set = node_index.get(i);
			for (int j = 0; j < c_set.size(); j++){
				int id = c_set.get(j);
				int target = (int)Math.floor((double)(id) / seg_size);
				set.set(target, set.get(target) | mask[id - target * seg_size]);
			}
			sr_node_set.add(set);         // this structure stores index of negative dual value in different segments, each segment is a Integer value
		}

		for(int i = 0; i < size; i++){
			//HashMap<Integer, Double> map = new HashMap<Integer, Double>();
			int S0 = 0;
			double v0 = 0;
			for(int j1 = 0; j1 < 2; j1++){
				int S1 = S0;
				double v1 = v0;
				if(j1 == 1){
					S1 = S0 | mask[0];
					v1 = v0 + sr_dual.get(neg_index.get(i * seg_size + 0));
				}
				if(i * seg_size + 0 == neg_index.size() - 1){
					//map.put(S1, v1);
					sr_comp[i][S1] = v1;
				}
				else{
					for(int j2 = 0; j2 < 2; j2++){
						int S2 = S1;
						double v2 = v1;
						if(j2 == 1){
							S2 = S1 | mask[1];
							v2 = v1 + sr_dual.get(neg_index.get(i * seg_size + 1));
						}
						if(i * seg_size + 1 == neg_index.size() - 1){
							//map.put(S2, v2);
							sr_comp[i][S2] = v2;
						}
						else{
							for(int j3 = 0; j3 < 2; j3++){
								int S3 = S2;
								double v3 = v2;
								if(j3 == 1){
									S3 = S2 | mask[2];
									v3 = v2 + sr_dual.get(neg_index.get(i * seg_size + 2));
								}
								if(i * seg_size + 2 == neg_index.size() - 1){
									//map.put(S3, v3);
									sr_comp[i][S3] = v3;
								}
								else{
									for(int j4 = 0; j4 < 2; j4++){
										int S4 = S3;
										double v4 = v3;
										if(j4 == 1){
											S4 = S3 | mask[3];
											v4 = v3 + sr_dual.get(neg_index.get(i * seg_size + 3));
										}
										if(i * seg_size + 3 == neg_index.size() - 1){
											//map.put(S4, v4);
											sr_comp[i][S4] = v4;
										}
										else{
											for(int j5 = 0; j5 < 2; j5++){
												int S5 = S4;
												double v5 = v4;
												if(j5 == 1){
													S5 = S4 | mask[4];
													v5 = v4 + sr_dual.get(neg_index.get(i * seg_size + 4));
												}
												if(i * seg_size + 4 == neg_index.size() - 1){
													//map.put(S5, v5);
													sr_comp[i][S5] = v5;
												}
												else{
													for(int j6 = 0; j6 < 2; j6++){
														int S6 = S5;
														double v6 = v5;
														if(j6 == 1){
															S6 = S5 | mask[5];
															v6 = v5 + sr_dual.get(neg_index.get(i * seg_size + 5));
														}
														if(i * seg_size + 5 == neg_index.size() - 1){
															//map.put(S6, v6);
															sr_comp[i][S6] = v6;
														}
														else{
															for(int j7 = 0; j7 < 2; j7++){
																int S7 = S6;
																double v7 = v6;
																if(j7 == 1){
																	S7 = S6 | mask[6];
																	v7 = v6 + sr_dual.get(neg_index.get(i * seg_size + 6));
																}
																if(i * seg_size + 6 == neg_index.size() - 1){
																	//map.put(S7, v7);
																	sr_comp[i][S7] = v7;
																}
																else{
																	for(int j8 = 0; j8 < 2; j8++){
																		int S8 = S7;
																		double v8 = v7;
																		if(j8 == 1){
																			S8 = S7 | mask[7];
																			v8 = v7 + sr_dual.get(neg_index.get(i * seg_size + 7));
																		}
																		if(i * seg_size + 7 == neg_index.size() - 1){
																			//map.put(S8, v8);
																			sr_comp[i][S8] = v8;
																		}
																		else{
																			for(int j9 = 0; j9 < 2; j9++){
																				int S9 = S8;
																				double v9 = v8;
																				if(j9 == 1){
																					S9 = S8 | mask[8];
																					v9 = v8 + sr_dual.get(neg_index.get(i * seg_size + 8));
																				}
																				if(i * seg_size + 8 == neg_index.size() - 1){
																					//map.put(S9, v9);
																					sr_comp[i][S9] = v9;
																				}
																				else{
																					for(int j10 = 0; j10 < 2; j10++){
																						int S10 = S9;
																						double v10 = v9;
																						if(j10 == 1){
																							S10 = S9 | mask[9];
																							v10 = v9 + sr_dual.get(neg_index.get(i * seg_size + 9));
																						}
																						if(i * seg_size + 9 == neg_index.size() - 1){
																							//map.put(S10, v10);
																							sr_comp[i][S10] = v10;
																						}
																						else{
																							for(int j11 = 0; j11 < 2; j11++){
																								int S11 = S10;
																								double v11 = v10;
																								if(j11 == 1){
																									S11 = S10 | mask[10];
																									v11 = v10 + sr_dual.get(neg_index.get(i * seg_size + 10));
																								}
																								if(i * seg_size + 10 == neg_index.size() - 1){
																									sr_comp[i][S11] = v11;
																								}
																								else{
																									for(int j12 = 0; j12 < 2; j12++){
																										int S12 = S11;
																										double v12 = v11;
																										if(j12 == 1){
																											S12 = S11 | mask[11];
																											v12 = v11 + sr_dual.get(neg_index.get(i * seg_size + 11));
																										}
																										if(i * seg_size + 11 == neg_index.size() - 1){
																											sr_comp[i][S12] = v12;
																										}
																										else{
																											for(int j13 = 0; j13 < 2; j13++){
																												int S13 = S12;
																												double v13 = v12;
																												if(j13 == 1){
																													S13 = S12 | mask[12];
																													v13 = v12 + sr_dual.get(neg_index.get(i * seg_size + 12));
																												}
																												if(i * seg_size + 12 == neg_index.size() - 1){
																													sr_comp[i][S13] = v13;
																												}
																												else{
																													for(int j14 = 0; j14 < 2; j14++){
																														int S14 = S13;
																														double v14 = v13;
																														if(j14 == 1){
																															S14 = S13 | mask[13];
																															v14 = v13 + sr_dual.get(neg_index.get(i * seg_size + 13));
																														}
																														if(i * seg_size + 13 == neg_index.size() - 1){
																															sr_comp[i][S14] = v14;
																														}
																														else{
																															for(int j15 = 0; j15 < 2; j15++){
																																int S15 = S14;
																																double v15 = v14;
																																if(j15 == 1){
																																	S15 = S14 | mask[14];
																																	v15 = v14 + sr_dual.get(neg_index.get(i * seg_size + 14));
																																}
																																if(i * seg_size + 14 == neg_index.size() - 1){
																																	sr_comp[i][S15] = v15;
																																}
																																else{
																																	for(int j16 = 0; j16 < 2; j16++){
																																		int S16 = S15;
																																		double v16 = v15;
																																		if(j16 == 1){
																																			S16 = S15 | mask[15];
																																			v16 = v15 + sr_dual.get(neg_index.get(i * seg_size + 15));
																																		}
																																		if(i * seg_size + 15 == neg_index.size() - 1){
																																			sr_comp[i][S16] = v16;
																																		}
																																		else{
																																			for(int j17 = 0; j17 < 2; j17++){
																																				int S17 = S16;
																																				double v17 = v16;
																																				if(j17 == 1){
																																					S17 = S16 | mask[16];
																																					v17 = v16 + sr_dual.get(neg_index.get(i * seg_size + 16));
																																				}
																																				if(i * seg_size + 16 == neg_index.size() - 1){
																																					sr_comp[i][S17] = v17;
																																				}
																																				else{
																																					for(int j18 = 0; j18 < 2; j18++){
																																						int S18 = S17;
																																						double v18 = v17;
																																						if(j18 == 1){
																																							S18 = S17 | mask[17];
																																							v18 = v17 + sr_dual.get(neg_index.get(i * seg_size + 17));
																																						}
																																						if(i * seg_size + 17 == neg_index.size() - 1){
																																							sr_comp[i][S18] = v18;
																																						}
																																						else{
																																							for(int j19 = 0; j19 < 2; j19++){
																																								int S19 = S18;
																																								double v19 = v18;
																																								if(j19 == 1){
																																									S19 = S18 | mask[18];
																																									v19 = v18 + sr_dual.get(neg_index.get(i * seg_size + 18));
																																								}
																																								//if(i * seg_size + 18 == neg_index.size() - 1){
																																									sr_comp[i][S19] = v19;        //setting value
																																								//}
																																								//else{

																																								//}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
			//sr_comp.add(map);
		}
	}
	public void build_sr_map(){
		sr_map = new HashMap<>();
		for (int i = 0; i < neg_index.size(); i++){
			int id = neg_index.get(i);
			ArrayList<Integer> cut = sr_cuts.get(id);    //需要注意的点是这里的cut一定是以0到n的顺序存储的
			//首先存储每个点访问两次的map
			for (int j = 0; j < cut.size(); j++){
				int node = cut.get(j);
				ArrayList<Integer> arr_1 = new ArrayList<>();
				arr_1.add(node); arr_1.add(node);
				if (sr_map.containsKey(arr_1)){
					sr_map.get(arr_1).add(i);
				}
				else{
					ArrayList<Integer> arr_2 = new ArrayList<>();
					arr_2.add(i);
					sr_map.put(arr_1, arr_2);
				}
			}
			//存储两两访问的map
			for (int j = 0; j < cut.size() - 1; j++){
				for (int k = j + 1; k < cut.size(); k++){
					int node_1 = cut.get(j);
					int node_2 = cut.get(k);
					ArrayList<Integer> arr_1 = new ArrayList<>();
					arr_1.add(node_1); arr_1.add(node_2);
					if (sr_map.containsKey(arr_1)){
						sr_map.get(arr_1).add(i);
					}
					else{
						ArrayList<Integer> arr_2 = new ArrayList<>();
						arr_2.add(i);
						sr_map.put(arr_1, arr_2);
					}
				}
			}
		}
	}

	public ArrayList<Integer> neg_index2neg_size(int index){
		ArrayList<Integer> return_arr = new ArrayList<>();
		int first_level = (int)Math.floor((double)(index) / seg_size);
		int second_level = index - first_level * seg_size;
		return_arr.add(first_level);
		return_arr.add(second_level);
		return return_arr;
	}

//	public void add_branch_dual(int id1, int id2) throws GRBException {
//		br_var[id1][id2] = model.addVar(0, GRB.INFINITY, br_dual_ub[id1][id2], GRB.CONTINUOUS, "slack");
//		GRBConstr range1 = visit_ranges[id1];
//		model.chgCoeff(range1, br_var[id1][id2], 1);
//		GRBConstr range2 = visit_ranges[id2];
//		model.chgCoeff(range2, br_var[id1][id2], -1);
//	}


	public void print_Solution() throws GRBException {
		for(int i = 0; i < route_index.size(); i++) {
			int ri = route_index.get(i);
			GRBVar var = column_vars.get( r2p.get(ri));
			if (var.get(GRB.DoubleAttr.X) > 0){
				System.out.println("Solution" + pool.column_pool.get(r2p.get(ri)));
			}
		}
	}

	public void set_value() throws GRBException {
		active_set.clear();
		active_value.clear();
		for(int i = 0; i < route_index.size(); i++){
			int ri = route_index.get(i);
			GRBVar var = column_vars.get(r2p.get(ri));
			double v = var.get(GRB.DoubleAttr.X);
			if(v < -0.1){
				System.out.println("value shold be nonegative");
				System.exit(0);
				non_negative = false;
			}
			if(v > 0.0000000001){
				active_value.add(v);
				active_set.add(ri);
			}
		}
		for(int i = 0; i < data.n; i++){
			inverter_map[i] = 0;
		}
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				arc_map[i][j] = 0;
			}
		}
		for(int i = 0; i < active_set.size(); i++){
			int id = active_set.get(i);
			double v = active_value.get(i);
			ArrayList<Integer> column = pool.get_column(id);
			int root = column.get(1);
			int size = column.get(0);
			inverter_map[root] += v;
			for(int j = 1; j <= size; j++){
				int id1 = column.get(j);
				int id2 = data.n;
				if(column.get(size + j) >= 0)
					id2 = column.get(column.get(size + j));
				arc_map[id1][id2] += v;
			}
		}
//		is_all_zero = true;
//		pos_tsr = false;
//		if(tsr_var != null && tsr_var.get(GRB.DoubleAttr.X) > 1e-3){
//			is_all_zero = false;
//			pos_tsr = true;
//		}
//		for(int i = 0; i < data.n + 1; i++){
//			for(int j = 0; j < data.n + 1; j++){
//				pos_br[i][j] = false;
//				if(br_var[i][j] != null && br_var[i][j].get(GRB.DoubleAttr.X) > 1e-3){
//					is_all_zero = false;
//					pos_br[i][j] = true;
//				}
//			}
//		}
//		for(int i = 1; i < data.n + 1; i++){
//			pos_mu[i] = false;
//			if(mu_slacks[i] != null && mu_slacks[i].get(GRB.DoubleAttr.X) > 1e-3){
//				is_all_zero = false;
//				pos_mu[i] = true;
//			}
//		}
//		if(is_all_zero == false){
//			//System.out.println("debug");
//			non_impr ++;
//			if(non_impr % 3 == 0){
//				br_step *= 2;
//				mu_step *= 2;
//			}
//		}
//		else{
//			non_impr = 0;
//		}
	}



	public void set_reduced_cost() throws GRBException {
		reduced_set.clear();
		for(int i = 0; i < route_index.size(); i++){
			int ri = route_index.get(i);
			double v = column_vars.get(r2p.get(ri)).get(GRB.DoubleAttr.RC);
			if(v <= 0.000000001){
				reduced_set.add(ri);
			}
		}
	}




	public void set_useful() {    // 保留当前LP下有效的cut
		useful_cc.clear();
		for(int i = 0; i < cap_index.size(); i++){
			int index = cap_index.get(i);
			ArrayList<Integer> cut = cut_pool.cut_pool.get(index);
			int right = cut_pool.right.get(index);
			double left = 0.0;
			for(int j = 0; j < data.n + 1; j++){
				if(cut.contains(j) == false){
					for(int k = 0; k < cut.size(); k++){
						left += arc_map[cut.get(k)][j];
					}
				}
			}
			//System.out.println("cap " + i + " : " + left + " " + right);
			if(left > right - 1e-3){
				useful_cc.add(index);
			}
		}
		useful_sr.clear();
		int[][] col_map = new int[active_set.size()][data.n];
		for(int i = 0; i < active_set.size(); i++){
			ArrayList<Integer> column = pool.get_column(active_set.get(i));
			for(int j = 1; j <= column.get(0); j++){
				col_map[i][column.get(j)] ++;
			}
		}
		for(int i = 0; i < sr_index.size(); i++){
			ArrayList<Integer> cut = sr_cuts.get(i);
			double left = 0;
			for(int j = 0; j < active_set.size(); j++){
				int count = 0;
				for(int k = 0; k < cut.size(); k++){
					count += col_map[j][cut.get(k)];
				}
				left += Help.floor(count / 2.0) * active_value.get(j);
			}
			//System.out.println("sr " + i + " : " + left + " ");
			if(left > 1 - 1e-3){
				useful_sr.add(i);
			}
		}
	}

	public void get_columns(ArrayList<ArrayList<Integer>> columns) throws GRBException {
		for(int i = 0; i < route_index.size(); i++){
			int id = route_index.get(i);
			GRBVar var = column_vars.get(r2p.get(id));
			if (var.get(GRB.DoubleAttr.UB) < 1e-1)
				continue;
//			double test = var.get(GRB.DoubleAttr.RC);
//			if (var.get(GRB.DoubleAttr.RC) > 5)
//				continue;
			if (var.get(GRB.DoubleAttr.Obj) > 1e5)
				continue;
//			ArrayList<Integer> Column = pool.column_pool.get(id);
//			int size = Column.get(0);
//			for(int j = 1; j <= size; j++){
//				int id1 = Column.get(j);
//				int id2 = data.n;
//				if(Column.get(j + Column.get(0)) >= 0)
//					id2 = Column.get(Column.get(j + Column.get(0)));
//				if (id1 == 12 && id2 == 16){
//					double ub = var.get(GRB.DoubleAttr.UB);
//					double RC = var.get(GRB.DoubleAttr.RC);
//					double cof = var.get(GRB.DoubleAttr.Obj);
//					double active = var.get(GRB.DoubleAttr.X);
//					int a = 0;
//				}
//			}
			columns.add((ArrayList<Integer>) pool.column_pool.get(id).clone());
		}
	}




	public boolean solve() throws GRBException {
		model.update();
		//System.out.println("start lp solve");
		model.optimize();
		//System.out.println("end lp solve");
		int status = model.get(GRB.IntAttr.Status);
		 if (status == GRB.Status.OPTIMAL){
			cost = model.get(GRB.DoubleAttr.ObjVal);
//			System.out.println("model feasible");
			return true;
		}
		return false;
	}


	public void clear() {
		//common data
		node = null;
		pool.clear();
		//route information
		if(route_index != null){
			route_index.clear();
			route_index = null;
		}
		if(route_hashset != null){
			route_hashset.clear();
			route_hashset = null;
		}
		//lp solution information
		if(active_value != null){
			active_value.clear();
			active_value = null;
		}
		if(active_set != null){
			active_set.clear();
			active_set = null;
		}
		if(reduced_set != null){
			reduced_set.clear();
		}
		inverter_map = null;
		arc_map = null;
		cost = 1e10;
		//cplex model
		if(model != null){
			model.dispose();
			model = null;
		}
		column_vars.clear();
		visit_ranges = null;
		root_range_LB = null;
		root_range_UB = null;
		cap_ranges.clear();
		sr_ranges.clear();
		//matrix mapping information
		if(r2p != null){
			r2p.clear();
			r2p = null;
		}
		//route mapping information
		if(ij2ri != null){
			ij2ri.clear();
			ij2ri = null;
		}
		//dual information
		mu = null;

		if(useful_cc != null)
			useful_cc.clear();
		if(useful_sr != null)
			useful_sr.clear();
	}

}
