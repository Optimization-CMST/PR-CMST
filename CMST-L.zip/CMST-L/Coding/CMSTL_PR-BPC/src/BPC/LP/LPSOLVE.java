package BPC.LP;

import BPC.JC.HJC;
import BPC.JC.JC;
import Common.Data;
import Helper.Help;
import com.gurobi.gurobi.GRBException;

import java.util.ArrayList;

public class LPSOLVE {

	public Data data;
	public boolean keep;
	public long[] keep_C;
	public boolean is_cut_added = true;
	
	public LPSOLVE(Data d){
		data = d;
		keep = false;
		keep_C = new long[4];
	}

	public boolean solve(RMP lp, boolean is_tabu, long[] CX, double ub) throws GRBException {
		if(lp.solve() == false)
			return false;
		lp.set_dual();
		lp.set_value();
		System.out.println("initial lp:" + lp.cost);
		System.out.println("negative sr cuts" + lp.neg_index.size());
		//----------- pricing-----------
		JC gc = new JC(data); //双向labeling
		HJC hgc = new HJC(data);

//		Tabu3 tabu = new Tabu3(data);
		double t1 = System.nanoTime();
//		if(is_tabu)
//			tabu.solve(lp);
//		lp.set_dual(true);
		while(true){
//			double final_t1 = System.nanoTime();
//			tabu.solve(lp, 20, 10);
//			double final_t2 = System.nanoTime();
//			if(data.is_root == true){
//				data.root_tabu_time += final_t2 - final_t1;
//			}
//			data.total_tabu_time += final_t2 - final_t1;
			ArrayList<Integer> index = new ArrayList<Integer>();
			ArrayList<ArrayList<Integer>> columns = new ArrayList<ArrayList<Integer>>();
			gc.fb_bb_elimination();
			ArrayList<Double> reduced_cost = hgc.solve(lp, -1e-3, CX, columns);  // heuristic pricing
//			ArrayList<Double> reduced_cost = gc.solve(lp, -1e-3, CX, columns, true);  // heuristic pricing
			for(int i = 0; i < columns.size(); i++){
				ArrayList<Integer> column = columns.get(i);
				double rc = reduced_cost.get(i);
				if(column.size() > 0)
					check_reduced_cost(lp, column, rc);
				//debug the reduced cost
				if(rc < -1e-3 && lp.pool.column2i(column) == -1){
					index.add(lp.pool.add_column(column));
				}
			}
			if(index.size() <= 0){
				columns.clear();
				reduced_cost.clear();
				columns = new ArrayList<ArrayList<Integer>>();
				reduced_cost = gc.solve(lp, -1e-3, CX, columns, false);
				if (!gc.is_cut_added)
					is_cut_added = false;
//				reduced_cost = fgc.solve(lp, -1e-3, CX, columns, false);
				for(int i = 0; i < columns.size(); i++){
					ArrayList<Integer> column = columns.get(i);
					double rc = reduced_cost.get(i);
					if(column.size() > 0)
						check_reduced_cost(lp, column, rc);
					//debug the reduced cost
					if(rc < -1e-3 && lp.pool.column2i(column) == -1){
						index.add(lp.pool.add_column(column));
					}
				}
			}
			if(index.size() <= 0){
				break;
			}
			lp.add_col(index);
			lp.solve();
			lp.set_dual();
			lp.set_value();
			if(keep == false && gc.keep == true){
				for(int i = 0; i < 4; i++)
					keep_C[i] = gc.keep_C[i];
				keep = true;
			}
			if(data.time_out())
				break;
			System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~dp: " + index.size() + " " + lp.cost );
		}
		System.out.println("*********************************************************************************************************************************optimal: " + lp.cost);
		//System.out.println("reduced********************************************************************");
		//lp.reduce();
		//lp.set_value();
		/*
		for(int i = 0; i < lp.active_set.size(); i++){
			ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
			
			boolean mutiple = false;
			boolean[] visit = new boolean[data.tot];
			for(int j = 1; j <= column.get(0); j++){
				if(visit[column.get(j)]){
					mutiple = true;
					break;
				}
				visit[column.get(j)] = true;
			}
			if(mutiple == false)
				continue;
			System.out.println(Help.col2str2(column) + " : " + lp.active_value.get(i) + " : " + Help.is_one_arc(column));
		}
		*/
		double t2 = System.nanoTime();
		System.out.println("lp time: " + (t2 - t1) / 1e9);
		return true;
	}
	
	//check the reduced cost of a column
	public void check_reduced_cost(RMP lp, ArrayList<Integer> column, double target){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		if(Math.abs(rc - target) > 1e-3){
			System.out.println("dp reduced cost error: " + rc + " " + target);
			System.out.println("cost " + cost + " profit " + dual_profit);
			System.out.println(Help.col2str2(column));
			System.out.println("mu:");
			for(int i = 1; i <= column.get(0); i++){
				System.out.print(column.get(i) + "(" + lp.mu[column.get(i)] + ") ");
			}
			System.out.println("mu[0]: " + lp.mu[0]);
			System.out.println();
			for(int i = 0; i < lp.sr_cuts.size(); i++){
				ArrayList<Integer> cut = lp.sr_cuts.get(i);
				for(int j = 0; j < cut.size(); j++){
					System.out.print(cut.get(j) + " ");
				}
				System.out.println(": " + lp.sr_dual.get(i));
			}
			for(int i = 1; i <= column.get(0); i++){
				int id1 = column.get(i);
				int id2 = data.n;
				if(column.get(i + column.get(0)) >= 0)
					id2 = column.get(column.get(i + column.get(0)));
				System.out.println(id1 + " " + id2 + " " + lp.dual_arc[id1][id2]);
			}
			System.exit(0);
		}
	}
}
