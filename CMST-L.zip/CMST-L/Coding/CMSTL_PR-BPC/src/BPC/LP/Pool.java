package BPC.LP;

import Common.Data;
import Helper.*;

import java.util.ArrayList;
import java.util.HashMap;

public class Pool {

	public Data data;
	//----------column pool-----------------------------------
	public ArrayList<ArrayList<Integer>>  column_pool;
	public ArrayList<Double> column_cost;
	public HashMap<ArrayList<Integer>, Integer> column_check_map;
	
	public Pool(Data d, ArrayList<ArrayList<Integer>> column_set){
		data = d;
		column_pool = new ArrayList<ArrayList<Integer>>();
		column_cost = new ArrayList<Double>();
		column_check_map = new HashMap<ArrayList<Integer>, Integer>();
		for(int i = 0;i < column_set.size(); i++){
			add_column(column_set.get(i));
		}
	}
	
	public void clear(){
		column_pool.clear();
		column_pool = null;
		column_cost.clear();
		column_cost = null;
		column_check_map.clear();
		column_check_map = null;
	}
	
	
	public double get_column_cost(int id){
		return column_cost.get(id);
	}


	public ArrayList<Integer> get_column(int id){
		return column_pool.get(id);
	}
	
	public int add_column(ArrayList<Integer> column){
		column_pool.add(column);
		column_cost.add(Help.get_column_cost(data, column));
		column_check_map.put(column,  column_pool.size() - 1);
		return column_pool.size() - 1;
	}
	
	public int column2i (ArrayList<Integer> column){
		int rid = -1;
		if(column_check_map.containsKey(column) == true){
			rid = column_check_map.get(column);
		}
		return rid;
	}
	
}
