package BPC.SearchTree;

import Common.Data;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

//representation of a column a
//a[0]: the size of the tree
//a[1]-a[a[0]]: the vertex ids, organized according to the vist order of a depth first search with increasing order of each level
//a[a[0] + 1]- a[2a[0]]:  pointer to the father
//for a tree
//           1
//        3     5
//     4    6      7
//store order: 1 3 4 6 5 7 
public class Node implements Comparable{
	public boolean is_cut_add = false;
	//basic information
	public int fid = -1;
	public int count = -1;
	public double sudo_cost;
	public Data data;
	public int depth;
	public ArrayList<ArrayList<Integer>> column_set; //pointed tree, -1 is the root, -2 is nun
	public int klb; //tree number lower bound
	public int kub; 
	public int[][] feasible_arc; //feasible_arc[i][j] = 0, the arc (i,j) on slot s is feasible. -1 infeasible, 1 must travel
	public ArrayList<ArrayList<Integer>> sr_cuts;
	public ArrayList<Integer> cc_index;
	public double tsr = 30;
	//ss start
	public long[] C;
	public long[] initial_C;
	public boolean potential_optimal = false;
	public Node(){
	}
	
	public Node(Data d){
		//basic information
		sudo_cost = 1e10;
		data = d;
		depth = 0;
		column_set = new ArrayList<ArrayList<Integer>>();
		klb = 0;
		kub = data.n;
		feasible_arc = new int[data.n + 1][data.n + 1];
		sr_cuts = new ArrayList<ArrayList<Integer>>();
		cc_index = new ArrayList<Integer>();
		C = new long[4];
		initial_C = new long[4];
		tsr = 30;
	}
	
	public Node(Data d, ArrayList<ArrayList<Integer>> columnset){
		//basic information
		sudo_cost = 1e10;
		data = d;
		depth = 0;
		column_set = columnset;
		klb = 0;
		kub = data.n;
		feasible_arc = new int[data.n + 1][data.n + 1];
		sr_cuts = new ArrayList<ArrayList<Integer>>();
		cc_index = new ArrayList<Integer>();
		C = new long[4];
		initial_C = new long[4];
		tsr = 30;
	}
	
	public Node duplicate(){
		//basic information
		Node new_node = new Node();
		new_node.sudo_cost = sudo_cost;
		new_node.data = data;
		new_node.depth = depth;
		new_node.column_set = null;
		new_node.klb = klb;
		new_node.kub = kub;
		new_node.feasible_arc = new int[data.n + 1][data.n + 1];
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				new_node.feasible_arc[i][j] = feasible_arc[i][j];
			}
		}
		new_node.sr_cuts = null;
		new_node.cc_index = null;
		new_node.C = new long[4];
		new_node.initial_C = new long[4];
		for(int i = 0; i < 4; i++) {
			new_node.C[i] = C[i];
			new_node.initial_C[i] = initial_C[i];
		}
		new_node.tsr = tsr;
		return new_node;
	}

	public void clear(){
		//basic information
		if(column_set != null)
			column_set.clear();
		feasible_arc = null;
		if(sr_cuts != null)
			sr_cuts.clear();
		if(cc_index != null)
			cc_index.clear();
	}
	
	public int compareTo(Object o){    // best first
		 Node node = (Node) o;
		 if(sudo_cost > node.sudo_cost)
			 return 1;
		 else if(sudo_cost == node.sudo_cost)
			 return 0;
		 else 
			 return -1;
	}
	
	public void export(int id) throws IOException{
		String out_path = "node_" + id + ".txt";
		BufferedWriter out=new BufferedWriter(new FileWriter(out_path));
		out.write("" + sudo_cost);
		out.newLine();
		out.write("" + depth);
		out.newLine();
		out.write("" + column_set.size());
		out.newLine();
		for(int i = 0; i < column_set.size(); i++){
			out.write(column_set.get(i).size() + " ");
			for(int j = 0; j < column_set.get(i).size(); j++){
				out.write(column_set.get(i).get(j) + " ");
			}
			out.newLine();
		}
		out.write(klb + " " + kub);
		out.newLine();
		for(int i = 0; i < data.n; i++){
			for(int j = 0; j < data.n; j++){
				out.write(feasible_arc[i][j] + " ");
			}
			out.newLine();
		}
		out.write(sr_cuts.size() + "");
		out.newLine();
		for(int i = 0; i < sr_cuts.size(); i++){
			for(int j = 0; j < 3; j++){
				out.write(sr_cuts.get(i).get(j) + " ");
			}
			out.newLine();
		}
		out.write(cc_index.size() + "");
		out.newLine();
		for(int i = 0; i < cc_index.size(); i++){
			out.write(cc_index.get(i) + " ");
		}
		out.newLine();
		out.write(tsr + "");
		out.newLine();
		out.close();
	}
	
	public void _import(int id) throws FileNotFoundException{
		String file = "node_" + id + ".txt";
		Scanner cin = new Scanner(new BufferedReader(new FileReader(file)));
		sudo_cost = cin.nextDouble();
		depth = cin.nextInt();
		int n = cin.nextInt();
		for(int i = 0; i < n; i++){
			ArrayList<Integer> column = new ArrayList<Integer>();
			int m = cin.nextInt();
			for(int j = 0; j < m; j++){
				column.add(cin.nextInt());
			}
			column_set.add(column);
		}
		klb = cin.nextInt();
		kub = cin.nextInt();
		for(int i = 0; i < data.n + 1; i++){
			for(int j = 0; j < data.n + 1; j++){
				feasible_arc[i][j] = cin.nextInt();
			}
		}
		n = cin.nextInt();
		for(int i = 0; i < n; i++){
			ArrayList<Integer> cut = new ArrayList<Integer>();
			for(int j = 0; j < 3; j++)
				cut.add(cin.nextInt());
			sr_cuts.add(cut);
		}
		n = cin.nextInt();
		for(int i = 0; i < n; i++){
			cc_index.add(cin.nextInt());
		}
		tsr = cin.nextDouble();
		cin.close();
	}
}
