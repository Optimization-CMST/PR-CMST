package BPC.SearchTree;

import BPC.Branch.*;
import BPC.Cut.CutPool;
import BPC.LP.PC;
import BPC.LP.RMP;
import Common.Data;
import Helper.*;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;


public class Tree {

	public Data data;
	public double best_value;
	public ArrayList<ArrayList<Integer>> best_columns;
	public boolean break_sign = false;
	public boolean slack_sign = false;
	public int slack_num = 0;
	public double best_LB;

	public double Heuristic_UB = 1e8;
	public double Heuristic_Time = 0;

	public Tree(Data d){
		data = d;
	};

	public void solve(ArrayList<ArrayList<Integer>> init_routes, ArrayList<ArrayList<Integer>> ubs) throws IOException, GRBException {
		//ArrayList<ArrayList<Integer>> optimal = read_optimal_solution("optimal.txt");
		//double optimal_cost = Help.get_solution_cost(data, optimal);
		long t1 = System.nanoTime();
		DecimalFormat df  = new DecimalFormat("0.00");
		best_value = 1e8;
		best_columns = new ArrayList<ArrayList<Integer>>();
		if(ubs != null){
			best_value = Help.get_solution_cost(data, ubs);
			data.ip_cost = best_value;
			for(int i = 0; i < ubs.size(); i++){
				best_columns.add(ubs.get(i));
			}
		}
		Node init_node = new Node(data, init_routes);
		init_node.potential_optimal = true;
		init_node.sudo_cost = 0.0;
		// arc elimination
		for (int i = 0; i < data.n; i++)
			for (int j = 0; j < data.n; j++){
				if (i == j) continue;
				if (data.d[i][j] > data.d[i][data.n]) {
					init_node.feasible_arc[i][j] = -1;
				}
			}
		PriorityQueue<Node> queue = new PriorityQueue<Node>();
		queue.add(init_node);
		int node_size = 0;
		CutPool cut_pool = new CutPool();
		long[] C = new long[4];
		while(queue.isEmpty() == false){
			double sudo_cost = -1;
			Node node = queue.poll();
			System.out.println("Current LB " + node.sudo_cost);
			System.out.println("Current UB" + best_value);
			best_LB = node.sudo_cost;
			if (data.turn_out()){
				break_sign = true;
				break;
			}
			//debug node
			//node.export(node_size);
			//cut_pool.export();
			sudo_cost = node.sudo_cost;
			//------------solve the node-------------------------------
			if(node.sudo_cost > best_value - 1e-5){
				node.clear();
				continue;
			}
			node_size++;
			//copy the node C
			for(int i = 0; i < 4; i++) {
				node.C[i] = C[i];
				node.initial_C[i] = node.C[i];
			}
			//-------------new the structure---------------------------
			long t10 = System.nanoTime();
			RMP lp = new RMP(data);
//			BCV bcv = new BCV(data);
			BCA2 bca2 = new BCA2(data);
			BCA bca = new BCA(data);
			PC pc = new PC(data);
			//-------------end------------------------------------------
			lp.construct(node, cut_pool);
			long t5 = System.nanoTime();
			//data.first_time = 0;
			System.out.println("set size: " + set_size(node.C[0], node.C[1], node.C[2], node.C[3]));
			System.out.println(node.fid + "----" + node.count);
			pc.solve(lp, best_value);
			if (data.time_out()){
				break_sign = true;
				break;
			}
			if (lp.solve() == false){
				slack_num++;
				slack_sign = true;
				lp.clear();
				node.clear();
				data.node_num = node_size;
				continue;
			}
			if (data.is_root && lp.is_feasible() == false){
				double h1 = System.nanoTime();
				RMP IP = new RMP(data);
				IP.construct_IP(lp.pool.column_pool, cut_pool);
				boolean  is_solved  =  IP.solve();
				double h2 = System.nanoTime();
				if (is_solved == true){
					Heuristic_Time = (h2 - h1)/1e9;
					Heuristic_UB = IP.cost;
					best_value = IP.cost;
				}
			}
			data.is_root = false;
			long t6 = System.nanoTime();
			//save the node_C
			if(node.depth == 0){
				for(int i = 0; i < 4; i++)
					C[i] = pc.keep_C[i];
			}
			double cur_cost = lp.cost;
			if(lp.cost > best_value - 1e-5){
				lp.clear();
				node.clear();
				//--------clear the structure----------------------------
				lp = null;
				bca = null;
				pc = null;
				double t = (System.nanoTime() - data.start_time) / 1e9;
				System.out.println(node_size + "\t" + df.format(cur_cost)
						+  "\t" + best_value + "\t" + queue.size()
						+ "\t" + sudo_cost + "\t" + t);;
				//---------------------------------------------------------
				data.node_num = node_size;
				//---------------------------------------------------------
				continue;
			}
			//---branch on the current node, 3 branch decisions--------
			String log_feasible = "";
			String bstr = "";
			if(lp.is_feasible() == true && lp.cost < best_value){
				best_columns.clear();
				for(int i = 0; i < lp.active_set.size(); i++){
					ArrayList<Integer> column = lp.pool.get_column(lp.active_set.get(i));
					best_columns.add((ArrayList<Integer>) column.clone());
				}
				best_value = lp.cost;
				data.ip_cost = best_value;
				log_feasible = "true";
				node.clear();
			}
			else{
//				boolean ret = bcv.branch(lp);
//				if(ret == true){
//					if(bcv.left_node != null){
//						Check.check_node(data, bcv.left_node);
//						boolean cret = Check.check_node_solvability(data, bcv.left_node, cut_pool);
//						if(cret == false){
//							System.out.println("left tree branch infeasible");
//							System.exit(0);
//						}
//						bcv.left_node.fid = node_size;
//						bcv.left_node.count = 0;
//						queue.add(bcv.left_node);
//					}
//					if(bcv.right_node != null){
//						Check.check_node(data, bcv.right_node);
//						boolean cret = Check.check_node_solvability(data, bcv.right_node, cut_pool);
//						if(cret == false){
//							System.out.println("right vehicle branch infeasible");
//							System.exit(0);
//						}
//						bcv.right_node.fid = node_size;
//						bcv.right_node.count = 1;
//						queue.add(bcv.right_node);
//					}
//					log_feasible = "false";
//					bstr = "bcv\t" + df.format(bcv.fv);
//				}
				 {
				  boolean	ret = bca2.branch(lp);
					//boolean is_left = bca_decision(optimal, bca2.id1, bca2.id2, bca2.id3, bca2.id4);
					if (ret == true) {
						if (bca2.left_node != null) {
							Check.check_node(data, bca2.left_node);
							//if(is_left && father_optimal){
							//bca2.left_node.potential_optimal = true;
							//}
							//else{
							//bca2.left_node.potential_optimal = false;
							//}
							boolean cret = Check.check_node_solvability(data, bca2.left_node, cut_pool);
							if (cret == false) {
								System.out.println("left arc branch infeasible");
								System.exit(0);
							}
							bca2.left_node.fid = node_size;
							bca2.left_node.count = 0;
							queue.add(bca2.left_node);
						}
						if (bca2.right_node != null) {
							Check.check_node(data, bca2.right_node);
							//if(is_left == false && father_optimal){
							//bca2.right_node.potential_optimal = true;
							//}
							//else{
							//bca2.right_node.potential_optimal = false;
							//}
							boolean cret = Check.check_node_solvability(data, bca2.right_node, cut_pool);
							if (cret == false) {
								System.out.println("right arc branch infeasible");
								System.exit(0);
							}
							bca2.right_node.fid = node_size;
							bca2.right_node.count = 1;
							queue.add(bca2.right_node);
						}
						//if(father_optimal && (is_left && bca2.left_node == null || is_left == false && bca2.right_node == null)){
						//System.out.println("optmial solution is prunned 2");
						//System.exit(0);
						//}
						log_feasible = "false";
						bstr = "arc2\t" + bca2.id1 + "\t" + bca2.id2 + "\t" + df.format(bca2.av) + "\t" + df.format(bca2.left_obj) + "\t" + df.format(bca2.right_obj);
					} else {
						bca.branch(lp);
						if (bca.left_node != null) {
							Check.check_node(data, bca.left_node);
							queue.add(bca.left_node);
						}
						if (bca.right_node != null) {
							Check.check_node(data, bca.right_node);
							queue.add(bca.right_node);
						}
						bstr = "arc\t" + bca.id1 + "\t" + bca.id2 + "\t" + df.format(bca.av);
						log_feasible = "false";
					}
				}
			}
			double t11 = System.nanoTime();
			//---print the information----------------------------------
			double gap = 1 - cur_cost / best_value;
			String gap_str = df.format((100 * gap)) + "%";
			double t = (System.nanoTime() - data.start_time) / 1e9;
			System.out.println(node_size + "\t" + df.format(cur_cost)
					+ "\t" + log_feasible +  "\t" + best_value + "\t" + gap_str
					+ "\t" + queue.size()
					+ "\t" + bstr + "\t" + sudo_cost + "\t" + t);;
			//--------clear the structure----------------------------
			lp.clear();
			lp = null;;
			bca = null;
			pc = null;
			//---------------------------------------------------------
			//System.exit(0);
			data.node_num = node_size;
		}
		data.ip_time = System.nanoTime() - data.start_time;
	}

	public ArrayList<ArrayList<Integer>> read_optimal_solution(String file) throws IOException{
		Scanner cin = new Scanner(new BufferedReader(new FileReader(file)));
		ArrayList<ArrayList<Integer>> column_set = new ArrayList<ArrayList<Integer>>();
		while(cin.hasNextLine()){
			String line = cin.nextLine();
			String[] split = line.split(" ");
			ArrayList<Integer> column = new ArrayList<Integer>();
			for(int i = 0; i < split.length; i++){
				column.add(Integer.parseInt(split[i]));
			}
			column_set.add(column);
		}
		return column_set;
	}

	//true left, false right
	public boolean bcn_decision(ArrayList<ArrayList<Integer>> optimal, int id){
		for(int i = 0; i < optimal.size(); i++){
			if(optimal.get(i).get(1) == id)
				return false;
		}
		return true;
	}

	public boolean bca_decision(ArrayList<ArrayList<Integer>> optimal, int id1, int id2){
		for(int i = 0; i < optimal.size(); i++){
			ArrayList<Integer> column = optimal.get(i);
			int size = column.get(0);
			for(int j = 2; j <= size; j++){
				int a1 = column.get(j);
				int a2 = column.get(column.get(size + j));
				if(a1 == id1 && a2 == id2)
					return false;
			}
		}
		return true;
	}

	public int set_size(long C1, long C2, long C3, long C4){
		int count = 0;
		for(int i = 0; i < data.n; i++){
			if(i < 64){
				if((data.mask[i] & C1) != 0x00)
					count++;
			}
			else if(i < 128){
				if((data.mask[i] & C2) != 0x00)
					count++;
			}
			else if(i < 192){
				if((data.mask[i] & C3) != 0x00)
					count++;
			}
			else{
				if((data.mask[i] & C4) != 0x00)
					count++;
			}
		}
		return count;
	}
}
