package Heuristic;

import Common.*;
import BPC.LP.*;
import java.util.*;
import Helper.*;
import com.gurobi.gurobi.GRB;
import com.gurobi.gurobi.GRBException;

public class Tabu3 {
	
	public Data data;
	public ArrayList<Integer> index_set;
	
	public Tabu3(){
	}
	
	public Tabu3(Data d){
		data = d;
		index_set = new ArrayList<Integer>();
	}
	
	public double get_sr_dual(RMP lp, int[] count, int in, int out){
		if(lp.is_sr_add == false)
			return 0.0;
		double value = 0.0;
		if(in != -1){
			for(int i = 0; i < lp.node_index.get(in).size(); i++){
				int index = lp.node_index.get(in).get(i);
				count[index]++;
				if(count[index] % 2 == 0)
					value += lp.sr_dual.get(lp.neg_index.get(index));
			}
		}
		if(out != -1){
			for(int i = 0; i < lp.node_index.get(out).size(); i++){
				int index = lp.node_index.get(out).get(i);
				if(count[index] > 0 && count[index] % 2 == 0)
					value -= lp.sr_dual.get(lp.neg_index.get(index));
			}
		}
		if(in != -1){
			for(int i = 0; i < lp.node_index.get(in).size(); i++){
				int index = lp.node_index.get(in).get(i);
				count[index]--;
			}
		}
		return value;
	}
	
	public double update_sr_dual(RMP lp, int[] count, int in, int out){
		if(lp.is_sr_add == false)
			return 0.0;
		double value = 0.0;
		if(in != -1){
			for(int i = 0; i < lp.node_index.get(in).size(); i++){
				int index = lp.node_index.get(in).get(i);
				count[index]++;
				if(count[index] % 2 == 0)
					value += lp.sr_dual.get(lp.neg_index.get(index));
			}
		}
		if(out != -1){
			for(int i = 0; i < lp.node_index.get(out).size(); i++){
				int index = lp.node_index.get(out).get(i);
				count[index]--;
				if(count[index] < 0){
					System.out.println("debug");
				}
				if(count[index] % 2 == 1)
					value -= lp.sr_dual.get(lp.neg_index.get(index));
			}
		}
		return value;
	}
	
	public ArrayList<Integer> get_column(int size, int[] tree){
		ArrayList<Integer> column = new ArrayList<Integer>();
		ArrayList<Integer> place = new ArrayList<Integer>();
		Stack<Integer> stack = new Stack<Integer>();
		Stack<Integer> father_stack = new Stack<Integer>();
		for(int i = 0; i < data.n; i++){
			if(tree[i] == data.n){
				stack.add(i);
				father_stack.add(-1);
				break;
			}
		}
		column.add(size);
		while(stack.isEmpty() == false){
			int x = stack.pop();
			int father = father_stack.pop();
			column.add(x);
			place.add(father);
			ArrayList<Integer> ids = new ArrayList<Integer>();
			for(int i = 0; i < tree.length; i++){
				if(tree[i] == x){
					int insert = 0;
					while(insert < ids.size() && i < ids.get(insert))
						insert++;
					ids.add(insert, i);
				}
			}
			for(int i = 0; i < ids.size(); i++){
				stack.add(ids.get(i));
				father_stack.add(column.size() - 1);
			}
		}
		for(int i = 0; i < place.size(); i++){
			column.add(place.get(i));
		}
		return column;
	}
	
	public void tabu(RMP lp, ArrayList<Integer> old_column, int max_iter, int tabu_tenure, double thresh_hold, int ts_size){
		int[] opt_list = new int[data.n + 1];
		Arrays.fill(opt_list, -10000000);
		int iter = 0;
		//get the initial column
		ArrayList<Integer> S = new ArrayList<Integer>();
		for(int i = 1; i <= old_column.get(0); i++){
			S.add(old_column.get(i));
		}
		int[] S_count = new int[lp.neg_index.size()];
		double S_sr = 0.0;
		for(int i = 0; i < lp.neg_index.size(); i++){
			int place = lp.neg_index.get(i);
			ArrayList<Integer> cut = lp.sr_cuts.get(place);
			double dual = lp.sr_dual.get(place);
			for(int j = 0; j < cut.size(); j++){
				if(S.contains(cut.get(j)))
					S_count[i]++;                              // this structure stores the number of vertex in sr cuts in this column
			}
			S_sr += Math.floor(S_count[i] / 2.0) * dual;       // S_sr : the sum value in subset row cuts on this column
		}
		int[] S_tree = new int[data.n + 1];
		Arrays.fill(S_tree, -1);
		S_tree[data.n] = -1;
		S_tree[old_column.get(1)] = data.n;
		for(int i = 2; i <= old_column.get(0); i++){
			S_tree[old_column.get(i)] = old_column.get(old_column.get(old_column.get(0) + i));
		}
		int[] S_q = new int[data.n + 1];                      // this structure store the number of capacity of each vertex
		for(int i = 0; i < S.size(); i++){
			int start = S.get(i);
			while(start != -1){
				S_q[start] ++;
				start = S_tree[start];
			}
		}
		double ub_cost = -S_sr - lp.mu[data.n];            // this value stores sum of dual values
		for(int i = 0; i < S.size(); i++){
			int id = S.get(i);
			ub_cost += data.d[id][S_tree[id]] - lp.dual_arc[id][S_tree[id]] - lp.mu[id];
		}
		double best_cost = ub_cost;
		check_state(lp, S, S_tree, S_q, S_count, ub_cost);
		//start the iteration 
		while(iter < max_iter){
			//explore the negbhorhood
			double min_delta = 1e10;
			int type = -1;
			int opt_id1 = -1;
			int opt_id2 = -1;
			//remove neighborhood
			if(S.size() > 1){
				for(int i = 0; i < S.size(); i++){
					int id = S.get(i);
					if(S_q[id] > 1)
						continue;
					double delta = -data.d[id][S_tree[id]] + lp.dual_arc[id][S_tree[id]] + lp.mu[id] 
							- get_sr_dual(lp, S_count, -1, id);
					int start= S_tree[id];
					while(S_tree[start] != -1){
						delta += data.d[start][S_tree[start]] - data.d[start][S_tree[start]];
						start = S_tree[start];
					}
					if(ub_cost + delta < best_cost && iter - opt_list[id] < tabu_tenure)
						continue;
					if(delta < min_delta){
						min_delta = delta;
						type = 1;
						opt_id1 = id;
						opt_id2 = -1;
					}
				}
			}
			//insertion neighborhood
			if(S.size() < data.Q){
				for(int i = 0; i < data.n; i++){
					if(S_tree[i] == -1){
						for(int j = 0; j < S.size(); j++){
							int id = S.get(j);
							if(lp.node.feasible_arc[i][id] == -1)
								continue;
							double delta = data.d[i][id] - lp.dual_arc[i][id] - lp.mu[i]
								- get_sr_dual(lp, S_count, i, -1);
							int start= id;
							while(S_tree[start] != -1){
								delta += data.d[start][S_tree[start]] - data.d[start][S_tree[start]];
								start = S_tree[start];
							}
							if(ub_cost + delta > best_cost && iter - opt_list[i] < tabu_tenure)
								continue;
							if(delta < min_delta){
								min_delta = delta;
								type = 2;
								opt_id1 = i;
								opt_id2 = id;
							}
						}
					}
				}
			}
			//exchange neighborhood
			for(int i = 0; i < data.n; i++){
				if(S_tree[i] == -1){
					for(int j = 0; j < S.size(); j++){
						int id = S.get(j);
						if(lp.node.feasible_arc[i][S_tree[id]] == -1)
							continue;
						double delta = data.d[i][S_tree[id]] - data.d[id][S_tree[id]]
								- lp.dual_arc[i][S_tree[id]] + lp.dual_arc[id][S_tree[id]] - lp.mu[i] + lp.mu[id]
										- get_sr_dual(lp, S_count, i, id);
						boolean feasible = true;
						for(int k = 0; k < S.size(); k++){
							int id2 = S.get(k);
							if(S_tree[id2] != id)
								continue;
							if(lp.node.feasible_arc[id2][i] == -1){
								feasible = false;
								break;
							}
							delta += data.d[id2][i] - data.d[id2][id] 
									- lp.dual_arc[id2][i] + lp.dual_arc[id2][id];
						}
						if(feasible == false)
							continue;
						if(ub_cost + delta > best_cost && iter - opt_list[i] < tabu_tenure)
							continue;
						if(delta < min_delta){
							min_delta = delta;
							type = 3;
							opt_id1 = i;
							opt_id2 = id;
						}
					}
				}
			}
			
			//update the information
			if(best_cost < ub_cost + min_delta){
				best_cost = ub_cost + min_delta;
			}
			ub_cost  += min_delta;
			if(type == 1){
				for(int i = 0; i < S.size(); i++){
					if(S.get(i) == opt_id1){
						S.remove(i);
						break;
					}
				}
				int start = opt_id1;
				while(start != -1){
					S_q[start] --;
					start = S_tree[start];
				}
				S_tree[opt_id1] = -1;
				update_sr_dual(lp, S_count, -1, opt_id1);
			}
			else if(type == 2){
				S.add(opt_id1);
				S_tree[opt_id1] = opt_id2;
				int start = opt_id1;
				while(start != -1){
					S_q[start] ++;
					start = S_tree[start];
				}
				update_sr_dual(lp, S_count, opt_id1, -1);
			}
			else if(type == 3){
				//if(opt_id1 == 18 && opt_id2 == 95){
					//System.out.println("debug");
				//}
				for(int i = 0; i < S.size(); i++){
					if(S_tree[S.get(i)] == opt_id2){
						S_tree[S.get(i)] = opt_id1;
					}
				}
				S_tree[opt_id1] = S_tree[opt_id2];
				S_tree[opt_id2] = -1;
				S_q[opt_id1] = S_q[opt_id2];
				S_q[opt_id2] = 0;
				for(int i = 0; i < S.size(); i++){
					if(S.get(i) == opt_id2){
						S.set(i, opt_id1);
						break; 
					}
				}
				update_sr_dual(lp, S_count, opt_id1, opt_id2);
			}
			else{
				System.out.println("type error");
				System.exit(0);
			}
			iter++;
			opt_list[opt_id1] = iter;
			check_state(lp, S, S_tree, S_q, S_count, ub_cost);
			if(ub_cost < thresh_hold){
				//get the column
				ArrayList<Integer> column = get_column(S.size(), S_tree);
				Check.check_column(data, lp.node, column, (column.size() - 1) / 2);
				check_reduced_cost(lp, column, ub_cost);
				if(lp.pool.column2i(column) == -1){
					//System.out.println(column);
					int index = lp.pool.add_column(column);
					index_set.add(index);
				}
			}
		}
	}
	
	//---------------public interface------------------------------------
	public boolean grasp(RMP lp, int max_iter, int tabu_tenure, double thresh_hold, int ts_size, int count) throws GRBException {
		//System.out.println("tabu: route size " + lp.reduced_set.size());
		index_set.clear();
		//--------get all the route with zero reduce cost-------------------------------------
		ArrayList<Integer> zero_routes = new ArrayList<Integer>();      // this structure stors the column whose RC = 0 (contain the current optimal solution)
		double thresh_value = 0.0;
		while(zero_routes.size() == 0){
			for(int i = 0; i < lp.route_index.size(); i++){
				double rc = lp.column_vars.get(lp.r2p.get(lp.route_index.get(i))).get(GRB.DoubleAttr.RC);
				if(rc <= thresh_value){
					zero_routes.add(lp.route_index.get(i));
				}
				if(zero_routes.size() > count)
					break;
			}
			if(zero_routes.size() > count)
				break;
			thresh_value += 1e-9;
		}
		//System.out.println("zero column size: " + zero_routes.size());
		for(int i = 0; i < zero_routes.size(); i++){
			ArrayList<Integer> column = lp.pool.get_column(zero_routes.get(i));
			tabu(lp, column, max_iter, tabu_tenure, thresh_hold, ts_size);
			if(index_set.size() > ts_size)
				break;
		}
		//System.out.println(index_set.size());
		//--------check the neg_columns-------------------------------------------------------
		if(index_set.size() > 0){
			lp.add_col(index_set);
			lp.solve();
			lp.set_dual();
			return true;
		
		}
		else{
			return false;
		}
	}
	
	public boolean solve(RMP lp, int max_iter, int count) throws GRBException {
		//lp.cplex.setParam(IloCplex.IntParam.RootAlg, IloCplex.Algorithm.Primal);
		if(lp.solve() == false)
			return false;
		lp.set_dual();
		lp.set_reduced_cost();
		boolean isNotEnd = true;
		//System.out.println(lp.cost);
		while(isNotEnd){
			isNotEnd = grasp(lp, max_iter, 20, -1e-1, 200, count);
			//if(isNotEnd)
				System.out.println("tabu: " + lp.cost);
		}
		//------------------------------------------------------
		lp.set_value();
		//System.exit(0);
		return true;
	}
	
	//check the reduced cost of a column
	public void check_reduced_cost(RMP lp, ArrayList<Integer> column, double target){
		double cost = Help.get_column_cost(data, column);
		double dual_profit = lp.mu[data.n];
		for(int i = 1; i <= column.get(0); i++){
			dual_profit += lp.mu[column.get(i)];
		}
		for(int i = 1; i <= column.get(0); i++){
			int id1 = column.get(i);
			int id2 = data.n;
			if(column.get(i + column.get(0)) >= 0)
				id2 = column.get(column.get(i + column.get(0)));
			dual_profit += lp.dual_arc[id1][id2];
		}
		//check the sr profit
		if(lp.is_sr_add){
			int[] col_map = new int[data.n];
			for(int i = 1; i <= column.get(0); i++){
				col_map[column.get(i)] ++;
			}
			for(int i = 0; i < lp.neg_index.size(); i++){
				int index = lp.neg_index.get(i);
				ArrayList<Integer> cut = lp.sr_cuts.get(index);
				int count = 0;
				for(int j = 0; j < cut.size(); j++){
					count += col_map[cut.get(j)];
				}
				dual_profit += Help.floor(count / 2.0) * lp.sr_dual.get(index);
			}
		}
		double rc = cost - dual_profit;
		if(Math.abs(rc - target) > 1e-3){
			System.out.println("tabu reduced cost error: " + rc + " " + target);
			System.out.println("cost " + cost + " profit " + dual_profit);
			System.out.println(Help.col2str2(column));
			System.out.println("mu:");
			for(int i = 1; i <= column.get(0); i++){
				System.out.print(column.get(i) + "(" + lp.mu[column.get(i)] + ") ");
			}
			System.out.println("mu[0]: " + lp.mu[0]);
			System.out.println();
			for(int i = 0; i < lp.sr_cuts.size(); i++){
				ArrayList<Integer> cut = lp.sr_cuts.get(i);
				for(int j = 0; j < cut.size(); j++){
					System.out.print(cut.get(j) + " ");
				}
				System.out.println(": " + lp.sr_dual.get(i));
			}
			for(int i = 1; i <= column.get(0); i++){
				int id1 = column.get(i);
				int id2 = 0;
				if(column.get(i + column.get(0)) >= 0)
					id2 = column.get(column.get(i + column.get(0)));
				System.out.println(id1 + " " + id2 + " " + lp.dual_arc[id1][id2]);
			}
			System.exit(0);
		}
	}

    public void check_state(RMP lp, ArrayList<Integer> S, int[] S_tree, int[] S_q, int[] S_count, double ub_cost){
    	if(S_tree[data.n] != -1){
    		System.out.println("root error");
    		System.exit(0);
    	}
    	for(int i = 0; i < data.n; i++){
    		if(S.contains(i) && S_tree[i] == -1 || S.contains(i) == false && S_tree[i] != -1){
    			System.out.println(S);
    			System.out.println(i + " " + S_tree[i]);
    			System.out.println("S contain error");
    			System.exit(0);
    		}
    	}
    	for(int i = 0; i < data.n; i++){
    		if(S_tree[i] != -1 && lp.node.feasible_arc[i][S_tree[i]] == -1){
    			System.out.println("state arc error: " + i + " " + S_tree[i]);
    			System.exit(0);
    		}
    	}
    	//check connectivity
    	for(int i = 0; i < S.size(); i++){
    		int start = S.get(i);
    		while(S_tree[start] != -1){
    			start = S_tree[start];
    		}
    		if(start != data.n){
    			System.out.println("connectivity error");
    			System.exit(0);
    		}
    	}
    	int[] check_q = new int[data.n + 1];
    	for(int i = 0; i < S.size(); i++){
    		int id = S.get(i);
    		while(id != -1){
    			check_q[id] ++;
    			id = S_tree[id];
    		}
    	}
    	for(int i = 0; i < data.n + 1; i++){
    		if(check_q[i] != S_q[i]){
    			System.out.println("S_q error " + i + " " + check_q[i] + " " + S_q[i]);
    			System.exit(0);
    		}
    	}
    	//check the objective 
    	double check_cost = -lp.mu[data.n];
		for(int i = 0; i < lp.neg_index.size(); i++){
			int place = lp.neg_index.get(i);
			ArrayList<Integer> cut = lp.sr_cuts.get(place);
			double dual = lp.sr_dual.get(place);
			int t_count = 0;
			for(int j = 0; j < cut.size(); j++){
				if(S.contains(cut.get(j)))
					t_count ++;
			}
			if(t_count != S_count[i]){
				System.out.println("S_count error " + t_count + " " + S_count[i]);
				System.out.println(S);
				System.out.println(cut);
				System.exit(0);
			}
			check_cost -= Math.floor(t_count / 2.0) * dual;
		}
		for(int i = 0; i < S.size(); i++){
			int id = S.get(i);
			check_cost += data.d[id][S_tree[id]] - lp.dual_arc[id][S_tree[id]] - lp.mu[id];
		}
		if(Math.abs(check_cost - ub_cost) > 1e-1){
			System.out.println("ub_cost error " + check_cost + " " + ub_cost);
			System.exit(0);
		}
    }
}
