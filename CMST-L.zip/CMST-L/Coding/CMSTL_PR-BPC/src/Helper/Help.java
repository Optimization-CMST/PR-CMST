package Helper;

import Common.Data;

import java.util.ArrayList;

public class Help {
	
	public static double tolerance = 1e-5;
	
	public static int get_column_root(ArrayList<Integer> column){
		int size = column.get(0);
		for(int i = size + 1; i < column.size(); i++){
			if(column.get(i) == -1){
				column.get(i - size);
			}
		}
		System.exit(0);
		return -1;
	}

	public static double get_column_cost(Data data, ArrayList<Integer> column){
		int size = column.get(0);
		int[] q = new int[size];
		for(int i = 1; i <= size; i++){
			int id = i;
			while(column.get(size + id) >= 0){
				id = column.get(size + id);
				q[id - 1]++;
			}
		}
		if(q[0] != column.get(0) - 1){
			System.out.println("cost computation error");
			System.exit(0);
		}
		double cost = 0;
		for(int i = 1; i <= size; i++){
			int next = column.get(size + i);
			if(next >= 0)
				cost += data.arc_cost(column.get(i), column.get(next), q[i - 1] + 1);
			else
				cost += data.arc_cost(column.get(i), data.n, q[i - 1] + 1);
		}
		return cost;
	}
	
	public static double get_solution_cost(Data data, ArrayList<ArrayList<Integer>> columns){
		double cost = 0;
		for(int i = 0; i < columns.size(); i++){
			cost += get_column_cost(data, columns.get(i));
		}
		return cost;
	}
	
	public static String col2str(ArrayList<Integer> column){
		String str = "";
		int size = column.get(0);
		for(int i = 1; i <= size; i++){
			int index1 = column.get(i);
			int index2 = -1;
			if(column.get(size + i) >= 0){
				index2 = column.get(column.get(size + i));
			}
			str += index1 + "->" + index2 + " ";
		}
		return str;
	}
	
	public static String col2str2(ArrayList<Integer> column){
		String str = column.get(0) + " : ";
		for(int i = 1; i < column.size(); i++){
			str += column.get(i) + " ";
			if(i == column.get(0)){
				str += "| ";
			}
		}
		return str;
	}
	
	public static boolean is_one_arc(ArrayList<Integer> column){
		int size = column.get(0);
		for(int i = 2; i <= size; i++){
			int id1 = column.get(i);
			int id2_place = column.get(size + i);
			int id3_place = column.get(size + id2_place);
			if(id3_place != -1 && id1 == column.get(id3_place))
				return true;
		}
		return false;
	}
	
	public static int ceiling(double v){
		int tv=(int)v;
		if(tv == v)
			return tv;
		else 
			return tv+1;
	}
	
	public static int floor(double v){
		return (int)(v + 1e-6);
	}
	
	public static int d2i(double v){
		int iv = (int) v;
		if(iv > v - tolerance)
			return iv;
		else
			return iv + 1;
	}
	
	public static boolean is_fractional(double v){
		if( v > (int) v + tolerance && v < (int) v + 1 - tolerance)
			return true;
		else
			return false;
	}
	
	public static double frac_cost(double v){
		double line = floor(v) + 0.5;
		if(v >= line)
			return v - line;
		else
			return line - v;
	}
	
	public static boolean is_one_zero(double v){
		if(v < tolerance || v > 1- tolerance && v < 1 + tolerance)
			return true;
		else return false;
	}
	
	public static double one_zero_cost(double v){
		if(v < 0.5)
			return 0.5 - v;
		else
			return v - 0.5;
	}
	
}
