package Common;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Input {
	public static Data read_instance(String file) throws IOException{
		Scanner cin = new Scanner(new BufferedReader(new FileReader(file)));
		Data data = new Data();
		cin.next();
		data.m = cin.nextInt();
		data.c = new int[data.m];
		data.q = new int[data.m];
		cin.next();
		for(int i = 0; i < data.m; i++){
			data.q[i] = cin.nextInt();
		}
		data.Q = data.q[data.m - 1];
		cin.next();
		for(int i = 0; i < data.m; i++)
			data.c[i] = cin.nextInt();
		cin.next();
		data.n = cin.nextInt() - 1;
		int[] x = new int[data.n + 1];
		int[] y = new int[data.n + 1];
		for(int i = 0; i <= data.n; i++){
			x[i] = cin.nextInt();
			y[i] = cin.nextInt();
		}
		data.d = new double[data.n + 1][data.n + 1];
		for(int i = 0; i < data.n + 1; i++){
			for(int j = i + 1; j < data.n + 1; j++){
				data.d[i][j] = data.d[j][i] = Math.sqrt((x[i] - x[j]) * (x[i] - x[j]) + (y[i] - y[j]) * (y[i] - y[j]));
			}
		}
		cin.close();
		return data;
	}
}
