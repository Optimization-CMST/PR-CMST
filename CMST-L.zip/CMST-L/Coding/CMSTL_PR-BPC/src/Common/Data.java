package Common;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Data {

	public int n; //the number of nodes, not including the depot
	public double[][] d; //the distance matrix
	public int[] q; //the demand of each vertex
	public int Q; //the capacity
	public int m; //the number of segment
	public int[] c; //unit cost
	public String name; //instance name
	public long[] mask;
	public double[] arc_map;
	
	//DP2 init masks
	public int init_limit = 50;
	public long[] intDC = {0x00, 0x00, 0x00, 0x00};
	//algorithm parameter
	public double time_limit = 7200;
	public double start_time  = System.nanoTime();
	//output information - root node
	public boolean is_root = true;
	public double lp_cost;
	public double lpc_cost;
	public double root_lp_time  = 0;
	public double root_lpc_time = 0;
	public double root_tabu_time;
	public double root_bd1_time = 0;
	public double root_bd2_time = 0;
	public double root_bd3_time = 0;
	public double root_join_time;
	public double total_join_time;
	public int root_flabels = 0;
	public int root_plabels = 0;
	public int root_blabels = 0;
	public int root_cap_num = 0;
	public int root_sr_num = 0;
	public double lpc = 0;
	
	public double ip_cost;
	public double ip_time = 0;
	public int node_num = 0;
	public int total_cap_num = 0;
	public int total_sr_num = 0;
	public double total_tabu_time;

	public long all_mask;

	public double DP_1_time = 0;
	public double DP_2_time = 0;
	public double DP_NG_time = 0;

	public Data() {
	}
	public double arc_cost(int i, int j, int t){
		return d[i][j] * arc_map[t];
	}
	
	public void build_mask(){
//		start_time = System.nanoTime();
		mask = new long[2* (n + 1 )];
		long mk = 0x01;
		for(int i = 0; i < 2 * (n + 1); i++){
			mask[i] = mk;
			if(i == 63 || i == 127 || i == 191)
				mk = 0x01;
			else
				mk *= 2;
		}
		mk = 0x01;
		for(int i = 0; i < 64; i++){
			all_mask = all_mask | mk;
			mk *= 2;
		}
		//init_limit = n / 3 + 10;
		init_limit = 50;
		arc_map = new double[Q + 1];
		for(int i = 0; i <= Q; i++){
			int k = 0;
			while(i > q[k]) k++;
			arc_map[i] = c[k];
		}
	}
	
	public boolean time_out(){
		if((System.nanoTime() - start_time) / 1e9 > time_limit)
			return true;
		else
			return false;
	}
	public boolean turn_out(){
		if((System.nanoTime() - start_time) / 1e9 > 7200)
			return true;
		else
			return false;
	}

	public void distance_refine() {
		double[][] new_d = new double[n + 1][n + 1];
		for (int i = 0; i < n + 1; i++)
			for (int j = 0; j < n + 1; j++){
				int old_i =  - 1; int old_j = - 1;
				if (i < n) {
					 old_i = i + 1;
				}
				else if (i == n)
					old_i = 0;
				if (j < n) {
					old_j = j + 1;
				}
				else if (j == n){
					old_j = 0;
				}
//				BigDecimal bd = new BigDecimal(d[i][j]);
//				bd = bd.setScale(4, RoundingMode.HALF_UP);
				new_d[i][j] = d[old_i][old_j];
			}
		d = new_d;
	}
}
