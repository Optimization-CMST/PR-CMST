package Run;

import BPC.SearchTree.RootNode_Test;
import BPC.SearchTree.Tree;
import Common.Data;
import Common.Input;
import Helper.Check;
import Heuristic_UB.Simple_UB;
import Heuristic_UB.Ub;
import com.gurobi.gurobi.GRBException;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Run {
    public static void main(String[] args) throws IOException, GRBException {
        // initializatio
        for (int i = 0; i < 9; i++) {
            String instance_part_1 = "";
            String instance_part_2 = "";
            switch (i){
                case 0 :
                    instance_part_1 = "50_node_center";
                    instance_part_2 = "c_51";
                    break;
                case 1 :
                    instance_part_1 = "50_node_edge";
                    instance_part_2 = "e_51";
                    break;
                case 2 :
                    instance_part_1 = "50_node_random";
                    instance_part_2 = "r_51";
                    break;
                case 3 :
                    instance_part_1 = "100_node_center";
                    instance_part_2 = "c_101";
                    break;
                case 4 :
                    instance_part_1 = "100_node_edge";
                    instance_part_2 = "e_101";
                    break;
                case 5 :
                    instance_part_1 = "100_node_random";
                    instance_part_2 = "r_101";
                    break;
                case 6 :
                    instance_part_1 = "150_node_center";
                    instance_part_2 = "c_151";
                    break;
                case 7 :
                    instance_part_1 = "150_node_edge";
                    instance_part_2 = "e_151";
                    break;
                case 8 :
                    instance_part_1 = "150_node_random";
                    instance_part_2 = "r_151";
            }
            for (int inst = 0; inst <= 49; inst++) {
                String input_string = "instance/" + instance_part_1  + "/" + "mlcmst_" + inst + instance_part_2 + "_3";
                Data data = Input.read_instance(input_string);
                data.distance_refine();
                data.build_mask();
                data.name = instance_part_2 + "_" + inst;

                double t1 = System.nanoTime();
                double t2 = System.nanoTime();
//        int a = 0;
                ArrayList<ArrayList<Integer>> init_columns = Simple_UB.initial_col_generation(data);

                Tree tree = new Tree(data);
                tree.solve(init_columns, null);
                double t3 = System.nanoTime();

                String output_Path = "result/" + instance_part_1 + "_result/" + data.name + ".txt";
                BufferedWriter writer = new BufferedWriter(new FileWriter(output_Path));
                writer.write("Heuristic UB : " + String.format("%.2f", tree.Heuristic_UB));
                writer.newLine();
                writer.write("Heuristic Time : " + String.format("%.2f", tree.Heuristic_Time));
                writer.newLine();
                writer.write("ip cost : " + String.format("%.2f", tree.best_value));
                writer.newLine();
                if (tree.break_sign == false) {
                    writer.write("best LB : " + String.format("%.2f", tree.best_value));
                }else{
                    writer.write("best LB : " + String.format("%.2f", tree.best_LB));
                }
                writer.newLine();
                writer.write("lp cost : " + String.format("%.2f", data.lp_cost));
                writer.newLine();
                writer.write("lp time : " + String.format("%.2f", (data.root_lp_time) / 1e9));
                writer.newLine();
                writer.write("lpc cost : " + String.format("%.2f", data.lpc_cost));
                writer.newLine();
                writer.write("lpc time :" + String.format("%.2f", (data.root_lpc_time) / 1e9));
                writer.newLine();
                writer.write("P1 Label : " + data.root_flabels);
                writer.newLine();
                writer.write("P2 Label : " + data.root_plabels);
                writer.newLine();
                writer.write("R Label : " + data.root_blabels);
                writer.newLine();
                writer.write("Root RCI Cuts : " + data.root_cap_num);
                writer.newLine();
                writer.write("Root SRI Cuts : " + data.root_sr_num);
                writer.newLine();
                writer.write("Total RCI Cuts : " + data.total_cap_num);
                writer.newLine();
                writer.write("Total SRI Cuts :" + data.total_sr_num);
                writer.newLine();
                writer.write("Nodes : " + data.node_num);
                writer.newLine();
                writer.write("Joining Time : " + String.format("%.2f", (data.total_join_time) / 1e9));
                writer.newLine();
                writer.write("Pruning Time : " + String.format("%.2f", (data.DP_1_time + data.DP_NG_time) / 1e9));
                writer.newLine();
                if (tree.break_sign == false) {
                    writer.write("Gap : " + 0);
                }else{
                    writer.write("Gap : " + String.format("%.2f", (tree.best_value - tree.best_LB) * 100/tree.best_value));
                }
                writer.newLine();

                double total_time = (t3 - t1) / 1e9;
                writer.write("Running Time : " + String.format("%.2f", total_time));
                writer.newLine();
                if (tree.slack_sign == true){
                    writer.write("require slack :" + String.valueOf(tree.slack_num));
                }
                writer.close();





                System.out.println("LPC value " + data.lpc_cost);
                System.out.println("LPC time " + data.root_lpc_time / 1e9);
                System.out.println("Node Number " + data.node_num);
                System.out.println("upper bound time: " + (t2 - t1) / 1e9);
                System.out.println("optimal cost: " + tree.best_value);
                System.out.println("total time: " + (t3 - t1) / 1e9);

                System.out.println("bpc time: " + (t3 - t2) / 1e9);
//        System.out.println("Ub value " + ub);

                System.out.println("DP_1 time" + data.DP_1_time);
                System.out.println("DP_2 time" + data.DP_2_time);
                System.out.println("DP NG Time" + data.DP_NG_time);

//        Check.check_EuclideanDistance(data);


                // BPC Process
//        ArrayList<ArrayList<Integer>> init_columns = new ArrayList<ArrayList<Integer>>() ;
//        for(int i = 0; i < data.n; i++){
//            ArrayList<Integer> column = new ArrayList<Integer>();
//            column.add(1);    // size
//            column.add(i);    // id
//            column.add(-1);   // root
//            init_columns.add(column);
//        }
//        RootNode_Test test = new RootNode_Test(data);
//        test.solve(init_columns, null);
            }
        }
    }
}