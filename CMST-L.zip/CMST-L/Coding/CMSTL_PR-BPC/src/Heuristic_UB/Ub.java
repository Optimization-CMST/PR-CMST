package Heuristic_UB;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class Ub {
	
	public static void get_column(ArrayList<Integer> column, ArrayList<Integer> place, int father, int[] tree){
		for(int i = 1; i < tree.length; i++){
			if(tree[i] == column.get(father)){
				column.add(i);
				place.add(father);
				get_column(column, place, column.size() - 1, tree);
			}
		}
	}
	
	public static double get_ub(String path,  int cap, ArrayList<ArrayList<Integer>> trees) throws FileNotFoundException{
		fun i = new fun();
		i.File_Name = path;
		i.Initializing();
		i.Q = cap;
		long l1 = 0;
		long l2 = 0;
		i.BLK= i.N_vtx / i.Q;
		i.set_parameter();
		
		int l = 0;
		int lbest = 99999;
		
		System.out.println( "BLK = " + i.BLK + " Q = " + i.Q + " search_depth = " + i.search_depth + " tabu_len = " + i.tabu_len );
		
		for(int mm = 0; mm < 5; mm++ )
	    {
	         
	         //i.initilize_solution();
			 System.out.println("begin");
	         l1 = System.currentTimeMillis(); 
	         l = i.hybrid_search( 50 );
	         l2 = System.currentTimeMillis();
	         //l = tabu_search( 10000 );
	         if(l < lbest)
	         {	 
	            lbest = l;
	            for(int j = 0; j < i.N_vtx; j++ )
		        {
		             i.Gbest[ j ] = i.Rbest[ j ]; 
		        }
	         }
	         System.out.println("l = " + l +  " lbest = " + lbest + " time = " + (l2 - l1) );
	    } 
		
		i.check_solution(i.Gbest, lbest);
		i.out_put_edge();
		
		//for(int j = 0; j < i.N_vtx; j++ )
        //{
			//System.out.print(i.Gedge[ j ] + " "); 
        //}
		
		for(int j = 1; j < i.Gedge.length; j++){
			if(i.Gedge[j] == 0){
				ArrayList<Integer> temp_column = new ArrayList<Integer>();
				ArrayList<Integer> temp_place = new ArrayList<Integer>();
				temp_column.add(j);
				temp_place.add(-1);
				get_column(temp_column, temp_place, 0, i.Gedge);
				ArrayList<Integer> column = new ArrayList<Integer>();
				column.add(temp_column.size());
				for(int k = 0; k < temp_column.size(); k++)
					column.add(temp_column.get(k) - 1);
				for(int k = 0; k < temp_place.size(); k++){
					if(k == 0)
						column.add(temp_place.get(k));
					else
						column.add(temp_place.get(k) + 1);
				}
				//System.out.println(column);
				trees.add(column);
			}
		}
		
		return lbest;
	}
}
