package Heuristic_UB;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class fun {

	String File_Name;
	int N_vtx;
	int Q;
	int [][]Edge; 
	int [][]Edge_solution; 
	int [][]Edge1; 
	int [][]tabu_list;
	int []tabu_ns;
	int []Gedge;
	int []solution;
	int []color;
	int []Gbest;
	int []Rbest;
	int num_best;
	int []best_v;
	int []best_k;
	int []ini_solution;
	int tabu_len;
	int f;
	int []sub_tree;
	int []min_edge;
	int []min_adj;
	int []set_A;
	int []set_B;
	int []node_color;
	int tmk;
	int []set_E0;
	int []set_E1;
	int []address;
	int [][]C_nd;
	int []ref;
	int Slen;
	int []S_node;
	int BLK;
	int []f_blk;
	int []aa;
	int []bb;
	int []bestsolution;
	int [][]Pop;
	int [][]distwo;
	int Psize = 5;
	int p1;
	int p2;
	int [][]C_nd1;
	int [][]C_nd2;
	int []color1;
	int []color2;
	int ff_best;
	int []fpop;
	int []offspring;
	int []adjaclen;
	int [][]adjacMatrix;
	int [][]delta_exchange;
	int iter;
	int fbest;
	int search_depth;
	
	public ArrayList<Integer> d;
	
	
	public void Initializing() throws FileNotFoundException{
	    
	     Scanner cin = new Scanner(new BufferedReader(new FileReader(File_Name)));
	     String StrReading = "";
	     StrReading = cin.next();
		 N_vtx = Integer.parseInt(StrReading.trim());
		 N_vtx = N_vtx + 1;
	     System.out.println("N_vtx = " + N_vtx);
	     Edge = new int[N_vtx + 1 ][N_vtx + 1 ];
	     
	     C_nd = new int[ N_vtx ][ N_vtx ];
	     C_nd1 = new int[ N_vtx ][ N_vtx ];
	     C_nd2 = new int[ N_vtx ][ N_vtx ];
	     Edge1 = new int[ N_vtx + 1 ][ N_vtx + 1 ];
	     Edge_solution = new int[ N_vtx ][ N_vtx ];
	     tabu_list = new int[ N_vtx ][ N_vtx ];
	     Pop = new int[ N_vtx ][ N_vtx ];     
	     solution = new int[ N_vtx ]; 
	     ini_solution = new int[ N_vtx ];
	     delta_exchange = new int[ N_vtx ][ N_vtx ];
	     address = new int[ N_vtx ];
	     tabu_ns = new int[ N_vtx ];
	     Gbest = new int[ N_vtx ];
	     Rbest = new int[ N_vtx ]; 
	     ref = new int[ N_vtx ];
	     distwo = new int[ N_vtx ][ N_vtx ];
	     set_A = new int[ N_vtx ]; 
	     set_B = new int[ N_vtx ]; 
	     Gedge = new int[ N_vtx ];
	     sub_tree = new int[ N_vtx ];
	     min_edge = new int[ N_vtx ];
	     min_adj = new int[ N_vtx ];
	     set_E0 = new int[ N_vtx ];
	     set_E1 = new int[ N_vtx ];
	     fpop = new int[ N_vtx ];
	     color = new int[ N_vtx ];
	     color1 = new int[ N_vtx ];
	     color2 = new int[ N_vtx ];
	     aa = new int[ N_vtx + 1 ];
	     bb = new int[ N_vtx + 1 ];
	     S_node = new int[ N_vtx ];
	     offspring = new int[ N_vtx ];
	     node_color = new int[ N_vtx ];
	     f_blk = new int[ N_vtx ];
	     best_v = new int[ N_vtx ];
	     bestsolution = new int[ N_vtx ]; 
	     best_k = new int[ N_vtx ];
	     adjaclen = new int[ N_vtx ];
	     adjacMatrix = new int[ N_vtx ][ N_vtx ];
	     
	     
	     //FIC >> Q;
	     //N_vtx = N_vtx + 1;
	     
	     int i, j, m;
	     int g1, g2, flag;
	     g2 = 0;
		  for( i = 0; i < N_vtx; i++ )
		  {
			   flag = 0;
			   //System.out.println("");
			   for( j = 0; j < N_vtx; j++ )
			   {
					if(flag == 0)
					{
						StrReading = cin.next();
						m = Integer.parseInt(StrReading.trim());
						//System.out.print(m+ " ");
						//cout << m << " ";
						if(m <= 10000)
						{
							Edge[ i ][ j ] = m;
						}
						else
						{
							//System.out.println(m+ " ");
							g1 = m/10000;
							g2 = m - g1*10000;
							Edge[ i ][ j ] = g1;
							flag = 1;
						}
					}
					else
					{
						Edge[ i ][ j ] = g2;
						flag = 0;
					}
			   }
			   //cout << endl;
		  }

		  for( i = 0; i < N_vtx; i++ )
		  {
			   for( j = 0; j < N_vtx; j++ )
				  Edge1[ i ][ j ] = Edge[ i ][ j ];
		  }

		  for( i = 0; i < N_vtx; i++ )
		  if( i == 0 )
		  {
			  ref[ 0 ] = N_vtx - 1;
		  }
		  else
		  {
			  ref[ i ] = i - 1;
		  }

		  for( i = 0; i < N_vtx; i++ )
		  {
			   for( j = 0; j < N_vtx; j++ )
				  Edge[ i ][ j ] = Edge1[ ref[ i ] ][ ref[ j ] ];
		  }

	     for( i = 0; i < N_vtx; i++ )
	    	  Edge[ i ][ i ] = 0;
	     
	     for( i = 0; i < N_vtx; i++ )
	     {
	          for( j = 0; j < N_vtx; j++ )
	          if(Edge[ i ][ j ] != Edge[ j ][ i ])
	          {
	                System.out.println("not dui matrix i = " + i + " j = " + j + " x = " + Edge[ i ][ j ] + " y = " + Edge[ j ][ i ]);
	          }
	          
	     }
	     
	     /*for( i = 0; i < N_vtx; i++ )
	     {
	          for( j = 0; j < N_vtx; j++ )
	             Edge1[ i ][ j ] = Edge[ i ][ j ];
	     }
	     
	     for( i = 1; i < N_vtx - 1; i++ )
	     {
	         Edge[ i ][ 0 ] = Edge[ 0 ][ i ] = Edge1[ N_vtx - 1 ][ i ]; 
	         Edge[ N_vtx - 1 ][ i ] = Edge[ i ][ N_vtx - 1 ] = Edge1[ i ][ 0 ];
	     }*/
	     cin.close();
	} 
	
	public int randomInt( int n )
	{
		 Random r3 = new Random();
	     return r3.nextInt(n);
	}

	public int max_spanning_tree(int len)
	{
	     int i, j, k, l, m, k0;
	     int mink;
	     int minl;
	     int minf;
	     int lenA = len;
	      
	     int lenB = 0;
	     
	     if(len == 0)
	        return 0;
	     
	     int minf0 = 999999;
	     
	     int plen = 0;
	     l = 0;
	   
	     for(i = 0; i < lenA; i++ )
	     {
	        k = set_A[ i ]; 
	        if( Edge[ k ][ 0 ] < minf0) 
	        {
	           minf0 = Edge[ k ][ 0 ];
	           l = i;
	        }
	     }
	      
	     //l = randomInt(lenA);
	     k0 = set_A[ l ];
	     set_B[ lenB++ ] = set_A[ l ];
	     set_A[ l ] = set_A[ lenA - 1 ];
	     lenA--;
	     
	     for(i = 0; i < lenA; i++ )
	     {
	        k = set_A[ i ]; 
	        min_edge[ k ] = Edge[ k ][ k0 ]; 
	        min_adj[ k ] = k0; 
	     }
	     
	     l = 0;
	     
	     while(lenA > 0)
	     {
	        mink = minl = -1;
	        minf = 9999999;
	        for( i = 0; i < lenA; i++ )
	        if(min_edge[ set_A[ i ] ] < minf)
	        {
	             minf = min_edge[ set_A[ i ] ];
	             minl = i;        
	        } 
	        
	        plen += minf;  
	        
	        k0 = set_A[ minl ];
	        set_B[ lenB++ ] = set_A[ minl ];
	        set_A[ minl ] = set_A[ lenA - 1 ];
	        lenA--;   
	        
	        for(i = 0; i < lenA; i++ )
	        {
	           k = set_A[ i ]; 
	           if( Edge[ k ][ k0 ] < min_edge[ k ] )
	           {
	               min_edge[ k ] = Edge[ k ][ k0 ]; 
	               min_adj[ k ] = k0;  
	           }
	        }
	     }
	     
	     return plen + minf0;
	}
	
	public void select_all()
	{
	    int i, j, k, l;
	    Slen = 0;
	    for( i = 1; i < N_vtx; i++ )
	    {
	        if(node_color[ i ] == 0)
	           S_node[ Slen++ ] = i; 
	    }
	}

	public void initilize_solution()
	{
	     int i, j, k, l, m;
	     int tcl = 0;
	     
	     for( i = 0; i < N_vtx; i++ )
	     {
	         color[ i ] = 0;
	         node_color[ i ] = 0;   
	     } 
	     
	     for( i = 0; i < N_vtx; i++ )
	     for( j = 0; j < N_vtx; j++ )
	         tabu_list[ i ][ j ] = 0; 
	     
	     for( i = 1; i < N_vtx; i++ )
	     {     
	         select_all();
	         k = randomInt(Slen);
	         k = S_node[ k ];
	         while( true )
	         {
	             tcl = 1 + randomInt(BLK);
	             if( color[ tcl ] < Q)
	             {
	                 break;
	             }    
	         }
	         node_color[ k ] = tcl;
	         color[ tcl ]++;
	     }
	     

	     for( i = 0; i < N_vtx; i++ )
	        color[ i ] = 0;
	        
	     for( i = 0; i < N_vtx; i++ )
	     if(node_color[ i ] > 0)
	     {
	        k = node_color[ i ];  
	        C_nd[ k ][ color[ k ] ] = i;
	        address[ i ] = color[ k ];
	        color[ k ]++;
	     }
	     
	     f = 0;
	     for( i = 1; i <= BLK; i++ )
	     {
	        for(j = 0; j < color[ i ]; j++) 
	           set_A[ j ] = C_nd[ i ][ j ];
	        f_blk[ i ] = max_spanning_tree( color[ i ] ); 
	        f += f_blk[ i ];
	     }
	     //System.out.print("finish");
	}
	
	public int delta_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    for( i = 0; i < color[ node_color[ xnd1 ] ]; i++ )
	        set_A[ i ] = C_nd[ node_color[ xnd1 ] ][ i ];
	    
	    m = address[ xnd1 ];
	    set_A[ m ] = xnd2;
	    
	    int d1 = max_spanning_tree( color[ node_color[ xnd1 ] ] );   
	    
	    for( i = 0; i < color[ node_color[ xnd2 ] ]; i++ )
	        set_A[ i ] = C_nd[ node_color[ xnd2 ] ][ i ];
	    
	    m = address[ xnd2 ];
	    set_A[ m ] = xnd1;
	    
	    int d2 = max_spanning_tree( color[ node_color[ xnd2 ] ] );   
	    
	    int d = d1 + d2 - f_blk[ node_color[ xnd1 ] ] - f_blk[ node_color[ xnd2 ] ];
	     
	    return d;
	}

	public void perform_exchange_two(int xnd1, int xnd2)
	{
	    int i, j, k, l, m;
	    int k1 = node_color[ xnd1 ];
	    int k2 = node_color[ xnd2 ];
	    int m1 = address[ xnd1 ];
	    int m2 = address[ xnd2 ];
	    
	    node_color[ xnd1 ] = k2;
	    node_color[ xnd2 ] = k1;
	    
	    C_nd[ k1 ][ m1 ] = xnd2;
	    C_nd[ k2 ][ m2 ] = xnd1;
	    address[ xnd1 ] = m2;
	    address[ xnd2 ] = m1;
	    
	    for(j = 0; j < color[ k1 ]; j++) 
	        set_A[ j ] = C_nd[ k1 ][ j ];
	    f_blk[ k1 ] = max_spanning_tree(color[ k1 ]);
	    
	    for(j = 0; j < color[ k2 ]; j++) 
	        set_A[ j ] = C_nd[ k2 ][ j ];
	    f_blk[ k2 ] = max_spanning_tree(color[ k2 ]);
	}

	public void update_delta_exchange(int ki, int kj)
	{
	     int i, j, k, l;
	     
	     int len1 = 0;
	     int len2 = 0;
	     
	     for( i = 1; i < N_vtx; i++ )
	     if( (node_color[ i ] == ki) || (node_color[ i ] == kj) )
	         aa[ len1++ ] = i;
	     else
	         bb[ len2++ ] = i;
	         
	     for( i = 0; i < len1; i++ )
	     for( j = 0; j < len2; j++ )  
	         delta_exchange[ aa[ i ] ][ bb[ j ] ] = delta_exchange[ bb[ j ] ][ aa[ i ] ] = delta_exchange_two(aa[ i ], bb[ j ]);   
	         
	     for( i = 0; i < color[ ki ]; i++ )
	     for( j = 0; j < color[ kj ]; j++ )  
	         delta_exchange[ C_nd[ ki ][ i ] ][ C_nd[ kj ][ j ] ] = delta_exchange[ C_nd[ kj ][ j ] ][ C_nd[ ki ][ i ] ] = delta_exchange_two(C_nd[ ki ][ i ], C_nd[ kj ][ j ]);              
	}
	
	public int check_solution(int [] cp, int fbest)
	{
	     int  fft, i, j, k, l, m, m1;
	     int num = 0;
	     
	     fft = 0;
	     l = 0;
	     for( k = 1; k <= BLK; k++ )
	     {
	        l = 0; 
	        for( i = 1; i < N_vtx; i++ )
	        if(cp[ i ] == k)
	        {
	           set_A[ l++ ] = i;
	           num++;
	        }
	         
	        m =  max_spanning_tree(l);
	        fft += m;

	        /*for(j = 0; j < color[ k ]; j++) 
		        set_A[ j ] = C_nd[ k ][ j ];
	        m1 = max_spanning_tree(color[ k ]);
	        if(m != m1)
	        	System.out.println("m = " + m + " m1 = " + m1 + " m2 = " + f_blk[ k ] + " k = " + k);*/
	     }     
	     //cout << "num = " << num << " ftest = " << fft << " fbest = " << fbest << endl;  
	     System.out.println("num = " + num + " ftest = " + fft + " fbest = " + fbest);
	     
	     return fft;
	}
	
	public int tabu_search( int depth )
	{
	     int iter, i, j, k, l, m;
	     int d, fmin, ftabu;
	     int kmin1, kmin2, ktabu1, ktabu2;
	     int fbest = f;
	     
	     for( i = 0; i < N_vtx; i++ )
	         bestsolution[ i ] = node_color[ i ];
	     
	     for( i = 0; i < N_vtx; i++ )
	     for( j = 0; j < N_vtx; j++ )
	         tabu_list[ i ][ j ] = 0; 
	        
	     for( i = 1; i < N_vtx; i++ )
	     for( j = i + 1; j < N_vtx; j++ )
	     if(node_color[ i ] != node_color[ j ] )
	         delta_exchange[ i ][ j ] = delta_exchange[ j ][ i ] = delta_exchange_two(i,j);     
	     
	     for( iter = 1; iter <= depth; iter++ )
	     {
	          fmin = 9999999;
	          kmin1 = -1;
	          kmin2 = -1;
	          
	          ftabu = 9999999;
	          ktabu1 = -1;
	          ktabu2 = -1;
	          l = 0;
	          
	          for( i = 1; i < N_vtx; i++ )
	          for( j = i + 1; j < N_vtx; j++ )
	          if( (node_color[ i ] != node_color[ j ]) )
	          {
	              
	                d = delta_exchange[ i ][ j ];
	                if( (tabu_list[ i ][ node_color[ j ] ] < iter) && (tabu_list[ j ][ node_color[ i ] ] < iter) )
	                {
	                    if(d < fmin)
	                    {
	                        fmin = d;
	                        kmin1 = i;
	                        kmin2 = j;
	                        l = 1;
	                    }
	                    else if( d == fmin )
	                    {
	                        l++;
	                        if( randomInt(l) == 0 )
	                        {
	                           kmin1 = i;
	                           kmin2 = j;
	                        } 
	                    } 
	                }
	                else
	                {
	                    if( d < ftabu )
	                    {
	                         ftabu = d;
	                         ktabu1 = i;
	                         ktabu2 = j;
	                    }
	                }
	          }  
	          
	          if( (ftabu < fmin) && (f + ftabu < fbest) )
	          {
	              f += ftabu; 
	              tabu_list[ ktabu1 ][ node_color[ ktabu1 ] ] = iter + tabu_len;
	              tabu_list[ ktabu2 ][ node_color[ ktabu2 ] ] = iter + tabu_len; 
	              perform_exchange_two(ktabu1,ktabu2);
	              update_delta_exchange(node_color[ ktabu1 ], node_color[ ktabu2 ]);
	              //cout << "in aspiration f = " << f << endl;
	              //cout << "hello2 ktabu1 = " << ktabu1 << " ktabu2 = " << ktabu2 << " c1 = " << node_color[ ktabu1 ] << " c2 = " << node_color[ ktabu2 ] << endl;
	          }
	          else
	          {
	              f += fmin; 
	              tabu_list[ kmin1 ][ node_color[ kmin1 ] ] = iter + tabu_len;
	              tabu_list[ kmin2 ][ node_color[ kmin2 ] ] = iter + tabu_len; 
	              perform_exchange_two(kmin1,kmin2);
	              update_delta_exchange(node_color[ kmin1 ], node_color[ kmin2 ]);
	              //cout << "hello2 kmin1 = " << kmin1 << " kmin2 = " << " c1 = " << node_color[ kmin1 ] << " c2 = " << node_color[ kmin2 ] << endl;
	          }   
	          
	          if( fbest  > f )
	          {
	              fbest = f;
	              for( i = 0; i < N_vtx; i++ )
	                  bestsolution[ i ] = node_color[ i ];
	              //check_solution(bestsolution, fbest);
	              //cout << "fbest = " << fbest << endl; 
	          }  
	     }
	     return fbest;  
	}
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	///////////*hybrid evolutionary algorithm*///////////////////////////////////////////////////////////////////////////////////////// 
	
	void dispatchnode1(int [] p)
	{
	     int i, j, k, l, m;
	     for( i = 1; i <= BLK; i++ )
	        color1[ i ] = 0;
	        
	     for( i = 1; i < N_vtx; i++ )
	     {
	          C_nd1[ p[ i ] ][ color1[ p[ i ] ] ] = i;
	          color1[ p[ i ] ]++;      
	     }             
	}
	 
	void dispatchnode2(int [] p)
	{
	     int i, j, k, l, m;
	     for( i = 1; i <= BLK; i++ )
	        color2[ i ] = 0;
	        
	     for( i = 1; i < N_vtx; i++ )
	     {
	          C_nd2[ p[ i ] ][ color2[ p[ i ] ] ] = i;
	          color2[ p[ i ] ]++;      
	     }             
	}
	 
	int dis_two_component(int x1, int x2)
	{
	    int i, j, k, m;
	    int l1 = 0;
	    int l2 = 0;
	    int l = 0;
	    int k1 = color1[ x1 ];
	    int k2 = color2[ x2 ];
	    while( (l1 < k1) && (l2 < k2) )
	    {
	        if(C_nd1[ x1 ][ l1 ] < C_nd2[ x2 ][ l2 ])  
	        {
	            l1++;           
	        } 
	        else if(C_nd1[ x1 ][ l1 ] > C_nd2[ x2 ][ l2 ])
	        {
	            l2++; 
	        }
	        else if(C_nd1[ x1 ][ l1 ] == C_nd2[ x2 ][ l2 ])
	        {
	            l1++;
	            l2++;
	            l++;
	        }
	    }
	    
	    return l;
	}
	
	int com_distance(int [] p1, int [] p2)
	{
	    int i, j, k, l, m, n, num;
	    int i1, i2, i3;
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = 0;
	    }
	    
	    dispatchnode1(p1);
	    dispatchnode2(p2);
	    
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = dis_two_component(i,j);
	    }
	    
	    int cmin = -1;
	    int hmin = -1;
	    num = 0;
	    
	    int fm = -1;
	    for( i1 = 1; i1 <= BLK; i1++ )
	    {
	         cmin = -1;
	         hmin = -1;
	         fm = -1;
	         for( i2 = 1; i2 <= BLK; i2++ )
	         for( i3 = 1; i3 <= BLK; i3++ )
	         if( distwo[ i2 ][ i3 ] > fm )
	         {
	             fm = distwo[ i2 ][ i3 ];
	             cmin = i2;
	             hmin = i3;
	         }
	         
	         num = num + fm;
	         
	         for( i = 1; i <= BLK; i++ )
	         {
	              distwo[ cmin ][ i ] = 0; 
	              distwo[ i ][ hmin ] = 0;
	         }
	    } 
	    
	    int pros = (100*num)/(N_vtx - 1); 
	    return pros;
	}

	int com_pop_dis(int ki_len)
	{
	    int i, j, k, l, m;
	    l = 0;
	    for( i = 0; i < ki_len; i++ )
	    {
	        m = com_distance(Pop[i],bestsolution); 
	        if( m > l )
	           l = m;
	    }
	    
	    return l;
	}

	int Ini_Pop()
	{
	    int i, j, k, l, l1, l2, m;
	    int f1;
	    i = 0;
	    ff_best = 900000;
	    while( i < Psize )
	    {
	          initilize_solution();
	          f1 = tabu_search( search_depth );
	          //System.out.println( "one run of search is finished f1 = " + f1 );
	         
	          l = com_pop_dis(i); 
	          //if( (l < 95 ) || (f1 < ff_best) )
	          {
	            if(f1 < ff_best)
	            {	
	                ff_best = f1;
	                for( j = 0; j < N_vtx; j++ )
		            {
		               Rbest[ j ] = bestsolution[ j ]; 
		            }
	            }
	         
	            fpop[ i ] = f1;
	            for( j = 0; j < N_vtx; j++ )
	            {
	               Pop[ i ][ j ] = bestsolution[ j ]; 
	            }
	            i++;
	         }
	    }
	    System.out.println( "finish population ini f = " + ff_best );
	    
	    return ff_best; 
	}
	
	void assign_value(int x1, int x2, int xkl)
	{
	    int k;
	    int l1 = 0;
	    int l2 = 0;
	    int k1 = color1[ x1 ];
	    int k2 = color2[ x2 ];
	    while( (l1 < k1) && (l2 < k2) )
	    {
	        if(C_nd1[ x1 ][ l1 ] < C_nd2[ x2 ][ l2 ])  
	        {
	            l1++;           
	        } 
	        else if(C_nd1[ x1 ][ l1 ] > C_nd2[ x2 ][ l2 ])
	        {
	            l2++; 
	        }
	        else if(C_nd1[ x1 ][ l1 ] == C_nd2[ x2 ][ l2 ])
	        {
	            k = C_nd1[ x1 ][ l1 ];
	            offspring[ k ] = xkl; 
	            l1++;
	            l2++;
	        }
	    }
	}
	
	public void cross_over(int []pp1, int []pp2)
	{
	    int i, j, k, l, m, n, num;
	    int i1, i2, i3;
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = 0;
	    }
	    
	    dispatchnode1(pp1);
	    dispatchnode2(pp2);
	    
	    for( i = 0; i < N_vtx; i++ )
	       offspring[ i ] = 0;
	    
	    for( i = 1; i <= BLK; i++ )
	    for( j = 1; j <= BLK; j++ )
	    {
	         distwo[ i ][ j ] = dis_two_component(i,j);
	    }
	    
	    int cmin = -1;
	    int hmin = -1;
	    num = 0;
	    int fm = -1;
	    for( i1 = 1; i1 <= BLK; i1++ )
	    {
	         cmin = -1;
	         hmin = -1;
	         fm = -1;
	         for( i2 = 1; i2 <= BLK; i2++ )
	         for( i3 = 1; i3 <= BLK; i3++ )
	         if( distwo[ i2 ][ i3 ] > fm )
	         {
	             fm = distwo[ i2 ][ i3 ];
	             cmin = i2;
	             hmin = i3;
	         }
	         
	         num = num + fm;
	         
	         for( i = 0; i <= BLK; i++ )
	         {
	              distwo[ cmin ][ i ] = 0; 
	              distwo[ i ][ hmin ] = 0;
	         }
	         
	         assign_value(cmin, hmin, i1);
	    }
	}

	void Select_P()
	{
	    p1 = randomInt( Psize );
	    p2 = randomInt( Psize );
	    while(p1 == p2)
	    {
	       p2 = randomInt( Psize );
	    }
	}
	
	int Max_f( )
	{
	    int i, j, k, l, m;
	    int kp = 0;
	    int fmax = 0;
	    for( i = 0; i < Psize; i++ )
	    {
	       if( fpop[ i ] > fmax )
	       {
	           fmax = fpop[ i ];
	           kp = i;
	       }
	    }
	     
	    return kp;
	}

	int com_pop_dis_off()
	{
	    int i, j, k, l, m;
	    l = -100;
	    for( i = 0; i < Psize; i++ )
	    {
	        m = com_distance(Pop[ i ],bestsolution); 
	        if( m > l )
	           l = m;
	    }
	    
	    return l;
	}

	void up_date(int fm)
	{
	     int j;
	     int dl = Max_f( );
	     int dmin = com_pop_dis_off();
	     if( (fm < ff_best) || (dmin < 95) )
	     {
	         if( fm < fpop[ dl ] )
	         {            
	            fpop[ dl ] = fm;
	            for( j = 0; j < N_vtx; j++ )
	            {
	               Pop[ dl ][ j ] = bestsolution[ j ]; 
	            }
	         }
	     }
	} 

	void initilize_offspring()
	{
	     int i, j, k, l;
	     int tcl = 0;
	     
	     for( i = 0; i < N_vtx; i++ )
	     {
	         color[ i ] = 0;
	         node_color[ i ] = 0;   
	     } 
	     
	     for( i = 0; i < N_vtx; i++ )
	     for( j = 0; j < N_vtx; j++ )
	         tabu_list[ i ][ j ] = 0; 
	     
	     l = 0;    
	     for( i = 1; i < N_vtx; i++ )
	     if(offspring[ i ] > 0)
	     {
	         k = i;
	         tcl = offspring[ i ];  
	         node_color[ k ] = tcl;
	         color[ tcl ]++;  
	         l++;      
	     } 
	     
	     while(true)
	     {     
	         select_all();
	         if(Slen == 0)
	             break;
	         k = randomInt(Slen);
	         k = S_node[ k ];
	         while(true)
	         {
	             tcl = 1 + randomInt(BLK);
	             if( color[ tcl ] < Q)
	             {
	                 break;
	             }    
	         }
	         node_color[ k ] = tcl;
	         color[ tcl ]++;
	     }
	     

	     for( i = 0; i < N_vtx; i++ )
	        color[ i ] = 0;
	        
	     for( i = 0; i < N_vtx; i++ )
	     if(node_color[ i ] > 0)
	     {
	        k = node_color[ i ];  
	        C_nd[ k ][ color[ k ] ] = i;
	        address[ i ] = color[ k ];
	        color[ k ]++;
	     }

	     f = 0;
	     for( i = 1; i <= BLK; i++ )
	     {
	        for(j = 0; j < color[ i ]; j++) 
	           set_A[ j ] = C_nd[ i ][ j ];
	        f_blk[ i ] = max_spanning_tree( color[ i ] ); 
	        f += f_blk[ i ];
	        //cout << "i = " << i << " len = " << color[ i ] << " fblk = " << f_blk[ i ] << endl;  
	     }
	}
	
	int check_bestsolution(int []cp, int ki)
	{
	     int  fft, i, k, l, m;
	     int num = 0;
	     
	     fft = 0;
	     l = 0;
	     for( k = 1; k <= BLK; k++ )
	     {
	        l = 0; 
	        for( i = 1; i < N_vtx; i++ )
	        if(cp[ i ] == k)
	        {
	           set_A[ l++ ] = i;
	           num++;
	        }
	        System.out.print( l + " "); 
	        m =  max_spanning_tree(l);
	        fft += m;       
	     }
	     System.out.println("");
	     System.out.println( "num = " + num + " ftest = " + fft + " fop = " + fpop[ ki ]);  
	     
	     return fft;
	}

	void check_pop()
	{
	     int i, j;
	     for( i = 0; i < Psize; i++ )
	     {
	        check_bestsolution(Pop[ i ], i);  
	     }
	     for( i = 0; i < Psize; i++ )
	     {
	        for( j = 0; j < Psize; j++ )
	        	System.out.print( com_distance(Pop[ i ], Pop[ j ]) + " ");
	        System.out.println("");
	     }   
	}
	
	int hybrid_search(int generation)
	{
	     int i, j, f1;
	     
	     Ini_Pop();
	     
	     for( i = 0; i < generation; i++ )
	     {
	        Select_P();
	        cross_over(Pop[ p1 ], Pop[ p2 ]);
	        initilize_offspring();
	        //inisolution();
	        //f1 = tabu_one_move(search_depth);  
	        f1 = tabu_search(search_depth);
	           
	        up_date(f1);
	        
	        if(f1 < ff_best)
	        {	
	          ff_best = f1;
	          for( j = 0; j < N_vtx; j++ )
	          {
	             Rbest[ j ] = bestsolution[ j ]; 
	          }
	        }
	        /*System.out.println( "gen = " + i + " one run f1 = " + f1 + " ffbest = " + ff_best );  
	        
	        if(i % 10 == 0)
	           check_pop();*/
	     }
	     return ff_best;
	}
	
	void set_parameter()
	{
	     if(Q <= 10)
	     {
	          if(N_vtx <= 123)
	          {
	              tabu_len = 15;
	              search_depth = 1000;      
	          }
	          else
	          {
	              tabu_len = 25;
	              search_depth = 2000;
	          }
	     }
	     else
	     {
	          if(N_vtx <= 123)
	          {
	              tabu_len = 10;
	              search_depth = 1000;      
	          }
	          else
	          {
	              tabu_len = 15;
	              search_depth = 2000;
	          }
	     }
	}
	
	public int max_spanning_tree_edge(int len, int cki)
	{
	     int i, j, k, l, m, k0;
	     int mink;
	     int minl;
	     int minf;
	     int lenA = len;
	      
	     int lenB = 0;
	     int lenE = 0;
	     
	     if(len == 0)
	        return 0;
	     
	     int minf0 = 999999;
	     
	     int plen = 0;
	     l = 0;
	   
	     for(i = 0; i < lenA; i++ )
	     {
	        k = set_A[ i ]; 
	        if( Edge[ k ][ 0 ] < minf0) 
	        {
	           minf0 = Edge[ k ][ 0 ];
	           l = i;
	        }
	     }
	      
	     //l = randomInt(lenA);
	     k0 = set_A[ l ];
	     Edge_solution[ cki ][ lenE++ ] = 0;
	     Edge_solution[ cki ][ lenE++ ] = k0;
	     //System.out.print(Edge_solution[ cki ][ lenE - 1] + " " + Edge_solution[ cki ][ lenE ]);
	     set_B[ lenB++ ] = set_A[ l ];
	     set_A[ l ] = set_A[ lenA - 1 ];
	     lenA--;
	     
	     for(i = 0; i < lenA; i++ )
	     {
	        k = set_A[ i ]; 
	        min_edge[ k ] = Edge[ k ][ k0 ]; 
	        min_adj[ k ] = k0; 
	     }
	     
	     l = 0;
	     
	     while(lenA > 0)
	     {
	        mink = minl = -1;
	        minf = 9999999;
	        for( i = 0; i < lenA; i++ )
	        if(min_edge[ set_A[ i ] ] < minf)
	        {
	             minf = min_edge[ set_A[ i ] ];
	             minl = i;        
	        } 
	        
	        plen += minf;  
	        
	        k0 = set_A[ minl ];
	        
	        Edge_solution[ cki ][ lenE++ ] = min_adj[ k0 ];
		    Edge_solution[ cki ][ lenE++ ] = k0;
		    //System.out.print(Edge_solution[ cki ][ lenE - 1] + " " + Edge_solution[ cki ][ lenE ]);
		     
	        set_B[ lenB++ ] = set_A[ minl ];
	        set_A[ minl ] = set_A[ lenA - 1 ];
	        lenA--;   
	        
	        for(i = 0; i < lenA; i++ )
	        {
	           k = set_A[ i ]; 
	           if( Edge[ k ][ k0 ] < min_edge[ k ] )
	           {
	               min_edge[ k ] = Edge[ k ][ k0 ]; 
	               min_adj[ k ] = k0;  
	           }
	        }
	     }
	     
	     return plen + minf0;
	}
	
	public void out_put_edge()
	{
		int i, j, k;
		for( i = 0; i < N_vtx; i++ )
		{	
	        color[ i ] = 0;
	        Gedge[ i ] = -1;
	        node_color[ i ] = Gbest[ i ];
		}
	        
	     for( i = 0; i < N_vtx; i++ )
	     if(node_color[ i ] > 0)
	     {
	        k = node_color[ i ];  
	        C_nd[ k ][ color[ k ] ] = i;
	        color[ k ]++;
	     }
	     
	     f = 0;
	     int f1 = 0;
	     for( i = 1; i <= BLK; i++ )
	     {
	        for(j = 0; j < color[ i ]; j++) 
	           set_A[ j ] = C_nd[ i ][ j ];
	        f_blk[ i ] = max_spanning_tree_edge( color[ i ], i ); 
	        f += f_blk[ i ];
	        
	        for(j = 0; j < color[ i ]; j++)
	        {
	        	System.out.print(Edge_solution[ i ][ 2*j ] + " " + Edge_solution[ i ][ 2*j + 1 ] + " ");
	        	f1 += Edge[ Edge_solution[ i ][ 2*j ] ][ Edge_solution[ i ][ 2*j + 1 ] ];
	        	Gedge[ Edge_solution[ i ][ 2*j + 1 ] ] = Edge_solution[ i ][ 2*j ] ;
	        }
	        System.out.println("");
	     }
	     System.out.println("Edge f1 = " + f1 + " f = " + f);
	     
	     for( i = 0; i < N_vtx; i++ )
	    	 System.out.print(Gedge[ i ] + " ");
	     System.out.println("");
	}
	
	public void out_put_transferdata()
	{
		int i;
		for( i = 0; i < N_vtx; i++ )
	    if( i == 0 )
	    {
	        ref[ 0 ] = N_vtx - 1;
	    }
	    else
	    {
	        ref[ i ] = i - 1;
	    }
		
		for( i = 0; i < N_vtx; i++ )
		{	
	        node_color[ ref[ i ] ] = Gbest[ i ];
		}
		
		for( i = 0; i < N_vtx; i++ )
		{	
	        Gbest[ i ] = node_color[ i ];
		}
		
		for( i = 0; i < N_vtx; i++ )
		{	
	        set_E0[ i ] =  ref[ i ] ;
	        if(Gedge[ i ] >= 0)
	           set_E1[ i ] =  ref[ Gedge[ i ] ];
	        else
	           set_E1[ i ] = -1;	 
		}
		
		for( i = 0; i < N_vtx; i++ )
			Gedge[ set_E0[ i ] ] = set_E1[ i ];
		
		int f1 = 0;
		for( i = 0; i < N_vtx; i++ )
		if( Gedge[ i ] >= 0 )	
		  f1 += Edge1[ Gedge[ i ] ][ i ];
		
		System.out.println("In out_put_transferdata, Edge f1 = " + f1 + " f = " + f);
	     
	     for( i = 0; i < N_vtx; i++ )
	    	 System.out.print(Gedge[ i ] + " ");
	     System.out.println("");
	}
	/*
	public static void  main(String args[]) throws FileNotFoundException{
		fun i = new fun();
		i.route = "E:/study in hust/luo solar/code/";
		i.file = "te120-3.dat"; //or "tc40-1.txt "
		i.File_Name = i.route  + i.file; 
		i.Q = 5;
		
		int len = i.file.length();
		char a[]=i.file.toCharArray();
		
		System.out.println(a[0]);
		System.out.println(a[len - 2]);
		if( (a[0] == 't') && (a[len-2] == 'a') )
		{
			i.File_Name = i.route  + i.file; 
			i.Initializing(0);
		}
		else if((a[0] == 't') && (a[len-2] == 'x'))
		{
			i.File_Name = i.route  + "capmst1.txt";
			i.Initializing(1);
		}
		
		long l1 = 0;
		long l2 = 0;
		i.BLK= i.N_vtx / i.Q;
		//i.tabu_len = 15;
		//i.search_depth = 1000;
		i.set_parameter();
		
		int l = 0;
		int j = 0;
		int mm = 0;
		int lbest = 99999;
		
		System.out.println( "BLK = " + i.BLK + " Q = " + i.Q + " search_depth = " + i.search_depth + " tabu_len = " + i.tabu_len );
		
		for(mm = 0; mm < 5; mm++ )
	    {
	         
	         //i.initilize_solution();
			 System.out.println("begin");
	         l1 = System.currentTimeMillis(); 
	         l = i.hybrid_search( 50 );
	         l2 = System.currentTimeMillis();
	         //l = tabu_search( 10000 );
	         if(l < lbest)
	         {	 
	            lbest = l;
	            for( j = 0; j < i.N_vtx; j++ )
		        {
		             i.Gbest[ j ] = i.Rbest[ j ]; 
		        }
	         }
	         System.out.println("l = " + l +  " lbest = " + lbest + " time = " + (l2 - l1) );
	    } 
		
		i.check_solution(i.Gbest, lbest);
		
		for( j = 0; j < i.N_vtx; j++ )
        {
			System.out.print(i.Gbest[ j ] + " "); 
        }
		System.out.println("");
		i.out_put_edge();
		i.out_put_transferdata();
	}
	*/
}
