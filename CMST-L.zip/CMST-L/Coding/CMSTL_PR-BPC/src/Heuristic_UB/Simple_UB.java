package Heuristic_UB;

import Common.Data;

import java.util.ArrayList;

public class Simple_UB {
    public static ArrayList<ArrayList<Integer>> initial_col_generation(Data data) {
        ArrayList<ArrayList<Integer>> init_columns = new ArrayList<>();
        for(int i = 0; i < data.n; i++){
            ArrayList<Integer> column = new ArrayList<Integer>();
            column.add(1);
            column.add(i);
            column.add(-1);
            init_columns.add(column);
        }
        return init_columns;
    }
}
